#!/usr/bin/env python3
"""Rebuild the supplied LGPL display library and relink the application objects."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys

ROOT=Path(__file__).resolve().parents[1]
def run(args,**kw):
    subprocess.run(list(map(str,args)),check=True,**kw)
def main():
    info=json.loads((ROOT/'release.json').read_text('utf-8'))
    sdk=Path(os.environ.get('IDF_PATH','')).resolve()
    if not (sdk/'tools/idf.py').is_file():
        raise SystemExit('First activate the ESP-IDF SDK using its export.sh.')
    rev=subprocess.check_output(['git','-C',str(sdk),'rev-parse','HEAD'],text=True).strip()
    if rev!=info['sdk_commit']:
        raise SystemExit('SDK commit differs; use '+info['sdk_commit'])
    for name in ('riscv32-esp-elf-gcc','riscv32-esp-elf-g++','riscv32-esp-elf-ar'):
        if not shutil.which(name):raise SystemExit('Missing tool: '+name)
    version=subprocess.check_output(['riscv32-esp-elf-gcc','--version'],text=True)
    if info['compiler_release'] not in version:
        raise SystemExit('Use the matching compiler release '+info['compiler_release'])
    def expand(s):return s.replace('@ROOT@',str(ROOT)).replace('@SDK@',str(sdk))
    out=ROOT/'output'; out.mkdir(exist_ok=True)
    obj=out/'driver-objects';obj.mkdir(exist_ok=True)
    jobs=json.loads((ROOT/'driver_compile.json').read_text('utf-8'))
    objects=[]
    for i,job in enumerate(jobs):
        target=obj/(Path(job['source']).name+'.obj');objects.append(target)
        print('Driver %d/%d: %s'%(i+1,len(jobs),job['source']),flush=True)
        args=[job['tool']]+[expand(s) for s in job['args']]
        run(args+['-c',ROOT/job['source'],'-o',target],cwd=ROOT)
    library=out/'libepdiy.a'
    if library.exists():library.unlink() # Replace only our previous generated library.
    run(['riscv32-esp-elf-ar','qc',library]+objects,cwd=ROOT)
    run(['riscv32-esp-elf-ranlib',library],cwd=ROOT)
    link=json.loads((ROOT/'link_args.json').read_text('utf-8'))
    run(['riscv32-esp-elf-g++']+[expand(s) for s in link],cwd=ROOT)
    elf=out/'pocket_manager.elf';app=out/'pocket_manager.bin'
    run([sys.executable,'-m','esptool','--chip','esp32s31','elf2image',
         '--flash-mode','dio','--flash-freq','80m','--flash-size','16MB',
         '--elf-sha256-offset','0xb0','--min-rev-full','0','--max-rev-full','99',
         '-o',app,elf],cwd=ROOT)
    data=app.read_bytes()
    if len(data)>info['manager_max_bytes']:
        raise SystemExit('Modified manager exceeds its existing Flash partition')
    prefix=(ROOT/'images/flash-prefix.bin').read_bytes()
    if len(prefix)!=info['app_offset'] or data[0]!=0xe9:
        raise SystemExit('Invalid Flash prefix or application image')
    firmware=out/'firmware-pocket-plus-1.0.7-plus.15-relinked.bin'
    firmware.write_bytes(prefix+data)
    digest=hashlib.sha256(firmware.read_bytes()).hexdigest()
    (out/'SHA256.txt').write_text(digest+'  '+firmware.name+'\n',encoding='utf-8')
    print('RELINK_DONE',firmware,'bytes=',firmware.stat().st_size,'sha256=',digest)
if __name__=='__main__':
    main()
