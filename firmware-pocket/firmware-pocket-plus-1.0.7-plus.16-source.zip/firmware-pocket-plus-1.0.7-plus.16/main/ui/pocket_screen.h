#pragma once
#include "lvgl.h"

namespace pocket {
// Caller owns the returned screen and loads/deletes it under the LVGL lock.
lv_obj_t* CreateScreen();
// Queue-only hardware key route; safe to call outside the LVGL task.
bool HardwareKey(const char* key);
}
