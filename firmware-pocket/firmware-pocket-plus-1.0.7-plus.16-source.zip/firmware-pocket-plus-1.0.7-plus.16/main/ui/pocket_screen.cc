#include "pocket_screen.h"
#include "package_actions.h"
#include "pocket/pocket_runtime.h"
#include "legal/pocket_legal.h"

#include "font/pocket_font.h"
#include "ime/pocket_keyboard.h"
#include "hal/pocket_hal.h"
#include "pocket/pocket_wifi_connection_model.h"
#include "esp_log.h"

#include <atomic>
#include <algorithm>
#include <array>
#include <cstring>
#include <deque>
#include <new>
#include <string>

namespace pocket {
namespace {
constexpr int kWidth = 480;
constexpr int kHeight = 800;
constexpr int kContentWidth = 448;
// Anchor the header group to the right; changing an icon width moves its neighbours.
constexpr int kHeaderMargin = 16;
constexpr int kHeaderGap = 8;
constexpr int kBatteryWidth = 35;
constexpr int kWifiWidth = 40;
constexpr int kHelpWidth = 126;
constexpr int kBatteryX = kWidth - kHeaderMargin - kBatteryWidth;
constexpr int kWifiX = kBatteryX - kHeaderGap - kWifiWidth;
constexpr int kHelpX = kWifiX - kHeaderGap - kHelpWidth;
constexpr int kTitleWidth = 126;
constexpr int kInkX = 146;
constexpr int kInkWidth = 64;

// The accepted 480x800 layout is expressed in logical coordinates. Only this
// edge maps it to the Plus panel; scroll positions are converted back before reuse.
constexpr int PxX(int n) { return (n * 684 + 240) / 480; }
constexpr int PxY(int n) { return (n * 1216 + 400) / 800; }
void LayoutPos(lv_obj_t* o, int x, int y) { lv_obj_set_pos(o, PxX(x), PxY(y)); }
void LayoutSize(lv_obj_t* o, int w, int h) { lv_obj_set_size(o, PxX(w), PxY(h)); }
void LayoutWidth(lv_obj_t* o, int w) { lv_obj_set_width(o, PxX(w)); }
void LayoutHeight(lv_obj_t* o, int h) { lv_obj_set_height(o, PxY(h)); }
int LogicalHeight(lv_obj_t* o) { return (lv_obj_get_height(o) * 800 + 608) / 1216; }
int LogicalScrollY(lv_obj_t* o) { return (lv_obj_get_scroll_y(o) * 800 + 608) / 1216; }
void LogicalScrollTo(lv_obj_t* o, int y, lv_anim_enable_t a) { lv_obj_scroll_to_y(o, PxY(y), a); }
void LayoutAlign(lv_obj_t* o, lv_align_t a, int x, int y) { lv_obj_align(o, a, PxX(x), PxY(y)); }

enum class Action { Runtime, OpenWifi, Back, WifiSave, ConfirmOpen, SelectWifi,
                    AskForget, Forget, CancelForget, ConfirmInstall, CancelInstall, PackageDetails, AskRestart,
                    OpenHelp, BackHelp, Ink, OpenPin, BackPin, PinKey, PinSubmit, PinRetry, PinInk,
                    DeepSleepInfo, DismissDeepSleep, OpenLegal, LegalDocument, LegalPrevious, LegalNext, BackLegal };
struct Button {
    lv_obj_t* object = nullptr;
    Command command = Command::Refresh;
    int argument = 0;
    bool allowed = true;
    Action action = Action::Runtime;
    std::string value;
};
struct Ui {
    lv_obj_t* screen = nullptr;
    lv_obj_t* title = nullptr;
    lv_obj_t* subtitle = nullptr;
    lv_obj_t* body = nullptr;
    lv_obj_t* notice = nullptr;
    lv_obj_t* list = nullptr;
    lv_obj_t* scan_status = nullptr;
    lv_obj_t* help_button = nullptr;
    lv_obj_t* ink_button = nullptr;
    lv_obj_t* battery_icon = nullptr;
    lv_obj_t* battery_number = nullptr;
    int battery_displayed = -2;
    lv_obj_t* wifi_icon = nullptr;
    std::array<lv_obj_t*, 4> wifi_bars{};
    lv_obj_t* wifi_disconnected = nullptr;
    lv_obj_t* network_status = nullptr;
    int wifi_icon_level = -1;
    bool wifi_icon_connected = false;
    lv_timer_t* timer = nullptr;
    const lv_font_t* font = nullptr;
    const lv_font_t* heading_font = nullptr;
    std::deque<Button> buttons;
    std::deque<Button> header_buttons;
    std::deque<Button> wifi_buttons;
    std::deque<Button> modal_buttons;
    std::deque<Button> pin_buttons;
    std::deque<Button> deep_sleep_buttons;
    lv_obj_t* deep_sleep_overlay = nullptr;
    bool deep_sleep_requested = false;
    lv_obj_t* pin_overlay = nullptr;
    lv_obj_t* pin_status = nullptr;
    std::array<lv_obj_t*, 3> pin_inputs{};
    int pin_focus = 0;
    bool pin_pending = false;
    uint32_t pin_submit_revision = 0;
    lv_obj_t* install_overlay = nullptr;
    lv_obj_t* install_hint = nullptr;
    lv_obj_t* blocking_overlay = nullptr;
    lv_obj_t* blocking_label = nullptr;
    bool blocking_switching = false;
    int install_index = -1;
    bool install_details_only = false;
    bool install_resume = false;
    bool install_restart = false;
    bool install_dialog_rebuild = false;
    std::string resume_run_id;
    std::string install_id, install_version, install_name;
    std::string install_detail;
    PackageView install_package;
    lv_obj_t* ssid = nullptr;
    lv_obj_t* password = nullptr;
    lv_obj_t* keyboard = nullptr;
    View view;
    uint32_t epoch = 0;
    uint32_t last_poll_log = 0;
    bool rendered = false;
    bool unloaded = false;
    bool network_page = false;
    bool network_requested = false;
    bool help_page = false;
    bool help_requested = false;
    bool legal_requested = false;
    bool legal_dirty = false;
    int legal_document = -1;
    std::size_t legal_page = 0;
    bool pin_page = false;
    bool pin_requested = false;
    bool network_list_dirty = false;
    bool redraw = false;
    bool wifi_pending = false;
    bool wifi_pending_save = false;
    uint32_t wifi_submit_revision = 0;
    int manager_scroll = 0;
    std::string forget_name;
    std::string open_name;
    std::string selected_raw_ssid, selected_ssid_label;
    std::string local_error;
};

// All Ui pointers and LVGL objects are accessed only under the LVGL lock.
// Touch virtual-key dispatch can run on touch_feed, so it uses atomic activity
// and the runtime cache/queue, never these pointers or LVGL functions.
Ui* s_current = nullptr;
std::atomic<uint32_t> s_active_epoch{0};
std::atomic<uint32_t> s_network_epoch{0};
std::atomic<uint32_t> s_network_back_epoch{0};
uint32_t s_next_epoch = 0;

bool Current(const Ui* ui) {
    return ui != nullptr && ui == s_current && !ui->unloaded &&
           ui->screen == lv_screen_active();
}

void RequestUiUpdate(Ui* ui) {
    ui->redraw = true;
    // Schedule the next LVGL timer pass; rebuilding/deleting widgets remains
    // outside the event callback currently dispatching this click.
    if (ui->timer) lv_timer_ready(ui->timer);
}

void RequestSceneChange(Ui* ui) {
    // Stop replay immediately, even if the input driver can still drain several
    // queued edges in this timer pass. Render invalidates once more before it
    // builds the replacement scene so rearming waits for that scene's frame.
    pocket_hal::InvalidateInput();
    RequestUiUpdate(ui);
}

void PlainObject(lv_obj_t* object) {
    lv_obj_remove_style_all(object);
    lv_obj_set_style_bg_color(object, lv_color_white(), 0);
    lv_obj_set_style_bg_opa(object, LV_OPA_COVER, 0);
    lv_obj_set_style_text_color(object, lv_color_black(), 0);
    lv_obj_set_style_text_opa(object, LV_OPA_COVER, 0);
    lv_obj_set_style_border_opa(object, LV_OPA_COVER, 0);
    lv_obj_set_style_opa(object, LV_OPA_COVER, 0);
    lv_obj_set_style_anim_duration(object, 0, 0);
    // No descriptor property means no transition. A present nullptr descriptor
    // is dereferenced by this LVGL version when a button gains PRESSED state.
    lv_obj_remove_local_style_prop(object, LV_STYLE_TRANSITION, 0);
    lv_obj_clear_flag(object, LV_OBJ_FLAG_SCROLLABLE);
}

lv_obj_t* Text(Ui* ui, lv_obj_t* parent, int x, int y, int width,
               const std::string& text, bool heading = false,
               bool single_line = false) {
    auto* label = lv_label_create(parent);
    lv_obj_remove_style_all(label);
    LayoutPos(label, x, y);
    LayoutWidth(label, width);
    lv_obj_set_style_text_color(label, lv_color_black(), 0);
    lv_obj_set_style_text_opa(label, LV_OPA_COVER, 0);
    lv_obj_set_style_text_font(label, heading ? ui->heading_font : ui->font, 0);
    lv_obj_set_style_text_line_space(label, 2, 0);
    lv_label_set_long_mode(label, single_line ? LV_LABEL_LONG_DOT : LV_LABEL_LONG_WRAP);
    if (single_line) LayoutHeight(label, heading ? 38 : 31);
    lv_label_set_text(label, text.c_str());
    lv_obj_clear_flag(label, LV_OBJ_FLAG_CLICKABLE);
    return label;
}

void ShowBlocking(Ui* ui, bool switching) {
    const bool created = ui->blocking_overlay == nullptr;
    if (!ui->blocking_overlay) {
        pocket_hal::InvalidateInput();
        ui->blocking_overlay = lv_obj_create(ui->screen);
        PlainObject(ui->blocking_overlay);
        LayoutPos(ui->blocking_overlay, 0, 0);
        LayoutSize(ui->blocking_overlay, kWidth, kHeight);
        lv_obj_add_flag(ui->blocking_overlay, LV_OBJ_FLAG_CLICKABLE);
        ui->blocking_label = Text(ui, ui->blocking_overlay, 24, 350, 432, "", true);
        lv_obj_set_style_text_align(ui->blocking_label, LV_TEXT_ALIGN_CENTER, 0);
    }
    if (created || ui->blocking_switching != switching) {
        lv_label_set_text(ui->blocking_label,
            switching ? "固件切换中，请稍后" : "正在准备设备与存储，请稍后");
        ui->blocking_switching = switching;
    }
    lv_obj_move_foreground(ui->blocking_overlay);
    if (ui->wifi_icon) lv_obj_move_foreground(ui->wifi_icon);
    if (ui->battery_icon) lv_obj_move_foreground(ui->battery_icon);
}

bool KnownWifi(const View& view, const std::string& ssid) {
    return std::find(view.wifi_names.begin(), view.wifi_names.end(), ssid) != view.wifi_names.end();
}
std::string NetworkName(const Ui* ui) {
    const std::string text=ui->ssid?lv_textarea_get_text(ui->ssid):"";
    return !ui->selected_raw_ssid.empty() && text==ui->selected_ssid_label ? ui->selected_raw_ssid : text;
}

int SignalLevel(int rssi) {
    return rssi >= -55 ? 4 : rssi >= -67 ? 3 : rssi >= -78 ? 2 : 1;
}

bool SameAccessPoints(const View& a, const View& b) {
    const auto& left = a.wifi_connection.access_points;
    const auto& right = b.wifi_connection.access_points;
    if (left.size() != right.size()) return false;
    for (size_t i = 0; i < left.size(); ++i)
        if (left[i].ssid != right[i].ssid || left[i].secured != right[i].secured ||
            SignalLevel(left[i].rssi) != SignalLevel(right[i].rssi)) return false;
    return true;
}

void UpdateWifiIcon(Ui* ui, const View& view) {
    if (!ui->wifi_icon) return;
    const bool connected = view.wifi_connection.connected;
    const int level = connected ? std::max(1, std::min(4, view.wifi_connection.signal_bars)) : 0;
    // Only signal-band or connection changes redraw the e-paper status graphic.
    if (level != ui->wifi_icon_level || connected != ui->wifi_icon_connected) {
        for (size_t i = 0; i < ui->wifi_bars.size(); ++i)
            lv_obj_set_style_bg_color(ui->wifi_bars[i],
                static_cast<int>(i) < level ? lv_color_black() : lv_color_white(), 0);
        if (connected) lv_obj_add_flag(ui->wifi_disconnected, LV_OBJ_FLAG_HIDDEN);
        else lv_obj_remove_flag(ui->wifi_disconnected, LV_OBJ_FLAG_HIDDEN);
        ui->wifi_icon_level = level;
        ui->wifi_icon_connected = connected;
    }
    // Modals and the full-screen switch message keep the same truthful icon.
    lv_obj_move_foreground(ui->wifi_icon);
}

void BuildWifiIcon(Ui* ui) {
    ui->wifi_icon = lv_obj_create(ui->screen);
    PlainObject(ui->wifi_icon);
    LayoutPos(ui->wifi_icon, kWifiX, 10);
    LayoutSize(ui->wifi_icon, kWifiWidth, 44);
    lv_obj_clear_flag(ui->wifi_icon, LV_OBJ_FLAG_CLICKABLE);
    for (size_t i = 0; i < ui->wifi_bars.size(); ++i) {
        const int height = 9 + static_cast<int>(i) * 7;
        auto* bar = lv_obj_create(ui->wifi_icon);
        PlainObject(bar);
        LayoutPos(bar, 2 + static_cast<int>(i) * 9, 36 - height);
        LayoutSize(bar, 6, height);
        lv_obj_set_style_border_width(bar, 1, 0);
        lv_obj_set_style_border_color(bar, lv_color_black(), 0);
        lv_obj_clear_flag(bar, LV_OBJ_FLAG_CLICKABLE);
        ui->wifi_bars[i] = bar;
    }
    static const lv_point_precise_t disconnected_points[] = {{0, 0}, {PxX(34), PxY(28)}};
    ui->wifi_disconnected = lv_line_create(ui->wifi_icon);
    lv_obj_remove_style_all(ui->wifi_disconnected);
    LayoutPos(ui->wifi_disconnected, 1, 7);
    lv_line_set_points(ui->wifi_disconnected, disconnected_points, 2);
    lv_obj_set_style_line_width(ui->wifi_disconnected, 3, 0);
    lv_obj_set_style_line_color(ui->wifi_disconnected, lv_color_black(), 0);
    lv_obj_set_style_line_opa(ui->wifi_disconnected, LV_OPA_COVER, 0);
    lv_obj_clear_flag(ui->wifi_disconnected, LV_OBJ_FLAG_CLICKABLE);
}

void BuildBatteryIcon(Ui* ui) {
    // Hand-drawn monochrome icon: no extra font or image resource required.
    ui->battery_icon = lv_obj_create(ui->screen);
    PlainObject(ui->battery_icon);
    LayoutPos(ui->battery_icon, kBatteryX, 22);
    LayoutSize(ui->battery_icon, kBatteryWidth, 20);
    lv_obj_clear_flag(ui->battery_icon, LV_OBJ_FLAG_CLICKABLE);
    auto* outline = lv_obj_create(ui->battery_icon);
    PlainObject(outline);
    LayoutPos(outline, 0, 0);
    LayoutSize(outline, 32, 20);
    lv_obj_set_style_border_width(outline, 1, 0);
    lv_obj_set_style_border_color(outline, lv_color_black(), 0);
    lv_obj_set_style_radius(outline, 2, 0);
    lv_obj_clear_flag(outline, LV_OBJ_FLAG_CLICKABLE);
    auto* terminal = lv_obj_create(ui->battery_icon);
    PlainObject(terminal);
    LayoutPos(terminal, 32, 6);
    LayoutSize(terminal, 3, 8);
    lv_obj_set_style_bg_color(terminal, lv_color_black(), 0);
    lv_obj_clear_flag(terminal, LV_OBJ_FLAG_CLICKABLE);
    // Private 18px digits fit 100 inside the small scaled battery body.
    ui->battery_number = Text(ui, ui->battery_icon, 1, 2, 30, "--", false, true);
    lv_obj_set_style_text_font(ui->battery_number, pocket_font::Get(18), 0);
    lv_obj_set_style_text_line_space(ui->battery_number, 0, 0);
    LayoutHeight(ui->battery_number, 16);
    lv_obj_set_style_text_align(ui->battery_number, LV_TEXT_ALIGN_CENTER, 0);
}

void UpdateBatteryIcon(Ui* ui, const View& view) {
    if (!ui->battery_icon) return;
    const int level = view.battery_level >= 0 && view.battery_level <= 100 ? view.battery_level : -1;
    if (level != ui->battery_displayed) {
        const std::string number = level < 0 ? "--" : std::to_string(level);
        lv_label_set_text(ui->battery_number, number.c_str());
        ui->battery_displayed = level;
    }
    lv_obj_move_foreground(ui->battery_icon);
}

bool CanInstall(const View& view, int index, const std::string& id,
                const std::string& version) {
    return ui_policy::CanInstall(view,index,id,version);
}

bool CanResume(const View& view) {
    return view.ready && !view.busy && !view.switching && view.manager &&
           view.storage_ok && !view.usb_active && view.resume_available &&
           !view.resume_run_id.empty() && !view.resume_package.id.empty() &&
           !view.resume_package.exit_hint.empty();
}

bool CanConfirmInstall(const View& view, const Ui* ui) {
    if (ui->install_restart) {
        return ui_policy::CanRestartPackage(view, ui->install_index, ui->install_id, ui->install_version) &&
               ui_policy::SamePackage(view.packages[ui->install_index], ui->install_package);
    }
    if (ui->install_resume) {
        const auto& current = view.resume_package;
        const auto& displayed = ui->install_package;
        return CanResume(view) && view.resume_run_id == ui->resume_run_id &&
               ui_policy::SamePackage(current, displayed);
    }
    if (!CanInstall(view, ui->install_index, ui->install_id, ui->install_version)) return false;
    const auto& current = view.packages[ui->install_index];
    const auto& displayed = ui->install_package;
    return ui_policy::SamePackage(current, displayed);
}

bool CanAskRestart(const View& view, const Ui* ui) {
    return ui->install_details_only &&
           ui_policy::CanRestartPackage(view, ui->install_index, ui->install_id, ui->install_version) &&
           ui_policy::SamePackage(view.packages[ui->install_index], ui->install_package);
}

void FocusNetworkInput(Ui* ui, lv_obj_t* input) {
    if (ui->ssid) lv_obj_remove_state(ui->ssid, LV_STATE_FOCUSED);
    if (ui->password) lv_obj_remove_state(ui->password, LV_STATE_FOCUSED);
    if (input) lv_obj_add_state(input, LV_STATE_FOCUSED);
    pocket_ime::SetTarget(ui->keyboard, input, input == ui->ssid);
}

bool IsPinAction(Action action) {
    return action == Action::PinKey || action == Action::PinSubmit ||
           action == Action::PinRetry || action == Action::PinInk;
}

void FocusPinInput(Ui* ui, int index) {
    if (index < 0 || index >= static_cast<int>(ui->pin_inputs.size()) || !ui->pin_inputs[index]) return;
    ui->pin_focus = index;
    for (size_t i = 0; i < ui->pin_inputs.size(); ++i) {
        if (!ui->pin_inputs[i]) continue;
        if (static_cast<int>(i) == index) lv_obj_add_state(ui->pin_inputs[i], LV_STATE_FOCUSED);
        else lv_obj_remove_state(ui->pin_inputs[i], LV_STATE_FOCUSED);
    }
}

bool ValidPinInput(const std::string& pin) {
    return pin.size() >= 4 && pin.size() <= 8 &&
           std::all_of(pin.begin(), pin.end(), [](char c) { return c >= '0' && c <= '9'; });
}

void OnButton(lv_event_t* event) {
    auto* ui = s_current;
    if (!Current(ui) ||
        lv_obj_get_screen(static_cast<lv_obj_t*>(lv_event_get_target(event))) != ui->screen) return;
    auto* button = static_cast<Button*>(lv_event_get_user_data(event));
    if (button == nullptr || !button->allowed || ui->view.busy || !ui->view.ready) return;
    const View latest = Snapshot();
    if (latest.busy || latest.switching || !latest.ready) return;
    // The runtime enforces the same gate. An old callback or hardware event
    // cannot reach the list, USB, Wi-Fi or settings while wake unlock is due.
    if (latest.auth_required && !IsPinAction(button->action)) return;
    if ((ui->install_index >= 0 || ui->install_resume) && button->action != Action::ConfirmInstall &&
        button->action != Action::CancelInstall && button->action != Action::AskRestart) return;
    if (ui->deep_sleep_requested && button->action != Action::DismissDeepSleep) return;
    // A digit changes the existing textarea, not the page layout. Let LVGL
    // invalidate that text directly instead of walking every button and copying
    // the whole application list through Render for each accepted digit.
    if (button->action != Action::PinKey) RequestUiUpdate(ui);
    if (button->action != Action::Runtime) {
        switch (button->action) {
        case Action::DeepSleepInfo:
            RequestSceneChange(ui);
            ui->deep_sleep_requested = true;
            return;
        case Action::DismissDeepSleep:
            RequestSceneChange(ui);
            ui->deep_sleep_requested = false;
            return;
        case Action::Ink:
        case Action::PinInk:
            pocket_hal::RequestFullRefresh();
            return;
        case Action::OpenPin:
            if (!latest.manager || latest.usb_active) return;
            RequestSceneChange(ui);
            ui->pin_requested = true;
            ui->network_requested = ui->help_requested = false;
            ui->pin_pending = false;
            break;
        case Action::BackPin:
            RequestSceneChange(ui);
            ui->pin_requested = false;
            ui->pin_pending = false;
            break;
        case Action::PinKey: {
            if (!latest.pin_ready || ui->pin_pending) return;
            auto* input = ui->pin_inputs[ui->pin_focus];
            if (!input) return;
            if (button->value == "clear") lv_textarea_set_text(input, "");
            else if (button->value == "back") lv_textarea_delete_char(input);
            else if (button->value.size() == 1 && button->value[0] >= '0' && button->value[0] <= '9')
                lv_textarea_add_text(input, button->value.c_str());
            if (!ui->local_error.empty()) {
                ui->local_error.clear();
                RequestUiUpdate(ui);
            }
            return;
        }
        case Action::PinRetry:
            if (!Post(Command::Refresh)) ui->local_error = "暂未开始检查，请稍后重试。";
            else ui->local_error.clear();
            return;
        case Action::PinSubmit: {
            if (!latest.pin_ready || ui->pin_pending || !ui->pin_inputs[0]) return;
            const std::string current = lv_textarea_get_text(ui->pin_inputs[0]);
            if (!ValidPinInput(current)) {
                ui->local_error = "请输入 4 至 8 位数字密码。";
                return;
            }
            bool queued = false;
            if (latest.auth_required) queued = PostUnlockPin(current);
            else if (ui->pin_inputs[1] && ui->pin_inputs[2]) {
                const std::string next = lv_textarea_get_text(ui->pin_inputs[1]);
                const std::string confirm = lv_textarea_get_text(ui->pin_inputs[2]);
                if (!ValidPinInput(next) || !ValidPinInput(confirm)) {
                    ui->local_error = "新密码须为 4 至 8 位数字。";
                    return;
                }
                if (next != confirm) {
                    ui->local_error = "两次新密码不一致，请重新输入。";
                    return;
                }
                queued = PostChangePin(current, next, confirm);
            }
            if (!queued) {
                ui->local_error = "暂未提交，请稍后重试。";
                return;
            }
            ui->pin_pending = true;
            ui->pin_submit_revision = latest.pin_revision;
            ui->local_error.clear();
            return;
        }
        case Action::OpenHelp:
            RequestSceneChange(ui);
            ui->help_requested = true;
            ui->legal_requested = false;
            ui->legal_dirty = true;
            break;
        case Action::BackHelp:
            RequestSceneChange(ui);
            ui->help_requested = false;
            ui->legal_requested = false;
            ui->legal_dirty = true;
            break;
        case Action::OpenLegal:
            RequestSceneChange(ui);
            ui->legal_requested = ui->legal_dirty = true;
            ui->legal_document = -1;
            ui->legal_page = 0;
            break;
        case Action::LegalDocument:
            if (button->argument < 0 || static_cast<std::size_t>(button->argument) >= pocket_legal::DocumentCount()) return;
            RequestSceneChange(ui);
            ui->legal_document = button->argument;
            ui->legal_page = 0;
            ui->legal_dirty = true;
            break;
        case Action::LegalPrevious:
        case Action::LegalNext: {
            if (ui->legal_document < 0) return;
            const auto pages = pocket_legal::PageCount(static_cast<std::size_t>(ui->legal_document));
            if (button->action == Action::LegalPrevious && ui->legal_page > 0) --ui->legal_page;
            else if (button->action == Action::LegalNext && ui->legal_page + 1 < pages) ++ui->legal_page;
            else return;
            RequestSceneChange(ui);
            ui->legal_dirty = true;
            break;
        }
        case Action::BackLegal:
            RequestSceneChange(ui);
            if (ui->legal_document >= 0) ui->legal_document = -1;
            else ui->legal_requested = false;
            ui->legal_page = 0;
            ui->legal_dirty = true;
            break;
        case Action::CancelInstall:
            // The next timer tick removes the overlay, never this callback.
            RequestSceneChange(ui);
            ui->install_index = -1;
            ui->install_resume = false;
            ui->install_restart = false;
            return;
        case Action::PackageDetails: {
            const auto i = static_cast<size_t>(button->argument);
            if (button->argument < 0 || i >= ui->view.packages.size() || i >= latest.packages.size() ||
                !ui_policy::SamePackage(ui->view.packages[i], latest.packages[i])) {
                ui->local_error = "应用列表已经更新，请重新查看。";
                return;
            }
            ui->install_index = button->argument;
            ui->install_details_only = true;
            ui->install_resume = false;
            ui->install_restart = false;
            ui->install_id = latest.packages[i].id;
            ui->install_version = latest.packages[i].version;
            ui->install_name = latest.packages[i].name;
            ui->install_detail = latest.packages[i].detail;
            ui->install_package = latest.packages[i];
            RequestSceneChange(ui);
            break;
        }
        case Action::AskRestart:
            if (!CanAskRestart(latest, ui)) {
                ui->local_error = "应用或设备状态已经改变，请重新检查后再切换。";
                return;
            }
            // Keep the exact package shown in the reason dialog. The second
            // confirmation and worker both reject a changed run or image.
            ui->install_details_only = false;
            ui->install_restart = true;
            ui->install_dialog_rebuild = true;
            RequestSceneChange(ui);
            break;
        case Action::ConfirmInstall:
            RequestSceneChange(ui);
            if (ui->install_details_only ||
                !CanConfirmInstall(latest, ui)) {
                ui->install_index = -1;
                ui->install_resume = false;
                ui->install_restart = false;
                ui->local_error = "应用或设备状态已经改变，请重新检查后再切换。";
                return;
            }
            if (!(ui->install_restart ? PostRestartPackage(ui->install_index, ui->install_package) :
                  Post(ui->install_resume ? Command::ResumeApplication : Command::InstallAndLaunch,
                       ui->install_resume ? 0 : ui->install_index))) {
                ui->install_index = -1;
                ui->install_resume = false;
                ui->install_restart = false;
                ui->local_error = "切换暂未提交，请稍后重试。";
                return;
            }
            ui->install_index = -1;
            ui->install_resume = false;
            ui->install_restart = false;
            ShowBlocking(ui, true);
            break;
        case Action::OpenWifi:
            RequestSceneChange(ui);
            ui->network_requested = true;
            if (!Post(Command::WifiScan)) {
                ui->local_error = "暂未开始搜索，请进入后点“搜索 Wi-Fi”。";
                return;
            }
            break;
        case Action::Back:
            RequestSceneChange(ui);
            ui->network_requested = false;
            break;
        case Action::SelectWifi:
            ui->selected_raw_ssid = button->value;
            ui->selected_ssid_label = wifi_detail::SafeSsidLabel(button->value);
            lv_textarea_set_max_length(ui->ssid, 128);
            lv_textarea_set_text(ui->ssid, ui->selected_ssid_label.c_str());
            lv_textarea_set_text(ui->password, "");
            FocusNetworkInput(ui, ui->password);
            break;
        case Action::AskForget:
            RequestSceneChange(ui);
            ui->forget_name = button->value;
            ui->open_name.clear();
            ui->network_list_dirty = true;
            break;
        case Action::CancelForget:
            RequestSceneChange(ui);
            ui->forget_name.clear();
            ui->open_name.clear();
            ui->network_list_dirty = true;
            break;
        case Action::WifiSave:
        case Action::ConfirmOpen: {
            if (!latest.wifi_ready) return;
            const std::string ssid = NetworkName(ui);
            const std::string password = lv_textarea_get_text(ui->password);
            if (ssid.empty() || ssid.size() > 32 || password.size() > 64) {
                ui->local_error = "网络名称须为 1 至 32 字节，密码最多 64 字节。";
                return;
            }
            const bool use_saved = button->action == Action::WifiSave && password.empty() && KnownWifi(latest, ssid);
            if (button->action == Action::WifiSave && password.empty() && !use_saved) {
                const auto& points = latest.wifi_connection.access_points;
                const auto point = std::find_if(points.begin(), points.end(), [&](const WifiAccessPoint& item) {
                    return item.ssid == ssid;
                });
                if (point != points.end() && point->secured) {
                    ui->local_error = "此网络需要密码，请输入后再连接。";
                    return;
                }
                ui->open_name = ssid;
                RequestSceneChange(ui);
                ui->forget_name.clear();
                ui->network_list_dirty = true;
                ui->local_error.clear();
                return;
            }
            if (button->action == Action::ConfirmOpen &&
                (ui->open_name != ssid || !password.empty())) {
                RequestSceneChange(ui);
                ui->open_name.clear();
                ui->network_list_dirty = true;
                ui->local_error = "输入已经改变，请重新点击连接。";
                return;
            }
            if (!(use_saved ? PostWifiConnectSaved(ssid) : PostWifiSave(ssid, password))) {
                ui->local_error = "连接暂未提交，输入仍保留，请稍后重试。";
                return;
            }
            ui->wifi_pending = true;
            ui->wifi_pending_save = !use_saved;
            ui->wifi_submit_revision = latest.revision;
            break;
        }
        case Action::Forget:
            if (!latest.wifi_ready || ui->forget_name.empty()) return;
            if (!PostWifiForget(ui->forget_name)) {
                ui->local_error = "忘记网络暂未提交，请稍后重试。";
                return;
            }
            ui->wifi_pending = true;
            ui->wifi_pending_save = false;
            ui->wifi_submit_revision = latest.revision;
            break;
        default: break;
        }
        ui->local_error.clear();
        return;
    }
    if (button->command == Command::InstallAndLaunch) {
        const auto i = static_cast<size_t>(button->argument);
        if (button->argument < 0 || i >= ui->view.packages.size() ||
            !CanInstall(latest, button->argument, ui->view.packages[i].id,
                        ui->view.packages[i].version)) {
            ui->local_error = "应用列表已经更新，请核对后重新点击。";
            lv_label_set_text(ui->notice, ui->local_error.c_str());
            return;
        }
        ui->install_index = button->argument;
        ui->install_details_only = false;
        ui->install_resume = false;
        ui->install_restart = false;
        ui->install_id = latest.packages[i].id;
        ui->install_version = latest.packages[i].version;
        ui->install_name = latest.packages[i].name;
        ui->install_package = latest.packages[i];
        ui->local_error.clear();
        RequestSceneChange(ui);
        return; // Only the modal's explicit confirmation may queue installation.
    }
    if (button->command == Command::ResumeApplication) {
        if (!CanResume(latest)) {
            ui->local_error = "恢复信息已经改变，请重新检查。";
            return;
        }
        ui->install_index = -1;
        ui->install_details_only = false;
        ui->install_resume = true;
        ui->install_restart = false;
        ui->resume_run_id = latest.resume_run_id;
        ui->install_id = latest.resume_package.id;
        ui->install_version = latest.resume_package.version;
        ui->install_name = latest.resume_package.name;
        ui->install_package = latest.resume_package;
        ui->local_error.clear();
        RequestSceneChange(ui);
        return; // Restoring the retained application also requires explicit confirmation.
    }
    // The runtime validates the command again. Post only queues work and never
    // changes/deletes any UI object while this event is being dispatched.
    if (!Post(button->command, button->argument)) {
        ui->local_error = "操作暂未提交，请稍后重试。当前内容仍保留。";
        lv_label_set_text(ui->notice, ui->local_error.c_str());
    } else {
        ui->local_error.clear();
        if (button->command == Command::ReturnToManager) ShowBlocking(ui, true);
    }
}

lv_obj_t* AddButton(Ui* ui, lv_obj_t* parent, int x, int y, int width,
                    int height, const char* label_text, Command command,
                    int argument = 0, bool allowed = true,
                    Action action = Action::Runtime, const std::string& value = {},
                    bool wifi_list = false, bool pin_list = false) {
    auto* object = lv_button_create(parent);
    PlainObject(object);
    LayoutPos(object, x, y);
    LayoutSize(object, width, height);
    lv_obj_set_style_radius(object, 5, 0);
    lv_obj_set_style_border_color(object, lv_color_black(), 0);
    lv_obj_set_style_border_width(object, 2, 0);
    lv_obj_set_style_border_width(object, 2, LV_STATE_DISABLED);
    // HAL acknowledges each admitted physical Down once. LVGL must not add a
    // second pulse; keep the ink stable while pressed/released.
    lv_obj_set_style_bg_color(object, lv_color_white(), LV_STATE_PRESSED);
    lv_obj_set_style_text_color(object, lv_color_black(), LV_STATE_PRESSED);
    lv_obj_remove_local_style_prop(object, LV_STYLE_TRANSITION, LV_STATE_PRESSED);
    lv_obj_set_style_text_font(object, ui->font, 0);
    // No theme styles remain, so press/release has no fade or scale animation.
    auto* label = lv_label_create(object);
    lv_obj_remove_style_all(label);
    LayoutWidth(label, width - 12);
    lv_obj_set_style_text_align(label, LV_TEXT_ALIGN_CENTER, 0);
    lv_obj_set_style_text_font(label, ui->font, 0);
    lv_label_set_long_mode(label, LV_LABEL_LONG_WRAP);
    lv_label_set_text(label, label_text);
    lv_obj_center(label);
    lv_obj_clear_flag(label, LV_OBJ_FLAG_CLICKABLE);
    auto& buttons = action == Action::DismissDeepSleep ? ui->deep_sleep_buttons :
                    pin_list ? ui->pin_buttons : parent == ui->screen ? ui->header_buttons :
                    (action == Action::ConfirmInstall || action == Action::CancelInstall ||
                     action == Action::AskRestart) ?
                    ui->modal_buttons : wifi_list ? ui->wifi_buttons : ui->buttons;
    buttons.push_back(Button{object, command, argument, allowed, action, value});
    lv_obj_add_event_cb(object, OnButton, LV_EVENT_CLICKED, &buttons.back());
    return object;
}

lv_obj_t* LocalButton(Ui* ui, lv_obj_t* parent, int x, int y, int width,
                      int height, const char* text, Action action,
                      const std::string& value = {}, bool wifi_list = false, bool pin_list = false) {
    return AddButton(ui, parent, x, y, width, height, text, Command::Refresh,
                     0, true, action, value, wifi_list, pin_list);
}

void OnPinInputFocus(lv_event_t* event) {
    auto* ui = static_cast<Ui*>(lv_event_get_user_data(event));
    if (!Current(ui) || ui->view.busy || ui->pin_pending) return;
    auto* input = static_cast<lv_obj_t*>(lv_event_get_target(event));
    for (size_t i = 0; i < ui->pin_inputs.size(); ++i) {
        if (input == ui->pin_inputs[i]) {
            FocusPinInput(ui, static_cast<int>(i));
            return;
        }
    }
}

void BuildPinControls(Ui* ui, lv_obj_t* parent, const View& view, bool unlock) {
    ui->pin_inputs.fill(nullptr);
    ui->pin_focus = 0;
    ui->pin_pending = false;
    Text(ui, parent, 0, 0, kContentWidth,
         unlock ? (view.pin_is_default ? "请输入唤醒密码。默认密码为 1234。" : "请输入唤醒密码，解锁固件口袋。") :
                  "仅用于口袋深度休眠唤醒。\n4 至 8 位数字；普通锁屏不用密码。");
    const char* labels[] = {unlock ? "唤醒密码" : "当前密码", "新密码", "重复新密码"};
    const int count = unlock ? 1 : 3;
    for (int i = 0; i < count; ++i) {
        const int y = 76 + i * 60;
        Text(ui, parent, 0, y + 11, 140, labels[i], false, true);
        auto* input = lv_textarea_create(parent);
        PlainObject(input);
        LayoutPos(input, 146, y);
        LayoutSize(input, 302, 50);
        lv_obj_set_style_border_width(input, 2, 0);
        lv_obj_set_style_border_color(input, lv_color_black(), 0);
        lv_obj_set_style_border_width(input, 4, LV_STATE_FOCUSED);
        lv_obj_set_style_pad_all(input, 8, 0);
        lv_obj_set_style_text_font(input, ui->font, 0);
        // This page intentionally has no IME target, Latin keyboard or symbols.
        lv_textarea_set_one_line(input, true);
        lv_textarea_set_accepted_chars(input, "0123456789");
        lv_textarea_set_max_length(input, 8);
        lv_textarea_set_password_mode(input, true);
        lv_textarea_set_password_show_time(input, 0);
        lv_textarea_set_password_bullet(input, "*");
        lv_obj_set_style_bg_opa(input, LV_OPA_TRANSP, LV_PART_CURSOR);
        lv_obj_set_style_anim_duration(input, 0, LV_PART_CURSOR);
        lv_obj_add_event_cb(input, OnPinInputFocus, LV_EVENT_CLICKED, ui);
        ui->pin_inputs[i] = input;
    }
    ui->pin_status = Text(ui, parent, 0, unlock ? 150 : 248, kContentWidth, "", false, !unlock);
    LayoutHeight(ui->pin_status, unlock ? 116 : 31);
    static const char* keys[] = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "清空", "0", "退格"};
    for (int i = 0; i < 12; ++i) {
        const std::string value = i == 9 ? "clear" : i == 11 ? "back" : keys[i];
        LocalButton(ui, parent, (i % 3) * 154, 286 + (i / 3) * 64,
                    140, 56, keys[i], Action::PinKey, value, false, unlock);
    }
    LocalButton(ui, parent, 0, 554, 214, 52,
                unlock ? "重新检查" : "返回口袋", unlock ? Action::PinRetry : Action::BackPin,
                {}, false, unlock);
    LocalButton(ui, parent, 230, 554, 218, 52,
                unlock ? "解锁" : "保存密码", Action::PinSubmit, {}, false, unlock);
    FocusPinInput(ui, 0);
}

void UpdatePinControls(Ui* ui, const View& view) {
    if (!ui->pin_status) return;
    if (ui->pin_pending && view.pin_revision != ui->pin_submit_revision && !view.busy) {
        ui->pin_pending = false;
        // Do not keep a submitted password displayed after the worker replies.
        for (auto* input : ui->pin_inputs) if (input) lv_textarea_set_text(input, "");
        FocusPinInput(ui, 0);
    }
    std::string text = !ui->local_error.empty() ? ui->local_error :
                       ui->pin_pending ? "正在检查，请稍候。" : view.pin_message;
    if (text.empty() && !view.pin_ready) text = "密码记录不可用，请检查 TF 卡后重试。";
    if (text != lv_label_get_text(ui->pin_status)) lv_label_set_text(ui->pin_status, text.c_str());
    for (auto* input : ui->pin_inputs) {
        if (!input) continue;
        if (view.busy || !view.pin_ready || ui->pin_pending) lv_obj_add_state(input, LV_STATE_DISABLED);
        else lv_obj_remove_state(input, LV_STATE_DISABLED);
    }
}

void UpdatePinOverlay(Ui* ui, const View& view) {
    if (!view.ready || !view.auth_required) {
        if (ui->pin_overlay) {
            pocket_hal::InvalidateInput();
            lv_obj_delete(ui->pin_overlay);
            ui->pin_overlay = nullptr;
            ui->pin_status = nullptr;
            ui->pin_inputs.fill(nullptr);
            ui->pin_buttons.clear();
            ui->pin_pending = false;
        }
        return;
    }
    if (!ui->pin_overlay) {
        pocket_hal::InvalidateInput();
        ui->pin_overlay = lv_obj_create(ui->screen);
        PlainObject(ui->pin_overlay);
        LayoutPos(ui->pin_overlay, 0, 0);
        LayoutSize(ui->pin_overlay, kWidth, kHeight);
        lv_obj_add_flag(ui->pin_overlay, LV_OBJ_FLAG_CLICKABLE);
        Text(ui, ui->pin_overlay, 16, 14, kTitleWidth, "唤醒解锁", true, true);
        LocalButton(ui, ui->pin_overlay, kInkX, 10, kInkWidth, 44,
                    "研墨", Action::PinInk, {}, false, true);
        Text(ui, ui->pin_overlay, 16, 63, kContentWidth,
             "仅解锁固件口袋，不改变其他固件。", false, true);
        auto* content = lv_obj_create(ui->pin_overlay);
        PlainObject(content);
        LayoutPos(content, 16, 110);
        LayoutSize(content, kContentWidth, 622);
        BuildPinControls(ui, content, view, true);
    }
    UpdatePinControls(ui, view);
    lv_obj_move_foreground(ui->pin_overlay);
}

void UpdateDeepSleepDialog(Ui* ui, const View& view) {
    if (!view.ready || view.switching || view.auth_required || !view.manager ||
        ui->install_index >= 0 || ui->install_resume) ui->deep_sleep_requested = false;
    if (!ui->deep_sleep_requested) {
        if (ui->deep_sleep_overlay) {
            pocket_hal::InvalidateInput();
            lv_obj_delete(ui->deep_sleep_overlay);
        }
        ui->deep_sleep_overlay = nullptr;
        ui->deep_sleep_buttons.clear();
        return;
    }
    if (!ui->deep_sleep_overlay) {
        pocket_hal::InvalidateInput();
        // The opaque clickable parent intercepts touches outside the card.
        // Closing only changes state; this timer-owned function deletes it.
        ui->deep_sleep_overlay = lv_obj_create(ui->screen);
        PlainObject(ui->deep_sleep_overlay);
        LayoutPos(ui->deep_sleep_overlay, 0, 0);
        LayoutSize(ui->deep_sleep_overlay, kWidth, kHeight);
        lv_obj_add_flag(ui->deep_sleep_overlay, LV_OBJ_FLAG_CLICKABLE);
        auto* card = lv_obj_create(ui->deep_sleep_overlay);
        PlainObject(card);
        LayoutPos(card, 16, 208);
        LayoutSize(card, kContentWidth, 360);
        lv_obj_set_style_border_width(card, 2, 0);
        lv_obj_set_style_border_color(card, lv_color_black(), 0);
        Text(ui, card, 18, 18, 408, "深度休眠", true);
        Text(ui, card, 18, 80, 408,
             "长按电源键 5 秒以上进入深度休眠。\n\n连续 10 分钟无操作也会自动深休，锁屏时同样有效。\n\n再长按电源键唤醒。");
        LocalButton(ui, card, 18, 290, 408, 52, "知道了", Action::DismissDeepSleep);
    }
    lv_obj_move_foreground(ui->deep_sleep_overlay);
}

void UpdateInstallDialog(Ui* ui, const View& view) {
    if (ui->install_dialog_rebuild) {
        // Rebuild only on the LVGL timer, after the event callback has returned.
        if (ui->install_overlay) {
            pocket_hal::InvalidateInput();
            lv_obj_delete(ui->install_overlay);
        }
        ui->install_overlay = ui->install_hint = nullptr;
        ui->modal_buttons.clear();
        ui->install_dialog_rebuild = false;
    }
    if (ui->install_index < 0 && !ui->install_resume) {
        if (ui->install_overlay) {
            pocket_hal::InvalidateInput();
            lv_obj_delete(ui->install_overlay);
        }
        ui->install_overlay = ui->install_hint = nullptr;
        ui->modal_buttons.clear();
        ui->install_id.clear();
        ui->install_version.clear();
        ui->install_name.clear();
        ui->install_detail.clear();
        ui->install_package = {};
        ui->install_details_only = false;
        ui->install_restart = false;
        ui->resume_run_id.clear();
        return;
    }
    if (!ui->install_overlay) {
        pocket_hal::InvalidateInput();
        // A full-screen clickable parent intercepts every touch outside the
        // dialog. The original list stays alive at exactly its current scroll.
        ui->install_overlay = lv_obj_create(ui->screen);
        PlainObject(ui->install_overlay);
        LayoutPos(ui->install_overlay, 0, 0);
        LayoutSize(ui->install_overlay, kWidth, kHeight);
        lv_obj_add_flag(ui->install_overlay, LV_OBJ_FLAG_CLICKABLE);
        auto* card = lv_obj_create(ui->install_overlay);
        PlainObject(card);
        LayoutPos(card, 16, 172);
        LayoutSize(card, kContentWidth, 456);
        lv_obj_set_style_border_width(card, 2, 0);
        lv_obj_set_style_border_color(card, lv_color_black(), 0);
        Text(ui, card, 18, 16, 408, ui->install_details_only ? "应用信息" :
             ui->install_restart ? "确认重新启动" : ui->install_resume ? "确认恢复" : "确认切换", true);
        auto* details = lv_obj_create(card);
        PlainObject(details);
        LayoutPos(details, 18, 66);
        const bool show_restart = ui->install_details_only && CanAskRestart(view, ui);
        LayoutSize(details, 408, show_restart ? 248 : 304);
        lv_obj_add_flag(details, LV_OBJ_FLAG_SCROLLABLE);
        lv_obj_clear_flag(details, LV_OBJ_FLAG_SCROLL_ELASTIC);
        lv_obj_clear_flag(details, LV_OBJ_FLAG_SCROLL_MOMENTUM);
        lv_obj_set_scroll_dir(details, LV_DIR_VER);
        lv_obj_set_scrollbar_mode(details, LV_SCROLLBAR_MODE_AUTO);
        lv_obj_set_style_width(details, 3, LV_PART_SCROLLBAR);
        lv_obj_set_style_bg_color(details, lv_color_black(), LV_PART_SCROLLBAR);
        auto* name = Text(ui, details, 0, 0, 398,
                          ui->install_name.empty() ? ui->install_id : ui->install_name);
        lv_obj_update_layout(name);
        const int version_y = LogicalHeight(name) + 8;
        auto* version = Text(ui, details, 0, version_y, 398, "版本：" + ui->install_version);
        if (ui->install_details_only) {
            lv_obj_update_layout(version);
            Text(ui, details, 0, version_y + LogicalHeight(version) + 12, 398,
                 ui->install_detail.empty() ? "此应用暂不能切换，请重新检查。" : ui->install_detail);
            if (show_restart)
                LocalButton(ui, card, 18, 336, 408, 48, "解除限制并重新启动", Action::AskRestart);
            LocalButton(ui, card, 18, 392, 408, 48, "返回列表", Action::CancelInstall);
        } else {
            lv_obj_update_layout(version);
            ui->install_hint = Text(ui, details, 0, version_y + LogicalHeight(version) + 12, 398, "");
            LocalButton(ui, card, 18, 392, 196, 48, "取消", Action::CancelInstall);
            LocalButton(ui, card, 230, 392, 196, 48,
                        ui->install_restart ? "确认重新启动" :
                        ui->install_resume ? "确认恢复" : "确认切换", Action::ConfirmInstall);
        }
    }
    if (ui->install_hint) {
        const auto& package = ui->install_package;
        std::string hint = "退出：" + package.exit_hint + "\n\n";
        if (ui->install_restart)
            hint = "重新启动将放弃上次未完成的运行；未保存进度可能丢失，已保存的 TF 文件保留。"
                   "此操作不会清理 TF 文件。\n\n" + hint;
        if (ui->install_resume) {
            hint += "恢复设备中保留的上次应用；不会重新写入固件。请按上述退出方式完成保存并返回口袋。";
        } else switch (package.storage_mode) {
        case 0: hint += "存档：此应用无需保留记录，每次从初始状态开始。"; break;
        case 1: hint += "存档：应用退出前将必要记录存入 TF，再次切入时由应用恢复。"; break;
        case 2: hint += "存档：应用保存到原有 TF 文件，切换时不重复复制。"; break;
        default: hint += "存档方式未识别，请取消。"; break;
        }
        if (!ui->install_restart) hint+=ui_policy::UnfinishedSwitchWarning(view,ui->install_resume);
        if (!CanConfirmInstall(view, ui)) hint += "\n\n当前状态已改变，请取消后重新检查。";
        if (hint != lv_label_get_text(ui->install_hint)) lv_label_set_text(ui->install_hint, hint.c_str());
    }
}

bool SamePackages(const std::vector<PackageView>& a, const std::vector<PackageView>& b) {
    if (a.size() != b.size()) return false;
    for (size_t i = 0; i < a.size(); ++i) {
        if (!ui_policy::SamePackage(a[i], b[i])) return false;
    }
    return true;
}

bool SameBody(const View& a, const View& b) {
    return a.ready == b.ready && a.manager == b.manager && a.integrated == b.integrated &&
           a.handoff_blocked == b.handoff_blocked && a.resume_available == b.resume_available &&
           a.resume_run_id == b.resume_run_id && a.resume_package.id == b.resume_package.id &&
           a.resume_package.version == b.resume_package.version && a.resume_package.name == b.resume_package.name &&
           a.resume_package.storage_mode == b.resume_package.storage_mode &&
           a.resume_package.exit_method == b.resume_package.exit_method &&
           a.resume_package.exit_hint == b.resume_package.exit_hint &&
           a.usb_active == b.usb_active && a.app_id == b.app_id &&
           a.user_id == b.user_id && a.counter == b.counter && a.bookmark == b.bookmark &&
           a.note == b.note && a.preference == b.preference && SamePackages(a.packages, b.packages);
}

std::string UserLine(const View& view) {
    return "用户：" + (view.user_id.empty() ? std::string("等待读取") : view.user_id);
}

std::string ScanLine(const View& view) {
    if (view.usb_active) return "TF 卡由电脑占用，列表未刷新";
    if (!view.storage_ok) return "TF 卡不可用，列表未刷新";
    if (view.scan_running) {
        if (view.scan_total == 0) return "固件列表刷新中：正在读取";
        return "固件列表刷新中：" + std::to_string(view.scan_done) + " / " + std::to_string(view.scan_total);
    }
    if (view.scan_complete)
        return "固件列表刷新完成（" + std::to_string(view.packages.size()) + "个）";
    if (!view.error.empty()) return "列表刷新未完成，请重新检查";
    return "列表尚未刷新，请点击刷新列表";
}

void BuildManager(Ui* ui, const View& view, int scroll_y) {
    Text(ui, ui->body, 0, 4, 292, UserLine(view), false, true);
    LocalButton(ui, ui->body, 302, 0, 146, 38, "唤醒密码", Action::OpenPin);
    ui->scan_status = Text(ui, ui->body, 0, 42, kContentWidth, ScanLine(view), false, true);
    LayoutHeight(ui->scan_status, 30);
    lv_obj_set_style_bg_color(ui->scan_status, lv_color_black(), 0);
    lv_obj_set_style_bg_opa(ui->scan_status, LV_OPA_COVER, 0);
    lv_obj_set_style_text_color(ui->scan_status, lv_color_white(), 0);
    lv_obj_set_style_pad_left(ui->scan_status, 6, 0);
    lv_obj_set_style_pad_top(ui->scan_status, 2, 0);

    auto* list = lv_obj_create(ui->body);
    PlainObject(list);
    LayoutPos(list, 0, 80);
    LayoutSize(list, kContentWidth, 434);
    lv_obj_set_style_border_width(list, 2, 0);
    lv_obj_set_style_border_color(list, lv_color_black(), 0);
    lv_obj_add_flag(list, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_clear_flag(list, LV_OBJ_FLAG_SCROLL_ELASTIC);
    lv_obj_clear_flag(list, LV_OBJ_FLAG_SCROLL_MOMENTUM);
    lv_obj_set_scroll_dir(list, LV_DIR_VER);
    lv_obj_set_scrollbar_mode(list, LV_SCROLLBAR_MODE_ON);
    lv_obj_set_style_width(list, 3, LV_PART_SCROLLBAR);
    lv_obj_set_style_bg_color(list, lv_color_black(), LV_PART_SCROLLBAR);
    lv_obj_set_style_bg_opa(list, LV_OPA_COVER, LV_PART_SCROLLBAR);
    lv_obj_set_style_pad_right(list, 2, LV_PART_SCROLLBAR);
    ui->list = list;
    if (view.usb_active) {
        Text(ui, list, 12, 14, 412,
             "TF 卡正交给电脑使用。\n复制完成后先安全弹出，再停用模拟 U 盘并刷新列表。");
    } else if (view.packages.empty()) {
        Text(ui, list, 12, 14, 412,
             "尚无可显示的部件。\n将兼容 BIN 放入 firmware-pocket/packages/，再点击“刷新列表”。");
    } else {
        int card_y = 0;
        for (size_t i = 0; i < view.packages.size(); ++i) {
            const auto& package = view.packages[i];
            auto* card = lv_obj_create(list);
            PlainObject(card);
            LayoutPos(card, 0, card_y);
            LayoutSize(card, 436, 66);
            lv_obj_set_style_border_width(card, 2, 0);
            lv_obj_set_style_border_color(card, lv_color_black(), 0);
            lv_obj_set_style_border_side(card, LV_BORDER_SIDE_BOTTOM, 0);
            Text(ui, card, 10, 3, 204,
                 package.name.empty() ? "未识别应用" : package.name, false, true);
            auto* last_used = Text(ui, card, 222, 3, 204,
                "上次 " + (package.last_used.empty() ? std::string("暂无记录") : package.last_used), false, true);
            lv_obj_set_style_text_align(last_used, LV_TEXT_ALIGN_RIGHT, 0);
            Text(ui, card, 10, 34, 238,
                 ui_policy::PackageSummary(package), false, true);
            AddButton(ui, card, 258, 31, 168, 32,
                      package.compatible ? "切换并启动" : "查看原因",
                      Command::InstallAndLaunch, static_cast<int>(i), true,
                      package.compatible ? Action::Runtime : Action::PackageDetails);
            card_y += 70;
        }
        lv_obj_update_layout(list);
        LogicalScrollTo(list, scroll_y, LV_ANIM_OFF);
    }
    AddButton(ui, ui->body, 0, 526, 214, 46, "刷新列表", Command::Refresh);
    AddButton(ui, ui->body, 230, 526, 218, 46,
              view.usb_active ? "停用模拟 U 盘" : "启用模拟 U 盘", Command::ToggleUsb);
    LocalButton(ui, ui->body, 0, 580, view.resume_available ? 140 : 214, 46,
                "Wi-Fi 连接", Action::OpenWifi);
    if (view.resume_available) {
        AddButton(ui, ui->body, 154, 580, 140, 46, "恢复应用", Command::ResumeApplication);
        LocalButton(ui, ui->body, 308, 580, 140, 46, "深度休眠", Action::DeepSleepInfo);
    } else LocalButton(ui, ui->body, 230, 580, 218, 46, "深度休眠", Action::DeepSleepInfo);
}

void BuildLegal(Ui* ui) {
    auto* content = lv_obj_create(ui->body);
    PlainObject(content);
    LayoutSize(content, kContentWidth, 490);
    lv_obj_add_flag(content, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_clear_flag(content, LV_OBJ_FLAG_SCROLL_ELASTIC);
    lv_obj_clear_flag(content, LV_OBJ_FLAG_SCROLL_MOMENTUM);
    lv_obj_set_scroll_dir(content, LV_DIR_VER);
    lv_obj_set_scrollbar_mode(content, LV_SCROLLBAR_MODE_ON);
    lv_obj_set_style_width(content, 3, LV_PART_SCROLLBAR);
    lv_obj_set_style_bg_color(content, lv_color_black(), LV_PART_SCROLLBAR);
    lv_obj_set_style_bg_opa(content, LV_OPA_COVER, LV_PART_SCROLLBAR);
    if (ui->legal_document < 0) {
        Text(ui, content, 4, 0, 424, "许可全文已内置，可离线查看。上下滑动选择文件。");
        for (std::size_t i = 0; i < pocket_legal::DocumentCount(); ++i) {
            AddButton(ui, content, 4, 68 + static_cast<int>(i) * 62, 424, 54,
                      pocket_legal::Title(i), Command::Refresh, static_cast<int>(i),
                      true, Action::LegalDocument);
        }
    } else {
        const auto document = static_cast<std::size_t>(ui->legal_document);
        Text(ui, content, 4, 0, 424, pocket_legal::Title(document), true);
        Text(ui, content, 4, 58, 424, pocket_legal::Page(document, ui->legal_page));
        char position[64];
        std::snprintf(position, sizeof(position), "%u / %u",
                      static_cast<unsigned>(ui->legal_page + 1),
                      static_cast<unsigned>(pocket_legal::PageCount(document)));
        Text(ui, ui->body, 154, 505, 140, position);
        if (ui->legal_page > 0)
            LocalButton(ui, ui->body, 0, 500, 140, 46, "上一页", Action::LegalPrevious);
        if (ui->legal_page + 1 < pocket_legal::PageCount(document))
            LocalButton(ui, ui->body, 308, 500, 140, 46, "下一页", Action::LegalNext);
    }
    LocalButton(ui, ui->body, 0, 560, kContentWidth, 54,
                ui->legal_document < 0 ? "返回帮助" : "返回目录", Action::BackLegal);
}

void BuildHelp(Ui* ui) {
    if (ui->legal_requested) {
        BuildLegal(ui);
        return;
    }
    auto* content = lv_obj_create(ui->body);
    PlainObject(content);
    LayoutSize(content, kContentWidth, 490);
    lv_obj_add_flag(content, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_clear_flag(content, LV_OBJ_FLAG_SCROLL_ELASTIC);
    lv_obj_clear_flag(content, LV_OBJ_FLAG_SCROLL_MOMENTUM);
    lv_obj_set_scroll_dir(content, LV_DIR_VER);
    lv_obj_set_scrollbar_mode(content, LV_SCROLLBAR_MODE_ON);
    lv_obj_set_style_width(content, 3, LV_PART_SCROLLBAR);
    lv_obj_set_style_bg_color(content, lv_color_black(), LV_PART_SCROLLBAR);
    lv_obj_set_style_bg_opa(content, LV_OPA_COVER, LV_PART_SCROLLBAR);
    Text(ui, content, 4, 0, 428,
         "研墨：全刷当前画面，其他操作默认快刷。\n\n"
         "口袋前台：短按电源键锁屏并熄灯，再短按恢复原页面与微光，不用密码。连续长按 5 秒进入深度休眠；再长按 5 秒唤醒，输入数字密码解锁。默认密码 1234，可在首页的“唤醒密码”中修改，保存在 TF 卡。正常页面或锁屏后连续 10 分钟无操作也会自动深休；模拟 U 盘或切换、保存期间会延后。其他固件的休眠方式由各自决定。\n\n"
         "口袋与当前运行部件存在设备内部；TF 卡保存部件 BIN 和记录。\n\n"
         "本版配套应用的同一个 BIN 可独立烧录，也可放到 TF 卡的 firmware-pocket/packages/，无需另放 TXT。例如：\n"
         "firmware-pocket/packages/my-app.bin\n\n"
         "这里只接受为 Plus / ESP32-S31 编译的兼容部件，3.97 寸设备的 BIN 不能直接使用。\n\n"
         "电脑安全弹出后，设备停用模拟 U 盘，再刷新列表。提示完成后找部件，点“切换并启动”并确认；切换中请等待。\n\n"
         "切换前请看应用声明的退出说明：页面入口或快捷键由应用提供，请按说明操作并确认。应用负责保存；无记录的应用不建存档，直接存 TF 的应用不另复制一份。勿删 firmware-pocket/shared/ 和 firmware-pocket/users/ 内的用户资料。\n\n"
         "“Wi-Fi 连接”可搜索并连接网络；右上角实心信号条表示已连接并取得 IP。应用可选择读取或推荐网络；口袋验证新网络，失败再连接原网络。plus.13 已兼容的 Plus 应用可继续使用。");
    LocalButton(ui, ui->body, 0, 500, kContentWidth, 46,
                "开源许可与隐私说明", Action::OpenLegal);
    LocalButton(ui, ui->body, 0, 560, kContentWidth, 54, "返回口袋", Action::BackHelp);
}

void BuildApplication(Ui* ui, const View& view) {
    Text(ui, ui->body, 0, 0, kContentWidth, UserLine(view));
    // This recovery entry remains available for an unreadable or unsupported
    // saved state. The worker owns remount/revalidation and preserves edits.
    AddButton(ui, ui->body, 300, 62, 148, 48, "重新检查", Command::Refresh);
    Text(ui, ui->body, 0, 66, 284,
         view.integrated ? "运行方式：固件口袋" : "运行方式：独立运行");
    LocalButton(ui, ui->body, 0, 116, 214, 44, "Wi-Fi 连接", Action::OpenWifi);
    if (view.app_id == "pocket_counter") {
        Text(ui, ui->body, 0, 171, kContentWidth,
             "当前计数：" + std::to_string(view.counter), true);
        Text(ui, ui->body, 0, 225, kContentWidth,
             "增加计数后保存。退出重进或切换应用后，核对记录是否保留。");
        AddButton(ui, ui->body, 0, 320, kContentWidth, 58,
                  "计数加一", Command::Increment);
    } else {
        static constexpr const char* kNotes[] = {
            "今天读到这里。", "记得继续练习。", "下次看看新章节。", "测试记录已更新。"};
        const auto note_index = static_cast<unsigned>(view.note) % 4U;
        Text(ui, ui->body, 0, 166, kContentWidth,
             "书签：第 " + std::to_string(view.bookmark) + " 页", true);
        Text(ui, ui->body, 0, 211, kContentWidth,
             std::string("记录：") + kNotes[note_index]);
        Text(ui, ui->body, 0, 265, kContentWidth,
             "本应用设置：" + std::to_string(view.preference));
        AddButton(ui, ui->body, 0, 310, 214, 52,
                  "书签下一页", Command::BookmarkNext);
        AddButton(ui, ui->body, 230, 310, 218, 52,
                  "切换记录", Command::NoteNext);
        AddButton(ui, ui->body, 0, 374, kContentWidth, 52,
                  "切换本应用设置", Command::PreferenceNext);
    }
    AddButton(ui, ui->body, 0, 440, kContentWidth, 52,
              "保存当前记录", Command::Save);
    AddButton(ui, ui->body, 0, 504, kContentWidth, 58,
              view.integrated ? "保存并返回固件口袋" : "保存并返回应用入口",
              Command::ReturnToManager);
}

void OnInputFocus(lv_event_t* event) {
    auto* ui = static_cast<Ui*>(lv_event_get_user_data(event));
    if (!Current(ui) || !ui->network_page || !ui->keyboard || ui->view.busy) return;
    auto* input = static_cast<lv_obj_t*>(lv_event_get_target(event));
    FocusNetworkInput(ui, input);
}

void OnNetworkNameChanged(lv_event_t* event) {
    auto* ui = static_cast<Ui*>(lv_event_get_user_data(event));
    if (!Current(ui) || !ui->network_page || !ui->ssid || !ui->password) return;
    // Never carry the previous network's typed password into a different SSID.
    if (*lv_textarea_get_text(ui->password)) lv_textarea_set_text(ui->password, "");
    if (!ui->selected_raw_ssid.empty() &&
        ui->selected_ssid_label != lv_textarea_get_text(ui->ssid)) {
        ui->selected_raw_ssid.clear(); ui->selected_ssid_label.clear();
        lv_textarea_set_max_length(ui->ssid, 32);
    }
    const bool saved = KnownWifi(ui->view, NetworkName(ui));
    const char* placeholder = saved ? "留空使用已存密码；填入可更新" : "密码（开放网络留空）";
    if (std::strcmp(lv_textarea_get_placeholder_text(ui->password), placeholder) != 0)
        lv_textarea_set_placeholder_text(ui->password, placeholder);
    // Editing an ordinary character does not change the access-point list or
    // keyboard hit regions. Rebuild only when editing cancels a visible inline
    // confirmation; otherwise a fast SSID must keep one stable input scene.
    const bool dismiss_confirmation = !ui->open_name.empty() || !ui->forget_name.empty();
    ui->open_name.clear();
    ui->forget_name.clear();
    if (dismiss_confirmation) {
        ui->network_list_dirty = true;
        RequestUiUpdate(ui);
    }
}

lv_obj_t* NetworkInput(Ui* ui, int y, const char* placeholder, bool password) {
    auto* input = lv_textarea_create(ui->body);
    PlainObject(input);
    // Network layout uses physical Plus pixels, with a full-size keyboard below.
    lv_obj_set_pos(input, 0, y);
    lv_obj_set_size(input, PxX(kContentWidth), 60);
    lv_obj_set_style_border_width(input, 2, 0);
    lv_obj_set_style_border_color(input, lv_color_black(), 0);
    lv_obj_set_style_pad_all(input, 8, 0);
    lv_obj_set_style_text_font(input, ui->font, 0);
    lv_obj_set_style_border_width(input, 2, LV_STATE_FOCUSED);
    lv_obj_set_style_bg_color(input, lv_color_black(), LV_PART_CURSOR);
    lv_obj_set_style_bg_opa(input, LV_OPA_TRANSP, LV_PART_CURSOR);
    lv_obj_set_style_bg_opa(input, LV_OPA_COVER, lv_style_selector_t(LV_PART_CURSOR) | LV_STATE_FOCUSED);
    lv_obj_set_style_anim_duration(input, 0, LV_PART_CURSOR);
    lv_obj_set_style_anim_duration(input, 0, lv_style_selector_t(LV_PART_CURSOR) | LV_STATE_FOCUSED);
    lv_obj_remove_local_style_prop(input, LV_STYLE_TRANSITION, LV_PART_CURSOR);
    lv_textarea_set_one_line(input, true);
    lv_textarea_set_max_length(input, password ? 64 : 32);
    lv_textarea_set_placeholder_text(input, placeholder);
    lv_textarea_set_password_mode(input, password);
    if (password) {
        lv_textarea_set_password_show_time(input, 0);
        lv_textarea_set_password_bullet(input, "*");
    }
    lv_obj_add_event_cb(input, OnInputFocus, LV_EVENT_CLICKED, ui);
    lv_obj_add_event_cb(input, OnInputFocus, LV_EVENT_FOCUSED, ui);
    return input;
}

void UpdateNetworkList(Ui* ui, const View& view) {
    const int scroll_y = LogicalScrollY(ui->list);
    // A changed access-point/confirmation list really replaces hit targets.
    // Ordinary SSID characters never reach this rebuild path.
    pocket_hal::InvalidateInput();
    lv_obj_clean(ui->list);
    ui->wifi_buttons.clear();
    if (!ui->open_name.empty()) {
        Text(ui, ui->list, 6, 0, 430, "将保存此开放网络并尝试连接。");
        Text(ui, ui->list, 6, 36, 430, wifi_detail::SafeSsidLabel(ui->open_name), false, true);
        LocalButton(ui, ui->list, 6, 86, 204, 46, "确认连接", Action::ConfirmOpen, {}, true);
        LocalButton(ui, ui->list, 224, 86, 204, 46, "取消", Action::CancelForget, {}, true);
    } else if (!ui->forget_name.empty()) {
        Text(ui, ui->list, 6, 0, 430, "确认忘记此网络及已存密码？");
        Text(ui, ui->list, 6, 36, 430, wifi_detail::SafeSsidLabel(ui->forget_name), false, true);
        LocalButton(ui, ui->list, 6, 86, 204, 46, "确认忘记", Action::Forget, {}, true);
        LocalButton(ui, ui->list, 224, 86, 204, 46, "取消", Action::CancelForget, {}, true);
    } else if (!view.wifi_ready) {
        Text(ui, ui->list, 6, 8, 430, "网络配置暂不可用。可返回后重试。");
    } else if (view.wifi_connection.access_points.empty() && view.wifi_names.empty()) {
        Text(ui, ui->list, 6, 8, 430, view.wifi_connection.scanning ?
             "正在搜索附近的 2.4 GHz Wi-Fi……" : "尚未搜到网络。可重新搜索，或手动输入名称。");
    } else {
        int y = 0;
        const auto row = [&](const std::string& name, const char* signal, bool secured) {
            const bool saved = KnownWifi(view, name);
            auto* button = LocalButton(ui, ui->list, 0, y, 310, 68,
                                   wifi_detail::SafeSsidLabel(name).c_str(), Action::SelectWifi, name, true);
            auto* label = lv_obj_get_child(button, 0);
            LayoutAlign(label, LV_ALIGN_TOP_LEFT, 6, 3);
            lv_label_set_long_mode(label, LV_LABEL_LONG_DOT);
            LayoutHeight(label, 31);
            std::string info = signal;
            if (view.wifi_connection.connected && view.wifi_connection.ssid == name) info += " · 已连接";
            else if (saved) info += " · 已保存";
            Text(ui, button, 6, 34, 298, info, false, true);
            if (saved) LocalButton(ui, ui->list, 322, y, 116, 68, "忘记", Action::AskForget, name, true);
            else Text(ui, ui->list, 328, y + 18, 102, secured ? "需密码" : "开放", false, true);
            y += 74;
        };
        for (const auto& point : view.wifi_connection.access_points) {
            const int level = SignalLevel(point.rssi);
            row(point.ssid, level >= 3 ? "信号强" : level == 2 ? "信号中" : "信号弱", point.secured);
        }
        for (const auto& name : view.wifi_names) {
            const auto& points = view.wifi_connection.access_points;
            if (std::none_of(points.begin(), points.end(), [&](const WifiAccessPoint& point) { return point.ssid == name; }))
                row(name, "未搜到", true);
        }
        lv_obj_update_layout(ui->list);
        LogicalScrollTo(ui->list, scroll_y, LV_ANIM_OFF);
    }
    ui->network_list_dirty = false;
}

void UpdateNetworkStatus(Ui* ui, const View& view) {
    if (!ui->network_status) return;
    const auto& wifi = view.wifi_connection;
    const std::string text = wifi.connected ? "Wi-Fi 已连接\nIP: " + wifi.ip :
        wifi.connecting ? "正在连接 Wi-Fi\n请稍候" :
        wifi.scanning ? "正在搜索 Wi-Fi\n可选择已保存网络" : "Wi-Fi 未连接\n选择网络后连接";
    if (text != lv_label_get_text(ui->network_status)) lv_label_set_text(ui->network_status, text.c_str());
    if (ui->password && ui->ssid) {
        const bool saved = KnownWifi(view, NetworkName(ui));
        const char* placeholder = saved ? "留空使用已存密码；填入可更新" : "密码（开放网络留空）";
        if (std::strcmp(lv_textarea_get_placeholder_text(ui->password), placeholder) != 0)
            lv_textarea_set_placeholder_text(ui->password, placeholder);
    }
}

void BuildNetwork(Ui* ui, const View& view) {
    // Physical coordinates within the 638x945 body. The keyboard ends 11px
    // before the body edge; the short status strip stays below the body.
    ui->network_status = Text(ui, ui->body, 0, 0, 276, "");
    lv_obj_set_height(ui->network_status, 80);
    auto* search = AddButton(ui, ui->body, 286, 0, 162, 44, "搜索 Wi-Fi", Command::WifiScan);
    lv_obj_set_pos(search, 408, 4);
    lv_obj_set_size(search, 230, 64);
    ui->list = lv_obj_create(ui->body);
    PlainObject(ui->list);
    lv_obj_set_pos(ui->list, 0, 90);
    lv_obj_set_size(ui->list, PxX(kContentWidth), 132);
    lv_obj_set_style_border_width(ui->list, 2, 0);
    lv_obj_set_style_border_color(ui->list, lv_color_black(), 0);
    lv_obj_add_flag(ui->list, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_clear_flag(ui->list, LV_OBJ_FLAG_SCROLL_MOMENTUM);
    lv_obj_clear_flag(ui->list, LV_OBJ_FLAG_SCROLL_ELASTIC);
    lv_obj_set_scroll_dir(ui->list, LV_DIR_VER);
    lv_obj_set_scrollbar_mode(ui->list, LV_SCROLLBAR_MODE_ON);
    lv_obj_set_style_width(ui->list, 4, LV_PART_SCROLLBAR);
    lv_obj_set_style_bg_color(ui->list, lv_color_black(), LV_PART_SCROLLBAR);
    lv_obj_set_style_bg_opa(ui->list, LV_OPA_COVER, LV_PART_SCROLLBAR);
    ui->ssid = NetworkInput(ui, 232, "网络名称（SSID）", false);
    ui->selected_raw_ssid.clear(); ui->selected_ssid_label.clear();
    ui->password = NetworkInput(ui, 302, "密码（开放网络留空）", true);
    lv_obj_add_event_cb(ui->ssid, OnNetworkNameChanged, LV_EVENT_VALUE_CHANGED, ui);
    auto* connect = LocalButton(ui, ui->body, 0, 0, 214, 48, "连接", Action::WifiSave);
    lv_obj_set_pos(connect, 0, 374); lv_obj_set_size(connect, 305, 64);
    auto* back = LocalButton(ui, ui->body, 0, 0, 218, 48,
                            view.manager ? "返回固件口袋" : "返回应用", Action::Back);
    lv_obj_set_pos(back, 327, 374); lv_obj_set_size(back, 311, 64);
    ui->keyboard = pocket_ime::Create(ui->body, 0, 454, PxX(kContentWidth), 480, ui->font);
    if (ui->keyboard) FocusNetworkInput(ui, ui->ssid);
    else ui->local_error = "输入法创建失败，请返回后重试。";
    UpdateNetworkList(ui, view);
    UpdateNetworkStatus(ui, view);
}

void UpdateButtons(Ui* ui, const View& view) {
    const auto update = [&](const Button& button) {
        bool enabled = button.allowed && view.ready && !view.busy && !view.switching;
        if (view.auth_required && !IsPinAction(button.action)) enabled = false;
        if (ui->deep_sleep_requested && button.action != Action::DismissDeepSleep) enabled = false;
        if (button.action != Action::Runtime) {
            if (button.action == Action::PinKey || button.action == Action::PinSubmit)
                enabled = enabled && view.pin_ready && !ui->pin_pending;
            if (button.action == Action::OpenPin)
                enabled = enabled && view.manager && !view.usb_active;
            if (button.action == Action::WifiSave || button.action == Action::ConfirmOpen ||
                button.action == Action::Forget)
                enabled = enabled && view.wifi_ready && !view.wifi_connection.connecting;
            if (button.action == Action::ConfirmInstall)
                enabled = enabled && CanConfirmInstall(view, ui);
            if (button.action == Action::AskRestart)
                enabled = enabled && CanAskRestart(view, ui);
            if (button.action == Action::PackageDetails)
                enabled = enabled && ui_policy::CanInspectPackage(view,button.argument);
        } else if (button.command == Command::PowerOff) {
            // Shutdown remains available when TF is absent or needs repair.
        } else if (button.command == Command::ToggleUsb) {
            enabled = enabled && view.manager;
        } else if (button.command == Command::Refresh) {
            enabled = enabled && ui_policy::CanRefresh(view);
        } else if (button.command == Command::WifiScan) {
            enabled = enabled && !view.wifi_connection.scanning && !view.wifi_connection.connecting;
        } else if (button.command == Command::ResumeApplication) {
            enabled = enabled && CanResume(view);
        } else if (button.command == Command::InstallAndLaunch) {
            const int index=button.argument;
            enabled = enabled && index>=0 && static_cast<size_t>(index)<view.packages.size() &&
                      CanInstall(view,index,view.packages[static_cast<size_t>(index)].id,
                                 view.packages[static_cast<size_t>(index)].version);
        } else {
            enabled = enabled && !view.state_blocked && !view.usb_active;
            if (view.manager || (button.command != Command::Save &&
                                 button.command != Command::ReturnToManager)) {
                enabled = enabled && view.storage_ok;
            }
            if (button.command == Command::InstallAndLaunch || button.command == Command::Increment ||
                button.command == Command::BookmarkNext || button.command == Command::NoteNext ||
                (!view.manager && button.command == Command::PreferenceNext))
                enabled = enabled && !view.tf_space_blocked;
        }
        // Save/return remain retryable after a transient I/O failure. Only an
        // explicit state_blocked (corrupt/future state) disables those actions.
        if (enabled) {
            lv_obj_remove_state(button.object, LV_STATE_DISABLED);
            lv_obj_add_flag(button.object, LV_OBJ_FLAG_CLICKABLE);
        } else {
            lv_obj_add_state(button.object, LV_STATE_DISABLED);
            lv_obj_remove_flag(button.object, LV_OBJ_FLAG_CLICKABLE);
        }
    };
    for (const auto& button : ui->buttons) update(button);
    for (const auto& button : ui->header_buttons) update(button);
    for (const auto& button : ui->wifi_buttons) update(button);
    for (const auto& button : ui->modal_buttons) update(button);
    for (const auto& button : ui->pin_buttons) update(button);
    for (const auto& button : ui->deep_sleep_buttons) update(button);
    if (ui->network_page) {
        for (auto* input : {ui->ssid, ui->password, ui->keyboard}) {
            if (!input) continue;
            if (view.busy || !view.wifi_ready) lv_obj_add_state(input, LV_STATE_DISABLED);
            else lv_obj_remove_state(input, LV_STATE_DISABLED);
        }
    }
}

void Render(Ui* ui, const View& view) {
    // Put the opaque blocker above every page before changing any underlying
    // content. The runtime keeps switching latched until reboot or failure.
    if (!view.ready || view.switching) ShowBlocking(ui, view.switching);
    if (view.auth_required) {
        ui->network_requested = ui->help_requested = ui->pin_requested = false;
        ui->install_index = -1;
        ui->install_resume = false;
        ui->install_restart = false;
    }
    const bool page_changed = ui->network_page != ui->network_requested || ui->help_page != ui->help_requested ||
                              ui->pin_page != ui->pin_requested ||
                              (ui->help_requested && ui->legal_dirty);
    const bool body_changed = page_changed ||
        (!ui->network_requested && !ui->help_requested && !ui->pin_requested &&
         (!ui->rendered || !SameBody(ui->view, view)));
    if (ui->network_page && ui->wifi_pending && !view.busy &&
        view.revision != ui->wifi_submit_revision) {
        // A failed save retains the input. A completed save never exposes the
        // stored credential again; list snapshots contain names only.
        if (view.error.empty()) {
            if (ui->wifi_pending_save) lv_textarea_set_text(ui->password, "");
            ui->forget_name.clear();
            ui->open_name.clear();
            ui->network_list_dirty = true;
        }
        ui->wifi_pending = false;
    }
    if (page_changed || !ui->rendered || ui->view.title != view.title || ui->view.manager != view.manager) {
        const std::string title = ui->pin_requested ? "唤醒密码" : ui->help_requested ? (ui->legal_requested ? "开源许可" : "帮助文档") : ui->network_requested ? "Wi-Fi 连接" : view.manager ? "固件口袋" :
                                  (view.title.empty() ? "固件口袋" : view.title);
        lv_label_set_text(ui->title, title.c_str());
    }
    const bool show_help = view.manager && !ui->network_requested && !ui->help_requested && !ui->pin_requested;
    LayoutWidth(ui->title, kTitleWidth);
    if (show_help) lv_obj_remove_flag(ui->help_button, LV_OBJ_FLAG_HIDDEN);
    else lv_obj_add_flag(ui->help_button, LV_OBJ_FLAG_HIDDEN);
    if (!ui->rendered || ui->view.version != view.version) {
        const std::string subtitle = "内部测试 / 未发布" +
                                    (view.version.empty() ? std::string() : "  " + view.version);
        lv_label_set_text(ui->subtitle, subtitle.c_str());
    }
    if (body_changed) {
        // Coordinates queued for the former page must not act on a replacement
        // widget at the same position. Stable text edits do not take this path.
        pocket_hal::InvalidateInput();
        if (!ui->network_page && !ui->help_page && !ui->pin_page && ui->list) ui->manager_scroll = LogicalScrollY(ui->list);
        // Called by the timer/lifecycle event, never from a button's event.
        if (ui->keyboard) pocket_ime::SetTarget(ui->keyboard, nullptr);
        lv_obj_clean(ui->body);
        ui->buttons.clear();
        ui->wifi_buttons.clear();
        ui->list = nullptr;
        ui->scan_status = nullptr;
        ui->network_status = nullptr;
        ui->ssid = ui->password = ui->keyboard = nullptr;
        if (!ui->pin_overlay) {
            ui->pin_inputs.fill(nullptr);
            ui->pin_status = nullptr;
        }
        ui->forget_name.clear();
        ui->open_name.clear();
        ui->network_page = ui->network_requested;
        ui->help_page = ui->help_requested;
        ui->pin_page = ui->pin_requested;
        s_network_epoch.store((ui->network_page || ui->help_page || ui->pin_page) ? ui->epoch : 0, std::memory_order_release);
        if (ui->pin_page) {
            BuildPinControls(ui, ui->body, view, false);
        } else if (ui->help_page) {
            BuildHelp(ui);
        } else if (ui->network_page) {
            BuildNetwork(ui, view);
        } else if (!view.ready) {
            Text(ui, ui->body, 0, 30, kContentWidth,
                 "正在准备设备与存储，请稍候。\n现有文件不会自动格式化。", true);
        } else if (view.manager) {
            BuildManager(ui, view, ui->manager_scroll);
        } else {
            BuildApplication(ui, view);
        }
        ui->legal_dirty = false;
    } else if (ui->network_page && (ui->network_list_dirty ||
               ui->view.wifi_ready != view.wifi_ready || ui->view.wifi_names != view.wifi_names ||
               !SameAccessPoints(ui->view, view) ||
               ui->view.wifi_connection.scanning != view.wifi_connection.scanning ||
               ui->view.wifi_connection.connected != view.wifi_connection.connected ||
               ui->view.wifi_connection.ssid != view.wifi_connection.ssid)) {
        // Never rebuild the input fields/keyboard for a revision or list update.
        UpdateNetworkList(ui, view);
    }
    if (ui->network_page) UpdateNetworkStatus(ui, view);
    if (ui->pin_page) UpdatePinControls(ui, view);
    if (ui->scan_status) {
        const std::string scan = ScanLine(view);
        if (scan != lv_label_get_text(ui->scan_status)) lv_label_set_text(ui->scan_status, scan.c_str());
    }
    std::string message;
    const auto append_message = [&](const std::string& line) {
        if (line.empty()) return;
        if (!message.empty()) message += "\n";
        message += line;
    };
    if (ui->network_page) {
        // Connection results must be visible without scrolling past TF details.
        append_message(ui->local_error);
        append_message(view.error);
        append_message(view.wifi_connection.message);
        if (message.empty()) append_message(view.status);
    } else {
        if (!view.tf_space_known) message = "TF 剩余空间：未知，请重新检查。";
        else {
            message = "TF 剩余：" + std::to_string(view.tf_free_bytes / 1000000ULL) + " MB";
            if (view.tf_space_blocked) message += " · 需清理后继续";
            else if (view.tf_space_low) message += " · 空间不足";
        }
        if (view.tf_space_blocked) message += "\n操作已暂停，可保存返回或清理。";
        append_message(view.error);
        append_message(ui->local_error);
        append_message(view.status);
        if (!view.manager && view.ready) {
            if (!message.empty()) message += "\n";
            message += view.dirty ? "当前更改尚未保存。" : "以最近一次完整保存为准。";
            if (!view.storage_ok || view.state_blocked) {
                message += "\n恢复存储后，点击“重新检查”。";
            }
        }
    }
    if (message.empty()) message = view.busy ? "正在处理，请稍候。" : "就绪";
    if (message != lv_label_get_text(ui->notice)) {
        lv_label_set_text(ui->notice, message.c_str());
        LogicalScrollTo(lv_obj_get_parent(ui->notice), 0, LV_ANIM_OFF);
    }
    UpdateInstallDialog(ui, view);
    UpdateDeepSleepDialog(ui, view);
    UpdatePinOverlay(ui, view);
    UpdateButtons(ui, view);
    if (!view.ready || view.switching) {
        lv_obj_move_foreground(ui->blocking_overlay);
    } else if (ui->blocking_overlay) {
        // Timer/lifecycle only: never delete an object from its click callback.
        pocket_hal::InvalidateInput();
        lv_obj_delete(ui->blocking_overlay);
        ui->blocking_overlay = ui->blocking_label = nullptr;
    }
    UpdateWifiIcon(ui, view);
    UpdateBatteryIcon(ui, view);
    ui->view = view;
    ui->rendered = true;
    ui->redraw = false;
    if (view.switching) pocket_hal::CommitSwitchPresentation();
}

void Poll(lv_timer_t* timer) {
    auto* ui = static_cast<Ui*>(lv_timer_get_user_data(timer));
    const uint32_t now = lv_tick_get();
    if (ui && now - ui->last_poll_log >= 10000U) {
        ui->last_poll_log = now;
        ESP_LOGI("pocket_ui", "ui.poll revision=%lu ready=%d busy=%d switching=%d overlay=%d modal=%d screen_match=%d current=%d",
                 static_cast<unsigned long>(ui->view.revision), ui->view.ready,
                 ui->view.busy, ui->view.switching, ui->blocking_overlay != nullptr,
                 ui->install_overlay != nullptr, ui->screen == lv_screen_active(), Current(ui));
    }
    if (!Current(ui)) return;
    const View view = Snapshot();
    if (s_network_back_epoch.exchange(0, std::memory_order_acq_rel) == ui->epoch &&
        (ui->network_page || ui->help_page || ui->pin_page) && !view.busy && !view.auth_required) {
        ui->network_requested = false;
        ui->help_requested = false;
        ui->pin_requested = false;
        ui->redraw = true;
    }
    if (ui->rendered && view.revision == ui->view.revision && !ui->redraw &&
        !ui->network_list_dirty && ui->network_page == ui->network_requested &&
        ui->help_page == ui->help_requested && ui->pin_page == ui->pin_requested) return;
    Render(ui, view);
}

bool OnKey(const char* key) {
    if (key == nullptr || s_active_epoch.load(std::memory_order_acquire) == 0) return true;
    const auto view = Snapshot();
    if (!view.ready || view.busy || view.switching || view.auth_required) return true;
    if (s_network_epoch.load(std::memory_order_acquire) == s_active_epoch.load(std::memory_order_acquire)) {
        if (std::strcmp(key, "vk_home") == 0 || std::strcmp(key, "vk_prev") == 0)
            s_network_back_epoch.store(s_active_epoch.load(std::memory_order_acquire), std::memory_order_release);
        return true;
    }
    if (view.state_blocked) return true;
    if (!view.manager &&
        (std::strcmp(key, "vk_home") == 0 || std::strcmp(key, "vk_prev") == 0)) {
        (void)Post(Command::ReturnToManager);
    }
    return true; // Never enter the inherited framework's home/settings route.
}

void OnLoaded(lv_event_t* event) {
    auto* ui = static_cast<Ui*>(lv_event_get_user_data(event));
    if (ui != s_current || lv_event_get_target(event) != ui->screen) return;
    ui->unloaded = false;
    pocket_hal::InvalidateInput();
    s_active_epoch.store(ui->epoch, std::memory_order_release);
    s_network_epoch.store((ui->network_page || ui->help_page || ui->pin_page) ? ui->epoch : 0, std::memory_order_release);
    if (ui->timer) lv_timer_resume(ui->timer);
    Render(ui, Snapshot());
}

void OnUnloaded(lv_event_t* event) {
    auto* ui = static_cast<Ui*>(lv_event_get_user_data(event));
    if (lv_event_get_target(event) != ui->screen) return;
    pocket_hal::InvalidateInput();
    ui->unloaded = true;
    if (ui->timer) lv_timer_pause(ui->timer);
    uint32_t expected = ui->epoch;
    s_active_epoch.compare_exchange_strong(expected, 0, std::memory_order_acq_rel);
    expected = ui->epoch;
    s_network_epoch.compare_exchange_strong(expected, 0, std::memory_order_acq_rel);
}

void OnDeleted(lv_event_t* event) {
    auto* ui = static_cast<Ui*>(lv_event_get_user_data(event));
    if (lv_event_get_target(event) != ui->screen) return;
    if (ui->timer) lv_timer_delete(ui->timer);
    uint32_t expected = ui->epoch;
    s_active_epoch.compare_exchange_strong(expected, 0, std::memory_order_acq_rel);
    expected = ui->epoch;
    s_network_epoch.compare_exchange_strong(expected, 0, std::memory_order_acq_rel);
    if (s_current == ui) s_current = nullptr;
    // Do not clear global status bindings here: a newer screen may own them.
    delete ui;
}
} // namespace

lv_obj_t* CreateScreen() {
    pocket_hal::RequestFullRefresh();
    auto* ui = new (std::nothrow) Ui;
    if (ui == nullptr) {
        auto* screen = lv_obj_create(nullptr);
        auto* message = lv_label_create(screen);
        lv_label_set_text(message, "Pocket: insufficient memory");
        lv_obj_center(message);
        return screen;
    }
    ui->epoch = ++s_next_epoch;
    ui->font = pocket_font::Get(32);
    if (!ui->font) ui->font = LV_FONT_DEFAULT;
    ui->heading_font = pocket_font::Get(38);
    if (!ui->heading_font) ui->heading_font = ui->font;
    ui->screen = lv_obj_create(nullptr);
    PlainObject(ui->screen);
    LayoutSize(ui->screen, kWidth, kHeight);
    ui->title = Text(ui, ui->screen, 16, 14, kTitleWidth, "固件口袋", true, true);
    ui->subtitle = Text(ui, ui->screen, 16, 51, kContentWidth, "内部测试 / 未发布", false, true);
    ui->body = lv_obj_create(ui->screen);
    PlainObject(ui->body);
    LayoutPos(ui->body, 16, 88);
    LayoutSize(ui->body, kContentWidth, 636);
    auto* notice_box = lv_obj_create(ui->screen);
    PlainObject(notice_box);
    LayoutPos(notice_box, 16, 732);
    LayoutSize(notice_box, kContentWidth, 52);
    lv_obj_set_style_border_width(notice_box, 2, 0);
    lv_obj_set_style_border_color(notice_box, lv_color_black(), 0);
    lv_obj_add_flag(notice_box, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_clear_flag(notice_box, LV_OBJ_FLAG_SCROLL_MOMENTUM);
    lv_obj_clear_flag(notice_box, LV_OBJ_FLAG_SCROLL_ELASTIC);
    lv_obj_set_scroll_dir(notice_box, LV_DIR_VER);
    lv_obj_set_scrollbar_mode(notice_box, LV_SCROLLBAR_MODE_AUTO);
    ui->notice = Text(ui, notice_box, 8, 4, 428, "正在初始化……");
    lv_obj_set_style_text_font(ui->notice, pocket_font::Get(25), 0);
    // Header controls own separate, stable callback data across body rebuilds.
    ui->help_button = LocalButton(ui, ui->screen, kHelpX, 10, kHelpWidth, 44, "帮助文档", Action::OpenHelp);
    ui->ink_button = LocalButton(ui, ui->screen, kInkX, 10, kInkWidth, 44, "研墨", Action::Ink);
    BuildWifiIcon(ui);
    BuildBatteryIcon(ui);
    s_current = ui;
    s_active_epoch.store(0, std::memory_order_release);
    lv_obj_add_event_cb(ui->screen, OnLoaded, LV_EVENT_SCREEN_LOADED, ui);
    lv_obj_add_event_cb(ui->screen, OnUnloaded, LV_EVENT_SCREEN_UNLOADED, ui);
    lv_obj_add_event_cb(ui->screen, OnDeleted, LV_EVENT_DELETE, ui);
    ui->timer = lv_timer_create(Poll, 50, ui);
    Render(ui, Snapshot());
    if (ui->timer == nullptr) {
        lv_label_set_text(ui->notice, "界面定时器创建失败，请重启设备。未提交任何存储操作。");
    }
    return ui->screen;
}
bool HardwareKey(const char* key) { return OnKey(key); }
} // namespace pocket
