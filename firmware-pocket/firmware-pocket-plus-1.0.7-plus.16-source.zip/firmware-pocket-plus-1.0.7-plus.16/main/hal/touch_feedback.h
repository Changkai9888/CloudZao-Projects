#pragma once
#include "input_pipeline.h"

namespace pocket_hal_detail {
struct FeedbackSample {
    bool accepted = false;
    bool new_down = false;
};
// A successful new DOWN, independent of which LVGL object lies underneath.
// Repeated held samples/movement/release and fence rearming are not presses.
// TouchQueue increments presses before Push, so Sample's actual success is
// also required: a DOWN dropped by bounded overflow must not claim feedback.
template<size_t Capacity>
FeedbackSample SampleWithFeedback(TouchQueue<Capacity>& queue, bool down,
                                  int x, int y, int64_t sampled_us) {
    const uint32_t presses_before = queue.Stats().presses;
    const bool accepted = queue.Sample(down, x, y, sampled_us);
    return {accepted, accepted && down && queue.Stats().presses != presses_before};
}
} // namespace pocket_hal_detail
