#include "../power_key.h"
#include "../wake_hold.h"
#include <cassert>
#include <cstdio>

using plus_hal_detail::PowerKeyEvent;
using plus_hal_detail::PowerKeyState;
using plus_hal_detail::WakeHoldGate;
namespace {
void Arm(PowerKeyState& key) {
    assert(key.Sample(false, 0) == PowerKeyEvent::None);
    assert(key.Sample(false, 40000) == PowerKeyEvent::None);
}
void ShortTap() {
    PowerKeyState key; Arm(key);
    assert(key.Sample(true, 100000) == PowerKeyEvent::None);
    assert(key.Sample(true, 140000) == PowerKeyEvent::None);
    assert(key.Sample(false, 200000) == PowerKeyEvent::None);
    assert(key.Sample(false, 240000) == PowerKeyEvent::ShortPress);
    assert(key.Sample(false, 260000) == PowerKeyEvent::None);
}
void FiveSecondsOnlyOnce() {
    PowerKeyState key; Arm(key); unsigned longs = 0;
    for (int64_t t = 100000; t <= 12100000; t += 20000) {
        const auto event = key.Sample(true, t);
        if (t < 5100000) assert(event == PowerKeyEvent::None);
        assert(event != PowerKeyEvent::ShortPress);
        longs += event == PowerKeyEvent::LongPress;
    }
    assert(longs == 1);
    assert(key.Sample(false, 12120000) == PowerKeyEvent::None);
    assert(key.Sample(false, 12160000) == PowerKeyEvent::None);
}
void ThreeSecondsIsNotDeepSleep() {
    PowerKeyState key; Arm(key);
    for (int64_t t = 100000; t < 3100000; t += 20000)
        assert(key.Sample(true, t) == PowerKeyEvent::None);
    assert(key.Sample(false, 3100000) == PowerKeyEvent::None);
    assert(key.Sample(false, 3140000) == PowerKeyEvent::ShortPress);
}
void BootHeldRequiresRelease() {
    PowerKeyState key;
    for (int64_t t = 0; t < 6000000; t += 20000)
        assert(key.Sample(true, t) == PowerKeyEvent::None);
    assert(key.Sample(false, 6000000) == PowerKeyEvent::None);
    assert(key.Sample(false, 6040000) == PowerKeyEvent::None);
    assert(key.Sample(true, 6080000) == PowerKeyEvent::None);
    assert(key.Sample(true, 6120000) == PowerKeyEvent::None);
    assert(key.Sample(false, 6200000) == PowerKeyEvent::None);
    assert(key.Sample(false, 6240000) == PowerKeyEvent::ShortPress);
}
void UnknownGapDisarms() {
    PowerKeyState key; Arm(key);
    for (int64_t t = 100000; t < 2000000; t += 20000)
        assert(key.Sample(true, t) == PowerKeyEvent::None);
    for (int64_t t = 2500000; t < 8500000; t += 20000)
        assert(key.Sample(true, t) == PowerKeyEvent::None);
    assert(key.Sample(false, 8500000) == PowerKeyEvent::None);
    assert(key.Sample(false, 8540000) == PowerKeyEvent::None);
}
void BounceAndClockRollback() {
    PowerKeyState key; Arm(key);
    assert(key.Sample(true, 100000) == PowerKeyEvent::None);
    assert(key.Sample(false, 110000) == PowerKeyEvent::None);
    assert(key.Sample(false, 150000) == PowerKeyEvent::None);
    assert(key.Sample(true, 170000) == PowerKeyEvent::None);
    assert(key.Sample(true, 210000) == PowerKeyEvent::None);
    assert(key.Sample(true, 10000) == PowerKeyEvent::None);
    for (int64_t t = 30000; t < 6030000; t += 20000)
        assert(key.Sample(true, t) == PowerKeyEvent::None);
}
void WakeFiveContinuousSeconds() {
    WakeHoldGate gate;
    for (int64_t t = 0; t < 5000000; t += 20000) assert(!gate.Sample(true, t));
    assert(gate.Sample(true, 5000000));
}
void WakeReleaseGapAndRollbackRestart() {
    WakeHoldGate gate;
    for (int64_t t = 0; t < 4000000; t += 20000) assert(!gate.Sample(true, t));
    assert(!gate.Sample(false, 4000000));
    for (int64_t t = 4020000; t < 9020000; t += 20000) assert(!gate.Sample(true, t));
    assert(gate.Sample(true, 9020000));
    gate.Reset();
    for (int64_t t = 0; t < 4000000; t += 20000) assert(!gate.Sample(true, t));
    for (int64_t t = 4500000; t < 9500000; t += 20000) assert(!gate.Sample(true, t));
    assert(gate.Sample(true, 9500000));
    assert(!gate.Sample(true, 100000));
    for (int64_t t = 120000; t < 5100000; t += 20000) assert(!gate.Sample(true, t));
    assert(gate.Sample(true, 5100000));
}
} // namespace
int main() {
    ShortTap(); FiveSecondsOnlyOnce(); ThreeSecondsIsNotDeepSleep();
    BootHeldRequiresRelease(); UnknownGapDisarms(); BounceAndClockRollback();
    WakeFiveContinuousSeconds(); WakeReleaseGapAndRollbackRestart();
    std::puts("PASS: 8 production power-key/wake-gate scenarios (5-second threshold, no replay)");
}
