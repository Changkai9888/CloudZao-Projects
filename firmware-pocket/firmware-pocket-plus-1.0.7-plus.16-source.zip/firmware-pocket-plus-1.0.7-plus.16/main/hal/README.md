# Plus HAL integration notes

Official driver source: CloudZao/Metalio-E-INK4-Plus commit `ad8edf4150a688737c0d7c00cae4413079b262ef` (main observed 2026-10-24). The unmodified selected references are under ../../../../资料/官方驱动. This HAL does not import the official application, audio service, cloud services, shared font partition, or sleep policy.

## Build integration

- ESP-IDF v6.1, target esp32s31.
- Dependencies: lvgl 9.5, espressif/esp_tinyusb ^2.0.0; standard IDF hardware/storage/Wi-Fi components.
- Main source list must include hal/*.cc and hal/power/*.cc + hal/power/*.c; public include directories hal and hal/power.
- EPDiy component declares its own hardware requirements; no Xtensa lut.S is compiled on S31.
- Enable PSRAM OCT 200 MHz, FREERTOS_TASK_CREATE_ALLOW_EXT_MEM, SPIRAM_ALLOW_STACK_EXTERNAL_MEMORY. EPDiy has two feed tasks, pinned to CPU 0 and CPU 1, and requires a dual-core configuration.
- Enable LV_DRAW_SW_SUPPORT_L8 and TinyUSB MSC. The HAL uses an L8 64-line LVGL draw buffer and a native 4-bpp panel framebuffer.
- Give main at least 16 KiB stack and keep task WDT at 20 s while evaluating complete gray refresh.
- Main owns lv_init() and calls lv_timer_handler(). No hardware task calls LVGL. Main must finish or close TF file activity before ToggleUsb(), and must gate TF activity while UsbBusy() or UsbActive().

## Initialization and panel

Init performs EPDiy/TPS/TCA initialization, touch probe, haptic setup, BQ27220 and charger, TF mount, USB manager, then creates the LVGL display/input and panel worker. A missing TF card is diagnosable from TfMounted(); touch/panel/PSRAM initialization errors are fatal.

Physical panel: 1216 x 684, E0470A14_AF, LANDSCAPE. Logical UI: 684 x 1216. Mapping: physical x = logical y, physical y = 683 - logical x. Even physical x occupies the low framebuffer nibble; odd x occupies the high nibble.

The touch controller FT6336U at 0x38 is on shared I2C1 (SDA GPIO0/SCL GPIO1), interrupt GPIO5, reset TCA P1.2. Off-panel cover-key samples near y=1600 are suppressed from pointer input. The official touch code retains short press/release edges and polls as an IRQ fallback.

PollHardwareKey() transfers cover-key press edges as "home"/"prev"/"next" to the main thread; no LVGL operation runs in the touch feed callback. A separate 20 ms internal-RAM power service samples active-low TCA P1.7 through the shared I2C mutex. Debounced short release enters/leaves RAM-preserving standby. PollPowerOff() only drains a >= 3 second long-press event; the main thread retries the existing save-and-shutdown command if its queue is temporarily busy. A long press never also produces a short press on release.

In 1.0.7-plus.5, boot and wake use GPIO6 cool LEDC PWM at 20 kHz, 10 bits, duty 2/1023; GPIO7 warm remains zero. This is the Plus official UI brightness level 1 mapping (the official brightness scale limits full UI brightness to 20 percent output). A short press turns both LEDC duties off, pauses touch, and asks the physical worker to show a geometric Pocket lock screen. The worker finishes already-admitted application frames first, then paints the overlay directly into its own native 4bpp buffer. The complete LVGL application snapshot stays intact in s_pending. A second short press restores that snapshot and micro-light; IsStandby remains true until the physical restore succeeds. A lock/wake overlay never advances the application generation or acknowledges a switch presentation. No deep sleep, reboot or loss of RAM state occurs. Wi-Fi/storage services retain their existing behavior. Main skips LVGL timers during lock, resets old press state at both boundaries, and invalidates the screen after restoration to reconcile an interrupted LVGL stripe render. Touch re-arms only after a confirmed no-contact sample. SetStandbyAllowed(false) suppresses short-press entry during startup/save/switch work; wake is always accepted.

The power service takes only aux -> frame (brief snapshot admission fence), never the panel lock. The physical worker takes panel -> frame and owns all lock/wake drawing. Flash takes panel -> aux -> I2C; no frame owner waits for aux or panel, so the added control path introduces no reverse lock dependency. Pending control work is retained while Flash admission is closed and resumes on EndFlashWrite's notification.

Flash admission retains the panel gate, then the auxiliary power/motor gate, pauses touch and retains the shared synchronous I2C mutex until failure/reboot. Power-key epochs and unknown-sample re-arming cover even Flash leases shorter than one scanner period. Key read failures and sample gaps cannot synthesize a tap. These changes are confined to this new source copy; the accepted plus.3 source and BIN remain unchanged.

Flush builds a complete render frame on the LVGL thread, publishes a complete snapshot only after the last stripe, and the panel worker copies that into its private high-level front framebuffer. Panel refresh cannot read a framebuffer being changed by LVGL. Notifications coalesce to the latest complete frame.

The pocket UI converts L8 to physical black/white at threshold 160 (stroke coverage of at least 96/255 becomes black). This is a UI policy, not a panel capability limit. It avoids pale resampled glyphs and routes ordinary input changes through DU. The first frame clears the physical panel and draws GC16. A complete refresh is forced after 48 actual partial updates, and an explicit RequestFullRefresh() also forces it for page changes. There is no idle-time-only full-refresh trigger. Failed updates get one clear/full retry and expose LastRefreshError(). Touch I2C sampling pauses during actual panel drive. Flash installation/resume retains the physical display gate after presenting its switch page.

The copied board file has one deliberate correction: Port0's combined motor/TPS output value is now computed under the shared I2C mutex, preventing a delayed motor write from replaying stale TPS power bits.

## TF and USB

SDMMC: D0-D3 GPIO20-23, CLK GPIO24, CMD GPIO25; 4-bit. The official 4096-byte INTERNAL/DMA bounce buffer and alignment hook are retained. FatFS is never formatted by this code.

GPIO36 ANA_SW is high for the normal USB serial/debug path and low for the HS UTMI MSC path. S31 UTMI and USJ are separate hardware PHYs; the S3 PHY-selection sequence is not used for S31.

MSC uses explicit APP/USB ownership and a worker queue. Enable performs detach, cable route switch, storage handover and attach. Disable tears down the USB device first, then removes MSC storage and restores the normal VFS mount. Application files must not be accessed while the computer owns the card. The UI polls atomic status; it is not called from USB callbacks.

## Battery and RTC

BQ27220 @0x55: the manufacturer's existing voltage-based display estimate and smoothing are retained, not represented as calibrated true coulomb-count SOC. The UI value is sampled at most every 10 seconds and deferred while the panel is busy.

PCF8563 @0x51: read seconds through year; invalid-voltage flag and calendar ranges are checked. RtcTime returns transport success separately from the valid flag. It does not set the system clock or write an uninitialized RTC.

PowerOff stops MSC with a bounded wait, unmounts TF, turns frontlights and motor off, waits for a panel drive to finish, then emits the board's TCA P1.3 shutdown pulse train.

