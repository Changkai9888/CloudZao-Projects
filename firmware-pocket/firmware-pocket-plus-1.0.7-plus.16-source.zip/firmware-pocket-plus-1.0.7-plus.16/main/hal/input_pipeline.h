#pragma once
#include <cstddef>
#include <cstdint>

namespace pocket_hal_detail {

enum class TouchKind : uint8_t { Down, Move, Up };
struct TouchEvent {
    int16_t x = 0, y = 0;
    TouchKind kind = TouchKind::Up;
    uint32_t epoch = 0;
    int64_t sampled_us = 0;
};
struct TouchQueueStats {
    uint32_t presses = 0, releases = 0, enqueued = 0, delivered = 0;
    uint32_t overflow = 0, discarded = 0, moves_merged = 0, moves_skipped = 0;
    uint32_t max_delivery_us = 0;
};

// Caller serializes all operations. Edges are never replaced by newer clicks.
// Only adjacent movement samples from the same gesture may be coalesced.
// A layout/overflow boundary cancels the old gesture and requires a real lift.
template <size_t Capacity = 64> class TouchQueue {
public:
    static_assert(Capacity >= 4);
    void Invalidate() {
        stats_.discarded += uint32_t(size_);
        head_ = size_ = 0;
        down_ = false;
        wait_release_ = true;
        ++epoch_;
    }
    bool Sample(bool down, int x, int y, int64_t now) {
        if (wait_release_) {
            if (!down) wait_release_ = false;
            return true;
        }
        if (down) {
            if (!down_) {
                ++stats_.presses;
                down_ = true;
                x_ = int16_t(x); y_ = int16_t(y);
                return Push(TouchKind::Down, now);
            }
            if (x_ == x && y_ == y) return true;
            x_ = int16_t(x); y_ = int16_t(y);
            if (size_ && At(size_ - 1).kind == TouchKind::Move) {
                At(size_ - 1) = Event(TouchKind::Move, now);
                ++stats_.moves_merged;
                return true;
            }
            // Leave slots for the eventual release and a following press.
            if (size_ >= Capacity - 2) { ++stats_.moves_skipped; return true; }
            return Push(TouchKind::Move, now);
        }
        if (!down_) return true;
        down_ = false;
        ++stats_.releases;
        return Push(TouchKind::Up, now);
    }
    bool Pop(TouchEvent* out, int64_t now) {
        if (!out || !size_) return false;
        *out = At(0);
        head_ = (head_ + 1) % Capacity;
        --size_;
        ++stats_.delivered;
        const int64_t delay = now - out->sampled_us;
        if (delay > int64_t(stats_.max_delivery_us))
            stats_.max_delivery_us = uint32_t(delay > UINT32_MAX ? UINT32_MAX : delay);
        return true;
    }
    bool WaitingRelease() const { return wait_release_; }
    size_t Size() const { return size_; }
    uint32_t Epoch() const { return epoch_; }
    TouchQueueStats Stats() const { return stats_; }
private:
    TouchEvent Event(TouchKind kind, int64_t now) const {
        return {x_, y_, kind, epoch_, now};
    }
    TouchEvent& At(size_t offset) { return events_[(head_ + offset) % Capacity]; }
    bool Push(TouchKind kind, int64_t now) {
        if (size_ == Capacity) {
            ++stats_.overflow;
            Invalidate(); // Fail closed: never synthesize an orphan release/click.
            return false;
        }
        At(size_++) = Event(kind, now);
        ++stats_.enqueued;
        return true;
    }
    TouchEvent events_[Capacity]{};
    size_t head_ = 0, size_ = 0;
    uint32_t epoch_ = 1;
    int16_t x_ = 0, y_ = 0;
    bool down_ = false, wait_release_ = true;
    TouchQueueStats stats_{};
};

} // namespace pocket_hal_detail
