#pragma once
#include <cstdint>

namespace plus_hal_detail {

// Manager-only policy. Time comes from the monotonic ESP timer, never the RTC,
// Wi-Fi clock, redraw count or application records. Keep the ESP timer's full
// range even when a host-owned TF card defers shutdown for many weeks.
class IdleSleepPolicy {
public:
    static constexpr uint64_t kIdleMs = 10U * 60U * 1000U;
    static constexpr uint64_t kRetryMs = 60U * 1000U;

    static bool Expired(uint64_t now_ms, uint64_t activity_ms) {
        // A sampler may publish a later timestamp between the caller reading
        // now and reading activity. Such a sample is recent, never expired.
        return now_ms >= activity_ms && now_ms - activity_ms >= kIdleMs;
    }

    bool ShouldRequest(uint64_t now_ms, uint64_t activity_ms, bool safe) const {
        return safe && Expired(now_ms, activity_ms) &&
               (!attempted_ || (now_ms >= attempted_ms_ && now_ms - attempted_ms_ >= kRetryMs));
    }

    // Only a successfully queued request starts the retry interval. If the
    // existing save/shutdown path refuses, it cannot cause a busy retry loop.
    void Requested(uint64_t now_ms) {
        attempted_ = true;
        attempted_ms_ = now_ms;
    }

private:
    bool attempted_ = false;
    uint64_t attempted_ms_ = 0;
};

} // namespace plus_hal_detail
