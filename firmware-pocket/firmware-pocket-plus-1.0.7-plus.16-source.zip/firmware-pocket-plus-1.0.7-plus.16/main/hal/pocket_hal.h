#pragma once
#include <ctime>
#include <cstdint>
#include <string>
namespace pocket_hal {
// Must be called before LVGL, storage, Wi-Fi, or frontlight initialization.
void EarlyWakeGate();
// True only after this pocket's real deep-sleep wake passed the 5-second gate.
bool WokeFromDeepSleep();
bool Init(std::string* error = nullptr);
// Screen/recognized cover DOWNs already request one motor pulse in the feed
// task, including blank and disabled UI. Do not duplicate this in UI callbacks.
// Keep this API only for explicit non-touch feedback.
void Pulse();
// LVGL thread only: cancel old-scene input, wait for the next physical frame
// and a confirmed finger release. Do not use for ordinary text/frame updates.
void InvalidateInput();
// LVGL thread, once before lv_timer_handler(): coalesce software rendering
// while the physical panel owns a complete pending snapshot. Input/UI timers
// remain active. Ordinary dirty regions are retained until rendering resumes.
void ServiceRendering();
// LVGL thread: aggregate handler timing without logging input or credentials.
void RecordUiCycle(uint32_t elapsed_us);
void RequestFullRefresh();
// Runtime requests a presentation; only the LVGL thread commits its switch page.
uint32_t RequestSwitchPresentation();
void CommitSwitchPresentation();
// Wait for that completed physical frame, then retain exclusive panel ownership.
// Begin/End must run on the same worker; timeout leaves normal refresh enabled.
// presentation=0 drains hardware without showing a switch page (startup OTA ack).
bool BeginFlashWrite(uint32_t presentation, uint32_t timeout_ms);
void EndFlashWrite();
bool TfMounted();
bool MountTf();
bool UnmountTf();
bool UsbActive();
bool UsbBusy();
bool UsbExported();
void ToggleUsb();
std::string UsbHint();
int BatteryLevel();
bool RtcTime(struct tm* value, bool* valid);
// Successful entry does not return. Refusal restores the visible/usable state.
// Auto requests recheck inactivity after quiescing hardware; manual requests
// retain their existing behavior. This is private to the manager, not its ABI.
bool PowerOff(bool only_if_idle = false);
// Updated by valid physical touch samples (including while short-locked) and
// deliberate power-key operations. No screen/network/console update resets it.
uint64_t LastUserActivityMs();
bool IdleSleepDue();
// Called by the LVGL/main thread. Events are "home", "prev", "next", or null.
const char* PollHardwareKey();
// Power service handles debounced short presses; long press posts safe shutdown.
bool PollPowerOff();
// RAM-preserving lock screen. Wake remains blocked until app frame is restored.
bool IsStandby();
uint32_t StandbyRevision();
unsigned FrontlightDuty();
// Prevent a short press from hiding switch/save/USB maintenance work in progress.
void SetStandbyAllowed(bool allowed);
// Diagnostics without accessing LVGL from hardware tasks.
bool PanelBusy();
unsigned RefreshCount();
int LastRefreshError();
void PrintInputDiagnostics();
}

