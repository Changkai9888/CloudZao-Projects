#include "pocket_hal.h"
#include "SdCardManager.hpp"
#include "usb_virtual_disk.h"
#include "config.h"
#include "metalio_epd.h"
#include "metalio_touch.h"
#include "input_pipeline.h"
#include "touch_feedback.h"
#include "metalio_i2c1.h"
#include "epd_board_metalio_eink4_plus.h"
#include "epdiy.h"
#include "power/bq27220_gauge.h"
#include "power/cx25601n.h"
#include "power_key.h"
#include "idle_sleep.h"
#include "wake_hold.h"
#include "lockscreen.h"
extern "C" {
#include "pca9555.h"
}
#include <lvgl.h>
#include <driver/gpio.h>
#include <driver/ledc.h>
#include <driver/rtc_io.h>
#include <esp_attr.h>
#include <esp_heap_caps.h>
#include <esp_log.h>
#include <esp_psram.h>
#include <esp_sleep.h>
#include <esp_timer.h>
#include <soc/soc_caps.h>
#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>
#include <freertos/task.h>
#include <freertos/queue.h>
#include <algorithm>
#include <atomic>
#include <cstring>
#include <cstdlib>

extern const uint8_t pocket_lockscreen_start[] asm("_binary_pocket_lockscreen_bin_start");
extern const uint8_t pocket_lockscreen_end[] asm("_binary_pocket_lockscreen_bin_end");
extern const uint8_t pocket_deepsleep_start[] asm("_binary_pocket_deepsleep_bin_start");
extern const uint8_t pocket_deepsleep_end[] asm("_binary_pocket_deepsleep_bin_end");

namespace {
constexpr char kTag[] = "PocketPlusHal";
constexpr int kWidth = 684, kHeight = 1216;
// Pocket is a text/control UI. Promote antialiased stroke coverage >= 96/255
// to physical black instead of driving pale gray strokes on every keypress.
// 0/15 are the existing panel's verified black/white endpoints.
constexpr uint8_t kUiWhiteThreshold = 160;
constexpr size_t kFrameBytes = size_t(kWidth) * kHeight / 2;
constexpr size_t kLockBitmapBytes = size_t(kHeight) * kWidth / 8;
static_assert(kLockBitmapBytes == 103968);
constexpr uint32_t kDeepSleepMagic = 0x504B3744; // PK7D: pocket only, not applications.
RTC_DATA_ATTR uint32_t s_deep_sleep_magic = 0;
RTC_DATA_ATTR uint8_t s_sleep_tca_addr = 0x20;
bool s_woke_from_deep_sleep = false;

bool ExpandNativeMono(const uint8_t* begin, const uint8_t* end, uint8_t* frame) {
    if (!begin || !end || !frame || size_t(end - begin) != kLockBitmapBytes)
        return false;
    for (size_t i = 0; i < kLockBitmapBytes; ++i) {
        const uint8_t source = begin[i];
        for (unsigned pair = 0; pair < 4; ++pair) {
            const uint8_t even = (source & (0x80u >> (pair * 2))) ? 0 : 15;
            const uint8_t odd = (source & (0x40u >> (pair * 2))) ? 0 : 15;
            frame[i * 4 + pair] = uint8_t(even | (odd << 4));
        }
    }
    return true;
}

void DrawPocketLockScreen(uint8_t* frame) {
    const size_t length = size_t(pocket_lockscreen_end - pocket_lockscreen_start);
    if (length != kLockBitmapBytes) {
        ESP_LOGE(kTag, "lockscreen bitmap length=%u expected=%u; using fallback",
                 unsigned(length), unsigned(kLockBitmapBytes));
        plus_lockscreen::Draw(frame, kHeight, kWidth, plus_lockscreen::Style::Pocket);
        return;
    }
    // ROM image is native 1216x684 row-major MSB-first, 1 means black.
    // EPD native 4bpp stores even X in the LOW nibble (black=0, white=15).
    // Preserve every physical pixel; no scaling, font lookup or heap allocation.
    ExpandNativeMono(pocket_lockscreen_start, pocket_lockscreen_end, frame);
}
uint8_t* s_render = nullptr;   // Sole writer: LVGL thread.
uint8_t* s_pending = nullptr;  // Complete rendered snapshot, protected by mutex.
SemaphoreHandle_t s_frame_mu = nullptr;
SemaphoreHandle_t s_panel_gate = nullptr;
SemaphoreHandle_t s_aux_gate = nullptr;
TaskHandle_t s_refresh_task = nullptr;
std::atomic<bool> s_force_full{true}, s_panel_busy{false};
std::atomic<bool> s_panel_state_known{false};
std::atomic<bool> s_refresh_paused{false};
std::atomic<bool> s_standby{false}, s_standby_allowed{false}, s_power_off_requested{false};
std::atomic<bool> s_touch_wait_release{false}, s_powered_down{false};
std::atomic<uint32_t> s_standby_revision{0};
std::atomic<uint32_t> s_presented_standby_revision{0};
std::atomic<uint32_t> s_power_epoch{0};
portMUX_TYPE s_activity_mu = portMUX_INITIALIZER_UNLOCKED;
uint64_t s_last_user_activity_ms = 0; // Only accessed under s_activity_mu.
std::atomic<bool> s_power_key_held{false};
std::atomic<uint32_t> s_switch_request{0}, s_switch_submitted{0}, s_switch_generation{0};
std::atomic<uint32_t> s_completed_generation{0};
TaskHandle_t s_flash_owner = nullptr;
bool s_flash_i2c_held = false;
std::atomic<unsigned> s_refreshes{0};
std::atomic<int> s_refresh_error{0};
std::atomic<int> s_cover_event{0};
std::atomic<unsigned> s_pending_generation{0};
std::atomic<unsigned> s_input_reads{0}, s_input_down_reads{0};
std::atomic<unsigned> s_touch_samples_during_refresh{0};
std::atomic<bool> s_ready{false};
lv_indev_t* s_indev = nullptr; // Accessed only by the LVGL thread.
portMUX_TYPE s_input_mu = portMUX_INITIALIZER_UNLOCKED;
pocket_hal_detail::TouchQueue<64> s_touch_queue;
std::atomic<uint32_t> s_scene_generation{0};
struct MotorRequest { uint32_t epoch; int64_t requested_us; };
QueueHandle_t s_motor_queue = nullptr;
std::atomic<uint32_t> s_motor_epoch{1};
std::atomic<unsigned> s_motor_requested{0}, s_motor_queued{0};
std::atomic<unsigned> s_motor_started{0}, s_motor_finished{0}, s_motor_dropped{0};
std::atomic<unsigned> s_motor_max_delay_us{0};
std::atomic<unsigned> s_screen_feedback_requests{0}, s_cover_feedback_requests{0};
lv_timer_t* s_display_refr_timer = nullptr; // LVGL thread only.
std::atomic<bool> s_software_gate_paused{false}, s_frame_retry_pending{false};
std::atomic<uint32_t> s_failed_generation{0};
std::atomic<unsigned> s_gate_checks{0}, s_gate_waits{0}, s_gate_pauses{0}, s_gate_resumes{0};
std::atomic<unsigned> s_refr_callbacks{0}, s_refr_deferred{0};
std::atomic<unsigned> s_refr_total_us{0}, s_refr_max_us{0};
std::atomic<unsigned> s_flush_calls{0}, s_flush_total_us{0}, s_flush_max_us{0};
std::atomic<unsigned> s_frame_snapshots{0}, s_snapshot_replaced{0}, s_frame_retries{0};
std::atomic<unsigned> s_ui_cycles{0}, s_ui_total_us{0}, s_ui_max_us{0};
int64_t s_last_snapshot_us = 0; // LVGL writer only.

void RecordUserActivity() {
    const uint64_t now = uint64_t(esp_timer_get_time() / 1000);
    // A tiny separate critical section makes 64-bit time safe on RV32 without
    // libatomic. No I/O or other locks inside; delayed writers cannot go back.
    portENTER_CRITICAL(&s_activity_mu);
    if (now > s_last_user_activity_ms) s_last_user_activity_ms = now;
    portEXIT_CRITICAL(&s_activity_mu);
}

bool ScenePending() {
    const uint32_t target = s_scene_generation.load(std::memory_order_acquire);
    return target && s_completed_generation.load(std::memory_order_acquire) < target;
}
// Safe from hardware workers: never accesses LVGL, never takes panel/aux locks.
void CancelTouch() {
    portENTER_CRITICAL(&s_input_mu);
    s_touch_queue.Invalidate();
    s_touch_wait_release.store(true, std::memory_order_release);
    portEXIT_CRITICAL(&s_input_mu);
    s_cover_event.store(0);
}
// Caller owns aux when stopping hardware. An already dequeued request also
// checks this epoch after obtaining aux, so it cannot replay after a boundary.
void CancelMotor() {
    ++s_motor_epoch;
    MotorRequest request{};
    while (s_motor_queue && xQueueReceive(s_motor_queue, &request, 0) == pdTRUE)
        ++s_motor_dropped;
    epd_board_metalio_eink4_plus_motor_set(false);
}

bool StandbyBlocksUi() {
    return s_standby.load(std::memory_order_acquire) ||
           s_presented_standby_revision.load(std::memory_order_acquire) !=
           s_standby_revision.load(std::memory_order_acquire);
}

// A screen sample captures this epoch on callback entry, before its admission
// checks. Never replace it with a fresh epoch after a Flash/lock boundary.
// Only this nonblocking queue operation runs on the touch sampling task; the
// independent motor task owns every I2C/aux lease and actual pulse timing.
void QueueMotorRequest(const MotorRequest& request) {
    ++s_motor_requested;
    if (!s_ready.load() || !s_motor_queue || StandbyBlocksUi() ||
        s_refresh_paused.load() || s_powered_down.load() ||
        request.epoch != s_motor_epoch.load(std::memory_order_acquire) ||
        xQueueSend(s_motor_queue, &request, 0) != pdTRUE) {
        ++s_motor_dropped;
        return;
    }
    ++s_motor_queued;
}

// Exact Plus frontlight PWM mapping: official UI level 1 maps to 0.2% duty.
// Keep the warm channel off. PWM stays attached when off; GPIO writes would
// not reliably disable an output still routed through the LEDC matrix.
constexpr uint32_t kFrontlightDuty = 2;
bool InitFrontlight() {
    ledc_timer_config_t timer{};
    timer.speed_mode = LEDC_LOW_SPEED_MODE;
    timer.timer_num = LEDC_TIMER_0;
    timer.duty_resolution = LEDC_TIMER_10_BIT;
    timer.freq_hz = 20000;
    timer.clk_cfg = LEDC_AUTO_CLK;
    if (ledc_timer_config(&timer) != ESP_OK) return false;
    for (int i = 0; i < 2; ++i) {
        ledc_channel_config_t channel{};
        channel.gpio_num = i == 0 ? FL_COOL_PIN : FL_WARM_PIN;
        channel.speed_mode = LEDC_LOW_SPEED_MODE;
        channel.channel = i == 0 ? LEDC_CHANNEL_0 : LEDC_CHANNEL_1;
        channel.intr_type = LEDC_INTR_DISABLE;
        channel.timer_sel = LEDC_TIMER_0;
        channel.duty = 0;
        if (ledc_channel_config(&channel) != ESP_OK) return false;
    }
    return true;
}
void Frontlight(bool on) {
    const esp_err_t set = ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0,
                                       on ? kFrontlightDuty : 0);
    const esp_err_t update = ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0);
    ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_1, 0);
    ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_1);
    if (set != ESP_OK || update != ESP_OK)
        ESP_LOGE(kTag, "frontlight PWM failed: set=%s update=%s",
                 esp_err_to_name(set), esp_err_to_name(update));
}

// Only used before normal HAL init, or after the UI has fully stopped. The
// existing poster remains on the bistable panel and no light is initialized.
void HoldFrontlightDark() {
    for (const auto pin : {FL_COOL_PIN, FL_WARM_PIN}) {
        gpio_set_level(pin, 0);
        gpio_hold_dis(pin);
        gpio_set_direction(pin, GPIO_MODE_OUTPUT);
        gpio_set_level(pin, 0);
        gpio_hold_en(pin);
    }
#if !SOC_GPIO_SUPPORT_HOLD_SINGLE_IO_IN_DSLP
    gpio_deep_sleep_hold_en();
#endif
}

bool ReadSleepKey(bool* down) {
    if (!down || !metalio_i2c1_lock(100)) return false;
    uint8_t port0 = 0xFF, port1 = 0xFF;
    // TCA INT is shared by its ports: read both to clear pending levels.
    const esp_err_t first = metalio_i2c1_read_reg_stop_locked(
        I2C_NUM_1, s_sleep_tca_addr, 0, &port0, 1, 100);
    const esp_err_t second = metalio_i2c1_read_reg_stop_locked(
        I2C_NUM_1, s_sleep_tca_addr, 1, &port1, 1, 100);
    metalio_i2c1_unlock();
    if (first != ESP_OK || second != ESP_OK) return false;
    *down = !(port1 & (1u << (EPD_IO_POWER & 7)));
    return true;
}

[[noreturn]] void EnterHardwareDeepSleep() {
    esp_sleep_disable_wakeup_source(ESP_SLEEP_WAKEUP_ALL);
    rtc_gpio_init(IO_EXPANDER_INT_GPIO);
    rtc_gpio_set_direction(IO_EXPANDER_INT_GPIO, RTC_GPIO_MODE_INPUT_ONLY);
    rtc_gpio_pullup_en(IO_EXPANDER_INT_GPIO);
    rtc_gpio_pulldown_dis(IO_EXPANDER_INT_GPIO);
    const bool irq_idle = rtc_gpio_get_level(IO_EXPANDER_INT_GPIO) != 0;
    esp_err_t wake = ESP_FAIL;
    if (irq_idle) wake = esp_sleep_enable_ext1_wakeup_io(
        1ULL << IO_EXPANDER_INT_GPIO, ESP_EXT1_WAKEUP_ANY_LOW);
    if (!irq_idle || wake != ESP_OK) {
        ESP_LOGW(kTag, "DEEP_WAKE timer fallback irq_idle=%d ext1=%s",
                 int(irq_idle), esp_err_to_name(wake));
        ESP_ERROR_CHECK(esp_sleep_enable_timer_wakeup(500000));
    }
    metalio_i2c1_deinit();
    HoldFrontlightDark();
    ESP_LOGI(kTag, "DEEP_SLEEP enter wake=%s hold=5000ms",
             irq_idle && wake == ESP_OK ? "GPIO2" : "timer");
    esp_deep_sleep_start();
    __builtin_unreachable();
}

// Caller owns s_aux_gate. Physical panel work already admitted may finish;
// new UI frames and all old/replayed input are rejected across this boundary.
void SetStandby(bool standby) {
    if (s_standby.load() == standby) return;
    // A tiny admission fence against the final LVGL snapshot. No panel lock is
    // taken on this power task (aux -> panel would invert the Flash lock order).
    if (xSemaphoreTake(s_frame_mu, pdMS_TO_TICKS(300)) != pdTRUE) return;
    s_standby.store(standby, std::memory_order_release);
    ++s_standby_revision;
    xSemaphoreGive(s_frame_mu);
    CancelTouch();
    metalio_touch_set_ui_suppress(true);
    s_cover_event.store(0);
    if (standby) {
        // Keep physical contact sampling for the idle deadline. CoverSample
        // still rejects all locked UI/cover actions and motor requests.
        CancelMotor();
        Frontlight(false);
    } else {
        Frontlight(true);
    }
    if (s_refresh_task) xTaskNotifyGive(s_refresh_task);
    ESP_LOGI(kTag, "POWER_STANDBY active=%d frontlight_duty=%u", int(standby),
             unsigned(standby ? 0 : kFrontlightDuty));
}

void PowerTask(void*) {
    plus_hal_detail::PowerKeyState key;
    uint32_t epoch = s_power_epoch.load();
    for (;;) {
        if (!s_ready.load() || s_powered_down.load() || s_refresh_paused.load()) {
            key.ResetUnknown();
            vTaskDelay(pdMS_TO_TICKS(20));
            continue;
        }
        if (xSemaphoreTake(s_aux_gate, pdMS_TO_TICKS(20)) != pdTRUE) continue;
        const uint32_t current_epoch = s_power_epoch.load(std::memory_order_acquire);
        if (current_epoch != epoch) {
            // Even a Flash lease shorter than one polling interval invalidates
            // the prior key level; it must be released before accepting a tap.
            key.ResetUnknown();
            epoch = current_epoch;
        }
        if (!s_refresh_paused.load() && !s_powered_down.load()) {
            uint8_t p1 = 0xFF;
            if (!epd_board_metalio_eink4_plus_ioexp_read_port(1, &p1)) {
                key.ResetUnknown();
            } else {
                const bool down = !(p1 & (1u << (EPD_IO_POWER & 7)));
                s_power_key_held.store(down, std::memory_order_release);
                const auto event = key.Sample(down, esp_timer_get_time());
                if (event == plus_hal_detail::PowerKeyEvent::ShortPress) {
                    RecordUserActivity();
                    if (s_standby.load() || s_standby_allowed.load())
                        SetStandby(!s_standby.load());
                    else ESP_LOGI(kTag, "standby deferred: operation in progress");
                } else if (event == plus_hal_detail::PowerKeyEvent::LongPress) {
                    RecordUserActivity();
                    // Wake the UI so the existing save/refusal path stays usable.
                    SetStandby(false);
                    s_power_off_requested.store(true);
                }
            }
        } else key.ResetUnknown();
        xSemaphoreGive(s_aux_gate);
        vTaskDelay(pdMS_TO_TICKS(20));
    }
}

void MotorTask(void*) {
    for (;;) {
        MotorRequest request{};
        if (xQueueReceive(s_motor_queue, &request, portMAX_DELAY) != pdTRUE) continue;
        xSemaphoreTake(s_aux_gate, portMAX_DELAY);
        if (request.epoch == s_motor_epoch.load(std::memory_order_acquire) &&
            !StandbyBlocksUi() && !s_refresh_paused.load() && !s_powered_down.load()) {
            epd_board_metalio_eink4_plus_motor_set(true);
            ++s_motor_started;
            const int64_t delay = esp_timer_get_time() - request.requested_us;
            const unsigned value = unsigned(std::min<int64_t>(delay, UINT32_MAX));
            if (value > s_motor_max_delay_us.load()) s_motor_max_delay_us.store(value);
            vTaskDelay(std::max<TickType_t>(1, pdMS_TO_TICKS(30)));
            epd_board_metalio_eink4_plus_motor_set(false);
            ++s_motor_finished;
        } else ++s_motor_dropped;
        xSemaphoreGive(s_aux_gate);
        // Keep pulses distinct without blocking the input or UI thread.
        vTaskDelay(std::max<TickType_t>(1, pdMS_TO_TICKS(10)));
    }
}

power_i2c_t PowerBus() {
    power_i2c_t bus{};
    bus.port = I2C_NUM_1;
    bus.lock = metalio_i2c1_lock;
    bus.unlock = metalio_i2c1_unlock;
    bus.device = metalio_i2c1_device_locked;
    return bus;
}

// The physical worker and a Flash writer use the same mutex. A Flash writer
// closes admission before waiting, so a new refresh cannot race an idle check.
class PanelLease {
public:
    explicit PanelLease(bool owns) : owns_(owns) {}
    ~PanelLease() { if (owns_) xSemaphoreGive(s_panel_gate); }
    PanelLease(const PanelLease&) = delete;
    PanelLease& operator=(const PanelLease&) = delete;
private:
    bool owns_;
};

void CoverSample(uint8_t count, int raw_x, int raw_y, int lx, int ly) {
    const uint32_t motor_epoch = s_motor_epoch.load(std::memory_order_acquire);
    if (s_panel_busy.load(std::memory_order_relaxed)) ++s_touch_samples_during_refresh;
    static bool finger_down = false; // Only the touch feed task uses this.
    // The driver invokes this only for normalized, successful samples. Count
    // idle activity before the short-lock/scene UI fence, without waking it.
    if (count && s_ready.load(std::memory_order_acquire) &&
        !s_powered_down.load() && !s_refresh_paused.load()) RecordUserActivity();
    if (!s_ready.load(std::memory_order_acquire) || s_powered_down.load() || StandbyBlocksUi() ||
        s_refresh_paused.load() || ScenePending()) {
        metalio_touch_set_ui_suppress(true);
        finger_down = false;
        return;
    }
    // The three cover keys report outside the panel (Y near 1600).
    // They must never be clamped into an accidental bottom-edge UI press.
    const bool cover = count && (raw_y >= kHeight || raw_x >= kHeight);
    metalio_touch_set_ui_suppress(cover || s_touch_wait_release.load());
    bool feedback = false;
    MotorRequest feedback_request{};
    portENTER_CRITICAL(&s_input_mu);
    // A scene/Flash fence can cross this sample after the first admission
    // check. Queue admission and its epoch reset use this same short lock.
    if (!s_powered_down.load() && !StandbyBlocksUi() && !s_refresh_paused.load() && !ScenePending()) {
        // A cover key is not the release needed to re-arm a layout boundary.
        const bool waiting_release = s_touch_queue.WaitingRelease();
        // A recovered old-contact/new-DOWN boundary is a release for an active
        // gesture, but is not proof that a finger lifted after a scene fence.
        const bool admissible_release = count || !waiting_release ||
                                        metalio_touch_sample_confirms_release();
        if ((!cover || !waiting_release) && admissible_release) {
            const int64_t sampled_us = esp_timer_get_time();
            const auto sample = pocket_hal_detail::SampleWithFeedback(s_touch_queue, count && !cover,
                std::clamp(lx, 0, kWidth - 1), std::clamp(ly, 0, kHeight - 1),
                sampled_us);
            if (!sample.accepted) s_cover_event.store(0);
            if (sample.new_down) {
                feedback = true;
                feedback_request = {motor_epoch, sampled_us};
                ++s_screen_feedback_requests;
            }
            // The three recognized cover keys are separate from screen LVGL
            // coordinates. A newly received physical key gets one pulse too.
            // Publish under the same fence lock CancelTouch uses, so a stale
            // cover event cannot cross a scene boundary after admission.
            if (sample.accepted && count && cover && !finger_down &&
                !s_touch_queue.WaitingRelease() && std::abs(raw_y - TOUCH_VK_Y) <= TOUCH_VK_TOL) {
                int key = 0;
                if (std::abs(raw_x - TOUCH_VK_HOME_X) <= TOUCH_VK_TOL) key = 1;
                else if (std::abs(raw_x - TOUCH_VK_PREV_X) <= TOUCH_VK_TOL) key = 2;
                else if (std::abs(raw_x - TOUCH_VK_NEXT_X) <= TOUCH_VK_TOL) key = 3;
                if (key) {
                    s_cover_event.store(key, std::memory_order_release);
                    feedback = true;
                    feedback_request = {motor_epoch, sampled_us};
                    ++s_cover_feedback_requests;
                }
            }
        }
        s_touch_wait_release.store(s_touch_queue.WaitingRelease(), std::memory_order_release);
    }
    portEXIT_CRITICAL(&s_input_mu);
    if (feedback) QueueMotorRequest(feedback_request);
    if (s_touch_wait_release.load()) { finger_down = false; return; }
    if (!count) {
        finger_down = false;
        metalio_touch_set_ui_suppress(false);
        return;
    }
    finger_down = true;
}

void TouchRead(lv_indev_t* indev, lv_indev_data_t* data) {
    ++s_input_reads;
    static uint32_t delivered_epoch = 0;
    static bool delivered_down = false;
    static lv_point_t delivered_point{};
    pocket_hal_detail::TouchEvent event{};
    bool popped = false, more = false;
    uint32_t epoch = 0;
    portENTER_CRITICAL(&s_input_mu);
    epoch = s_touch_queue.Epoch();
    const bool blocked = StandbyBlocksUi() || s_refresh_paused.load() ||
                         s_touch_wait_release.load() || ScenePending();
    if (!blocked && epoch == delivered_epoch) {
        popped = s_touch_queue.Pop(&event, esp_timer_get_time());
        more = s_touch_queue.Size() != 0;
    } else if (!blocked) more = s_touch_queue.Size() != 0;
    portEXIT_CRITICAL(&s_input_mu);
    data->continue_reading = false;
    if (epoch != delivered_epoch) {
        delivered_epoch = epoch;
        delivered_down = false;
        lv_indev_reset(indev, nullptr);
        data->state = LV_INDEV_STATE_RELEASED;
        data->continue_reading = more;
        return;
    }
    if (blocked) {
        delivered_down = false;
        // The hardware task publishes its blocked flag before CancelTouch
        // advances the epoch. Cancel LVGL's gesture in that small interval as
        // well; a synthetic release must never finish an old button click.
        lv_indev_reset(indev, nullptr);
        data->state = LV_INDEV_STATE_RELEASED;
        return;
    }
    // Power/Flash may invalidate between dequeue and delivery. Never convert
    // that cancellation into a button release on the next visible scene.
    portENTER_CRITICAL(&s_input_mu);
    const bool stale = epoch != s_touch_queue.Epoch() || StandbyBlocksUi() ||
                       s_refresh_paused.load() || ScenePending();
    portEXIT_CRITICAL(&s_input_mu);
    if (stale) {
        delivered_down = false;
        lv_indev_reset(indev, nullptr);
        data->state = LV_INDEV_STATE_RELEASED;
        return;
    }
    if (popped) {
        delivered_point.x = event.x;
        delivered_point.y = event.y;
        delivered_down = event.kind != pocket_hal_detail::TouchKind::Up;
    }
    if (delivered_down) ++s_input_down_reads;
    data->point = delivered_point;
    data->state = delivered_down ? LV_INDEV_STATE_PRESSED : LV_INDEV_STATE_RELEASED;
    // LVGL must see every down AND up, including a complete quick tap sampled
    // between timer ticks. Do not collapse this FIFO back to a current snapshot.
    data->continue_reading = more;
}

void AccumulateTiming(std::atomic<unsigned>& total, std::atomic<unsigned>& maximum,
                      int64_t elapsed) {
    const unsigned us = unsigned(std::min<int64_t>(std::max<int64_t>(0, elapsed), UINT32_MAX));
    total.fetch_add(us, std::memory_order_relaxed);
    // Each timer/flush timing pair has only the LVGL thread as its writer.
    if (us > maximum.load(std::memory_order_relaxed)) maximum.store(us, std::memory_order_relaxed);
}

bool RenderGateBlocks() {
    if (!s_ready.load() || StandbyBlocksUi() || s_powered_down.load() ||
        s_refresh_paused.load() || s_panel_busy.load()) return true;
    const uint32_t pending = s_pending_generation.load(std::memory_order_acquire);
    const bool waiting = pending && pending > s_completed_generation.load(std::memory_order_acquire);
    // A permanently failed physical frame must not leave LVGL's software
    // renderer paused forever. Its bounded automatic retry finishes first;
    // subsequent dirty state or a user full-refresh can attempt recovery.
    if (waiting && s_failed_generation.load(std::memory_order_acquire) == pending &&
        !s_frame_retry_pending.load(std::memory_order_acquire)) return false;
    return waiting;
}

bool RenderIntervalWaits() {
    // First frame, layout, explicit Ink and the switch presentation do not
    // wait for an ordinary text-update interval. ScenePending never forbids
    // rendering: that would deadlock its required next physical frame.
    if (!s_last_snapshot_us || ScenePending() || s_force_full.load() ||
        s_switch_request.load() != s_switch_submitted.load()) return false;
    return esp_timer_get_time() - s_last_snapshot_us < 80000;
}

void PauseSoftwareRendering(lv_timer_t* timer) {
    if (!s_software_gate_paused.exchange(true)) ++s_gate_pauses;
    lv_timer_pause(timer);
}

void GatedRefreshTimer(lv_timer_t* timer) {
    ++s_refr_callbacks;
    // LVGL invalidation itself resumes its display timer, including from an
    // indev callback within the same timer_handler(). Recheck here as well as
    // in ServiceRendering so newly typed text cannot bypass the physical gate.
    if (RenderGateBlocks() || RenderIntervalWaits()) {
        ++s_refr_deferred;
        PauseSoftwareRendering(timer);
        return;
    }
    if (s_software_gate_paused.exchange(false)) ++s_gate_resumes;
    const int64_t started = esp_timer_get_time();
    lv_display_refr_timer(timer); // Public LVGL 9.4 original display callback.
    AccumulateTiming(s_refr_total_us, s_refr_max_us, esp_timer_get_time() - started);
}

struct FlushTiming {
    int64_t started = esp_timer_get_time();
    FlushTiming() { ++s_flush_calls; }
    ~FlushTiming() { AccumulateTiming(s_flush_total_us, s_flush_max_us,
                                     esp_timer_get_time() - started); }
};

void NativePixel(uint8_t* frame, int x, int y, uint8_t gray) {
    const int px = y, py = kWidth - 1 - x;
    uint8_t& b = frame[size_t(py) * (kHeight / 2) + px / 2];
    if (px & 1) b = uint8_t((b & 0x0F) | (gray << 4));
    else b = uint8_t((b & 0xF0) | gray);
}

void Flush(lv_display_t* display, const lv_area_t* area, uint8_t* pixels) {
    const FlushTiming timing;
    if (!s_render || !pixels || !area || StandbyBlocksUi() || s_powered_down.load() ||
        s_refresh_paused.load()) {
        lv_display_flush_ready(display);
        return;
    }
    const uint32_t stride = lv_draw_buf_width_to_stride(
        static_cast<uint32_t>(lv_area_get_width(area)), LV_COLOR_FORMAT_L8);
    const int x1 = std::max<int>(0, area->x1), y1 = std::max<int>(0, area->y1);
    const int x2 = std::min<int>(kWidth-1, area->x2), y2 = std::min<int>(kHeight-1, area->y2);
    for (int y = y1; y <= y2; ++y) {
        const uint8_t* row = pixels + size_t(y-area->y1) * stride;
        for (int x = x1; x <= x2; ++x) {
            const uint8_t gray = row[x-area->x1] >= kUiWhiteThreshold ? 15 : 0;
            NativePixel(s_render, x, y, gray);
        }
    }
    if (lv_display_flush_is_last(display)) {
        if (xSemaphoreTake(s_frame_mu, pdMS_TO_TICKS(300)) == pdTRUE) {
            if (StandbyBlocksUi() || s_powered_down.load() || s_refresh_paused.load()) {
                xSemaphoreGive(s_frame_mu);
                lv_display_flush_ready(display);
                return;
            }
            // Snapshot only after the final LVGL stripe: worker never sees a
            // partially rendered frame or a buffer still being reused by LVGL.
            if (s_pending_generation.load() > s_completed_generation.load())
                ++s_snapshot_replaced;
            memcpy(s_pending, s_render, kFrameBytes);
            ++s_pending_generation;
            ++s_frame_snapshots;
            s_last_snapshot_us = esp_timer_get_time();
            xSemaphoreGive(s_frame_mu);
            xTaskNotifyGive(s_refresh_task);
        } else {
            ESP_LOGE(kTag, "frame snapshot lock timed out");
            s_force_full.store(true);
            lv_obj_invalidate(lv_display_get_screen_active(display));
        }
    }
    lv_display_flush_ready(display);
}

// Caller holds the physical panel gate. All application/overlay/deep frames use
// this path so a refusal can restore the real screen before reopening input.
bool DrawNativeFrame(bool force, const char* purpose, unsigned generation) {
    auto* hl = MetalioEpd_Hl();
    const bool known = s_panel_state_known.load(std::memory_order_acquire);
    bool changed = false;
    for (size_t i = 0; i < kFrameBytes; ++i) {
        if (hl->back_fb[i] != hl->front_fb[i]) { changed = true; break; }
    }
    if (!changed && !force && known) return true;
    const int64_t started = esp_timer_get_time();
    const bool full = force || !known;
    const EpdDrawMode mode = full ? MODE_GC16 : MODE_DU;
    s_panel_busy.store(true);
    // Touch and panel-power transactions share the I2C mutex. Do not suspend
    // the touch sampler during ordinary ink refresh: an entire short tap can
    // otherwise disappear inside the several-hundred-ms waveform window.
    // Flash/deep-sleep retain sampling pause boundaries. Short lock suppresses
    // UI dispatch but continues sampling only to update the idle deadline.
    epd_poweron();
    EpdDrawError err = EPD_DRAW_SUCCESS;
    if (!epd_board_metalio_eink4_plus_tps_ok()) {
        err = EPD_DRAW_EMPTY_LINE_QUEUE;
    } else {
        if (!known) {
            err = epd_clear_checked();
            if (err == EPD_DRAW_SUCCESS)
                err = epd_hl_update_screen_from_white(hl, MODE_GC16, 25);
        } else if (full) {
            err = epd_hl_update_screen_full(hl, mode, 25);
        } else {
            err = epd_hl_update_screen(hl, mode, 25);
        }
        if (err != EPD_DRAW_SUCCESS) {
            ESP_LOGW(kTag, "refresh 0x%x, retry full once", unsigned(err));
            err = epd_clear_checked();
            if (err == EPD_DRAW_SUCCESS)
                err = epd_hl_update_screen_from_white(hl, MODE_GC16, 25);
        }
    }
    epd_poweroff();
    s_panel_busy.store(false);
    s_refresh_error.store(int(err));
    const bool displayed = err == EPD_DRAW_SUCCESS;
    s_panel_state_known.store(displayed, std::memory_order_release);
    if (displayed) ++s_refreshes;
    else s_force_full.store(true);
    ESP_LOGI(kTag, "frame=%u purpose=%s mode=%s result=0x%x elapsed=%lldms",
             generation, purpose, full ? "GC16" : "DU", unsigned(err),
             (long long)((esp_timer_get_time() - started) / 1000));
    return displayed;
}

void RefreshTask(void*) {
    auto* hl = MetalioEpd_Hl();
    bool overlay_visible = false;
    unsigned drawn_generation = 0;
    bool retry_wait = false;
    unsigned retry_generation = 0, retry_attempts = 0;
    const auto failed = [&](unsigned generation) {
        if (retry_generation != generation) {
            retry_generation = generation;
            retry_attempts = 0;
        }
        // DrawNativeFrame already makes one clear/GC16 recovery attempt.
        // Admit only one later retry of this complete generation, then let
        // newer dirty state/manual Ink recover without a permanently shut gate.
        retry_wait = retry_attempts++ == 0;
        if (retry_wait) ++s_frame_retries;
        s_frame_retry_pending.store(retry_wait, std::memory_order_release);
        s_failed_generation.store(generation, std::memory_order_release);
    };
    const auto succeeded = [&]() {
        retry_wait = false;
        retry_generation = retry_attempts = 0;
        s_failed_generation.store(0, std::memory_order_release);
        s_frame_retry_pending.store(false, std::memory_order_release);
    };
    // Lock overlays never acknowledge an application/switch presentation.
    for (;;) {
        ulTaskNotifyTake(pdTRUE, retry_wait ? pdMS_TO_TICKS(250) : portMAX_DELAY);
        retry_wait = false;
        if (s_refresh_paused.load(std::memory_order_acquire)) continue;
        if (xSemaphoreTake(s_panel_gate, pdMS_TO_TICKS(300)) != pdTRUE) {
            if (!s_refresh_paused.load()) xTaskNotifyGive(xTaskGetCurrentTaskHandle());
            continue;
        }
        PanelLease panel_lease(true);
        if (s_refresh_paused.load(std::memory_order_acquire)) continue;
        if (xSemaphoreTake(s_frame_mu, pdMS_TO_TICKS(300)) != pdTRUE) {
            s_force_full.store(true);
            xTaskNotifyGive(xTaskGetCurrentTaskHandle());
            vTaskDelay(pdMS_TO_TICKS(20));
            continue;
        }
        unsigned generation = s_pending_generation.load();
        const bool force = s_force_full.exchange(false);
        const bool wants_lock = s_standby.load(std::memory_order_acquire);
        const bool needs_app = generation && (generation != drawn_generation ||
                               (!wants_lock && (force || overlay_visible)));
        if (needs_app) memcpy(hl->front_fb, s_pending, kFrameBytes);
        xSemaphoreGive(s_frame_mu);

        // Drain every app snapshot admitted before the lock fence first. This
        // is the sole path advancing the completed application generation.
        if (needs_app) {
            const bool new_application_frame = generation != drawn_generation;
            if (!DrawNativeFrame(force, overlay_visible ? "wake" : "application", generation)) {
                failed(generation);
                continue;
            }
            succeeded();
            drawn_generation = generation;
            overlay_visible = false;
            if (new_application_frame)
                s_completed_generation.store(generation, std::memory_order_release);
        }
        if (s_pending_generation.load() != drawn_generation) {
            xTaskNotifyGive(xTaskGetCurrentTaskHandle());
            continue;
        }

        // Coalesce rapid key toggles to the latest request after any app draw.
        const uint32_t revision = s_standby_revision.load(std::memory_order_acquire);
        const bool standby = s_standby.load(std::memory_order_acquire);
        if (standby) {
            if (!overlay_visible) {
                DrawPocketLockScreen(hl->front_fb);
                if (!DrawNativeFrame(force, "lock", generation)) {
                    failed(generation);
                    continue;
                }
                succeeded();
                overlay_visible = true;
            }
        } else if (overlay_visible) {
            // A wake arrived during the preceding application/lock refresh.
            if (xSemaphoreTake(s_frame_mu, pdMS_TO_TICKS(300)) != pdTRUE) {
                xTaskNotifyGive(xTaskGetCurrentTaskHandle());
                continue;
            }
            generation = s_pending_generation.load();
            memcpy(hl->front_fb, s_pending, kFrameBytes);
            xSemaphoreGive(s_frame_mu);
            if (!DrawNativeFrame(force, "wake", generation)) {
                failed(generation);
                continue;
            }
            succeeded();
            overlay_visible = false;
            // Any newly admitted business frame was rendered here for real.
            if (generation != drawn_generation) {
                drawn_generation = generation;
                s_completed_generation.store(generation, std::memory_order_release);
            }
        }
        if (revision == s_standby_revision.load(std::memory_order_acquire) &&
            standby == s_standby.load(std::memory_order_acquire)) {
            s_presented_standby_revision.store(revision, std::memory_order_release);
            ESP_LOGI(kTag, "LOCK_SCREEN_PRESENTED active=%d epoch=%u app_frame=%u",
                     int(standby), unsigned(revision), generation);
        } else xTaskNotifyGive(xTaskGetCurrentTaskHandle());
        vTaskDelay(pdMS_TO_TICKS(5));
    }
}
bool Fail(std::string* error, const char* text) {
    if (error) *error = text;
    ESP_LOGE(kTag, "%s", text);
    return false;
}

int FromBcd(uint8_t v) { return int((v >> 4) * 10 + (v & 15)); }
} // namespace

extern "C" void MetalioSd_ReleaseHold(void) {
    const gpio_num_t pins[] = {SDMMC_CLK_PIN, SDMMC_CMD_PIN, SDMMC_D0_PIN,
        SDMMC_D1_PIN, SDMMC_D2_PIN, SDMMC_D3_PIN};
    for (auto pin : pins) gpio_hold_dis(pin);
}

namespace pocket_hal {
void EarlyWakeGate() {
    const auto cause = esp_sleep_get_wakeup_cause();
    if (s_deep_sleep_magic != kDeepSleepMagic || cause == ESP_SLEEP_WAKEUP_UNDEFINED) {
        s_deep_sleep_magic = 0;
        return;
    }
    HoldFrontlightDark();
    rtc_gpio_deinit(IO_EXPANDER_INT_GPIO);
    if (metalio_i2c1_init(I2C_SDA_PIN, I2C_SCL_PIN) != ESP_OK)
        EnterHardwareDeepSleep();
    plus_hal_detail::WakeHoldGate hold;
    for (;;) {
        bool down = false;
        if (!ReadSleepKey(&down) || !down) {
            ESP_LOGI(kTag, "DEEP_WAKE rejected: short/released/non-power wake");
            EnterHardwareDeepSleep();
        }
        if (hold.Sample(down, esp_timer_get_time())) break;
        vTaskDelay(pdMS_TO_TICKS(20));
    }
    s_deep_sleep_magic = 0;
    s_woke_from_deep_sleep = true;
    esp_sleep_disable_wakeup_source(ESP_SLEEP_WAKEUP_ALL);
    rtc_gpio_deinit(IO_EXPANDER_INT_GPIO);
#if !SOC_GPIO_SUPPORT_HOLD_SINGLE_IO_IN_DSLP
    gpio_deep_sleep_hold_dis();
#endif
    // Normal board init releases retained EPD/light holds. Runtime scanner
    // ignores this still-held wake gesture until its first confirmed release.
    ESP_LOGI(kTag, "DEEP_WAKE accepted: continuous power hold=5000ms pin_required=1");
}
bool WokeFromDeepSleep() { return s_woke_from_deep_sleep; }

bool Init(std::string* error) {
    if (s_ready) return true;
    if (!esp_psram_is_initialized()) return Fail(error, "PSRAM initialization failed");
    if (!MetalioEpd_Init()) return Fail(error, "EPD/TPS65185 initialization failed");
    if (!metalio_touch_init()) return Fail(error, "FT6336U touch initialization failed");
    metalio_touch_set_sample_cb(CoverSample);
    // One owner only: the queued worker drives full on/off directly. Do not
    // initialize the former timer-based VibeEngine alongside this worker.
    epd_board_metalio_eink4_plus_motor_set(false);
    auto bus = PowerBus();
    Bq27220Gauge::GetInstance().Begin(&bus);
    if (power_i2c_probe(&bus, CX25601N_I2C_ADDR, 100) == ESP_OK) {
        const auto charge_err = cx25601n_init(&bus);
        if (charge_err == ESP_OK) {
            cx25601n_set_ichg_ma(1000);
            cx25601n_enable_charge(true);
        } else ESP_LOGW(kTag, "charger init: %s", esp_err_to_name(charge_err));
    }
    if (!InitFrontlight()) return Fail(error, "frontlight PWM initialization failed");
    Frontlight(true);

    if (!SdCardManager::GetInstance().Mount())
        ESP_LOGW(kTag, "TF not mounted; pocket UI remains available for diagnosis");
    UsbVirtualDisk::GetInstance().Init();
    s_frame_mu = xSemaphoreCreateMutex();
    s_panel_gate = xSemaphoreCreateMutex();
    s_aux_gate = xSemaphoreCreateMutex();
    s_motor_queue = xQueueCreate(32, sizeof(MotorRequest));
    if (!s_frame_mu || !s_panel_gate || !s_aux_gate || !s_motor_queue)
        return Fail(error, "hardware mutex allocation failed");
    s_render = static_cast<uint8_t*>(heap_caps_aligned_alloc(64, kFrameBytes,
        MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
    s_pending = static_cast<uint8_t*>(heap_caps_aligned_alloc(64, kFrameBytes,
        MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
    const size_t draw_bytes = lv_draw_buf_width_to_stride(kWidth, LV_COLOR_FORMAT_L8)*64;
    auto* draw = static_cast<uint8_t*>(heap_caps_aligned_alloc(64, draw_bytes,
        MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
    if (!s_render || !s_pending || !draw)
        return Fail(error, "display framebuffer allocation failed");
    memset(s_render, 0xFF, kFrameBytes);
    memset(s_pending, 0xFF, kFrameBytes);
    if (xTaskCreate(RefreshTask, "pocket_epd", 8192, nullptr, 3, &s_refresh_task) != pdPASS)
        return Fail(error, "display worker creation failed");

    lv_tick_set_cb([]() -> uint32_t { return uint32_t(esp_timer_get_time()/1000); });
    auto* display = lv_display_create(kWidth, kHeight);
    if (!display) return Fail(error, "LVGL display creation failed");
    lv_display_set_default(display);
    lv_display_set_color_format(display, LV_COLOR_FORMAT_L8);
    lv_display_set_buffers(display, draw, nullptr, draw_bytes, LV_DISPLAY_RENDER_MODE_PARTIAL);
    lv_display_set_flush_cb(display, Flush);
    s_display_refr_timer = lv_display_get_refr_timer(display);
    if (!s_display_refr_timer) return Fail(error, "LVGL refresh timer missing");
    lv_timer_set_cb(s_display_refr_timer, GatedRefreshTimer);
    auto* indev = lv_indev_create();
    if (!indev) return Fail(error, "LVGL input creation failed");
    s_indev = indev;
    lv_indev_set_type(indev, LV_INDEV_TYPE_POINTER);
    lv_indev_set_read_cb(indev, TouchRead);
    lv_indev_set_display(indev, display);
    // Deliver press and release independently even with quick numeric input.
    if (auto* input_timer = lv_indev_get_read_timer(indev))
        lv_timer_set_period(input_timer, 10);
    if (xTaskCreatePinnedToCoreWithCaps(PowerTask, "pocket_power", 4096, nullptr, 3,
            nullptr, 0, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT) != pdPASS)
        return Fail(error, "power service creation failed");
    if (xTaskCreatePinnedToCoreWithCaps(MotorTask, "pocket_motor", 4096, nullptr, 3,
            nullptr, 0, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT) != pdPASS)
        return Fail(error, "motor service creation failed");
    RecordUserActivity();
    s_ready = true;
    ESP_LOGI(kTag, "ready: logical=684x1216 TF=%d touch=1",
             int(SdCardManager::GetInstance().IsMounted()));
    return true;
}
void Pulse() {
    const MotorRequest request{s_motor_epoch.load(std::memory_order_acquire),
                               esp_timer_get_time()};
    QueueMotorRequest(request);
}
void InvalidateInput() {
    // LVGL owns pending publication, so this target cannot be a stripe or a
    // snapshot already admitted before the scene change. A later generation
    // is also acceptable because it contains the latest complete scene.
    s_scene_generation.store(s_pending_generation.load(std::memory_order_acquire) + 1,
                             std::memory_order_release);
    CancelTouch();
    if (s_indev) lv_indev_reset(s_indev, nullptr);
    auto* display = lv_display_get_default();
    if (display) lv_obj_invalidate(lv_display_get_screen_active(display));
}
void ServiceRendering() {
    if (!s_display_refr_timer) return;
    ++s_gate_checks;
    if (RenderGateBlocks() || RenderIntervalWaits()) {
        ++s_gate_waits;
        PauseSoftwareRendering(s_display_refr_timer);
        return;
    }
    if (s_software_gate_paused.exchange(false)) {
        ++s_gate_resumes;
        // Dirty areas accumulated while busy remain owned by LVGL. Resume
        // exactly once, rendering their latest contents in one new snapshot.
        lv_timer_resume(s_display_refr_timer);
        lv_timer_ready(s_display_refr_timer);
    }
}
void RecordUiCycle(uint32_t elapsed_us) {
    ++s_ui_cycles;
    AccumulateTiming(s_ui_total_us, s_ui_max_us, elapsed_us);
}
const char* PollHardwareKey() {
    if (StandbyBlocksUi() || s_refresh_paused.load() || s_touch_wait_release.load()) {
        s_cover_event.store(0);
        return nullptr;
    }
    switch (s_cover_event.exchange(0, std::memory_order_acq_rel)) {
        case 1: return "home";
        case 2: return "prev";
        case 3: return "next";
        default: return nullptr;
    }
}
bool PollPowerOff() {
    return s_power_off_requested.exchange(false, std::memory_order_acq_rel);
}
uint64_t LastUserActivityMs() {
    portENTER_CRITICAL(&s_activity_mu);
    const uint64_t activity = s_last_user_activity_ms;
    portEXIT_CRITICAL(&s_activity_mu);
    return activity;
}
bool IdleSleepDue() {
    return s_ready.load() && !s_powered_down.load() && !s_power_key_held.load() &&
           plus_hal_detail::IdleSleepPolicy::Expired(
               uint64_t(esp_timer_get_time() / 1000), LastUserActivityMs());
}
bool IsStandby() { return StandbyBlocksUi(); }
uint32_t StandbyRevision() { return s_standby_revision.load(std::memory_order_acquire); }
unsigned FrontlightDuty() {
    return s_standby.load() || s_powered_down.load() ? 0 : kFrontlightDuty;
}
void SetStandbyAllowed(bool allowed) { s_standby_allowed.store(allowed); }
void RequestFullRefresh() {
    s_force_full.store(true);
    if (s_refresh_task) xTaskNotifyGive(s_refresh_task);
}
uint32_t RequestSwitchPresentation() {
    return s_switch_request.fetch_add(1, std::memory_order_acq_rel) + 1;
}
void CommitSwitchPresentation() {
    const uint32_t request = s_switch_request.load(std::memory_order_acquire);
    if (!request || s_switch_submitted.load(std::memory_order_acquire) == request) return;
    auto* display = lv_display_get_default();
    if (!display || !s_ready) return;
    // This runs at the end of the UI's switch-page Render(), on the LVGL
    // thread. The last flush publishes one complete frame, not just a timer tick.
    const uint32_t before = s_pending_generation.load(std::memory_order_acquire);
    lv_obj_invalidate(lv_display_get_screen_active(display));
    lv_refr_now(display);
    const uint32_t generation = s_pending_generation.load(std::memory_order_acquire);
    if (!generation || generation == before) return;
    s_switch_generation.store(generation, std::memory_order_relaxed);
    s_switch_submitted.store(request, std::memory_order_release);
}
bool BeginFlashWrite(uint32_t presentation, uint32_t timeout_ms) {
    if (!s_panel_gate || !s_refresh_task || s_flash_owner || s_powered_down.load()) return false;
    const int64_t deadline = esp_timer_get_time() + int64_t(timeout_ms) * 1000;
    uint32_t generation = 0;
    while (presentation && esp_timer_get_time() < deadline) {
        if (s_switch_submitted.load(std::memory_order_acquire) == presentation) {
            generation = s_switch_generation.load(std::memory_order_acquire);
            if (generation && s_completed_generation.load(std::memory_order_acquire) >= generation)
                break;
        }
        vTaskDelay(pdMS_TO_TICKS(10));
    }
    if (presentation && (!generation || s_completed_generation.load(std::memory_order_acquire) < generation)) {
        ESP_LOGE(kTag, "switch page presentation timed out request=%u generation=%u",
                 unsigned(presentation), unsigned(generation));
        return false;
    }
    bool expected = false;
    if (!s_refresh_paused.compare_exchange_strong(expected, true, std::memory_order_acq_rel))
        return false;
    ++s_power_epoch;
    ++s_motor_epoch;
    CancelTouch();
    const int64_t remaining_us = deadline - esp_timer_get_time();
    const TickType_t wait = remaining_us > 0
        ? pdMS_TO_TICKS(uint32_t(remaining_us / 1000) + 1) : 0;
    if (xSemaphoreTake(s_panel_gate, wait) != pdTRUE) {
        s_refresh_paused.store(false, std::memory_order_release);
        xTaskNotifyGive(s_refresh_task);
        ESP_LOGE(kTag, "panel quiesce timed out before Flash write");
        return false;
    }
    // The new power scanner and every UI motor start also own this gate. Drain
    // them before retaining I2C, so neither can run a synchronous transaction
    // from a Flash-disabled interval. The touch feed rechecks its pause flag
    // after acquiring I2C, including a read already queued before this pause.
    const auto ticks_left = [deadline]() -> TickType_t {
        const int64_t us = deadline - esp_timer_get_time();
        return us > 0 ? pdMS_TO_TICKS(uint32_t((us + 999) / 1000)) : 0;
    };
    if (xSemaphoreTake(s_aux_gate, ticks_left()) != pdTRUE) {
        xSemaphoreGive(s_panel_gate);
        s_refresh_paused.store(false, std::memory_order_release);
        xTaskNotifyGive(s_refresh_task);
        ESP_LOGE(kTag, "power service quiesce timed out before Flash write");
        return false;
    }
    metalio_touch_set_feed_paused(true);
    CancelTouch();
    metalio_touch_set_ui_suppress(true);
    s_cover_event.store(0);
    CancelMotor();
    const int64_t i2c_us = deadline - esp_timer_get_time();
    if (!metalio_i2c1_lock_for_flash(i2c_us > 0 ? int((i2c_us + 999) / 1000) : 0)) {
        metalio_touch_set_feed_paused(false);
        xSemaphoreGive(s_aux_gate);
        xSemaphoreGive(s_panel_gate);
        s_refresh_paused.store(false, std::memory_order_release);
        xTaskNotifyGive(s_refresh_task);
        ESP_LOGE(kTag, "I2C quiesce timed out before Flash write");
        return false;
    }
    s_flash_i2c_held = true;
    s_flash_owner = xTaskGetCurrentTaskHandle();
    ESP_LOGI(kTag, "FLASH_DISPLAY_QUIESCED request=%u frame=%u",
             unsigned(presentation), unsigned(generation));
    return true;
}
void EndFlashWrite() {
    if (s_flash_owner != xTaskGetCurrentTaskHandle()) return;
    if (s_flash_i2c_held) { metalio_i2c1_unlock(); s_flash_i2c_held = false; }
    metalio_touch_set_feed_paused(false);
    s_flash_owner = nullptr;
    xSemaphoreGive(s_aux_gate);
    xSemaphoreGive(s_panel_gate);
    s_refresh_paused.store(false, std::memory_order_release);
    xTaskNotifyGive(s_refresh_task);
    ESP_LOGI(kTag, "FLASH_DISPLAY_RESUMED");
}
bool UsbActive() { return UsbVirtualDisk::GetInstance().IsGadgetActive(); }
bool UsbBusy() { return UsbVirtualDisk::GetInstance().IsBusy(); }
bool UsbExported() { return UsbVirtualDisk::GetInstance().IsSdExportedToHost(); }
bool TfMounted() {
    return !UsbBusy() && !UsbActive() && SdCardManager::GetInstance().IsMounted();
}
bool MountTf() {
    if (UsbBusy() || UsbActive()) return false;
    return SdCardManager::GetInstance().Mount();
}
bool UnmountTf() {
    if (UsbBusy() || UsbActive()) return false;
    return SdCardManager::GetInstance().Unmount();
}
void ToggleUsb() { UsbVirtualDisk::GetInstance().Toggle(); }
std::string UsbHint() {
    auto& usb = UsbVirtualDisk::GetInstance();
    return UsbVirtualDisk::HintText(usb.GetUiHint());
}
bool PanelBusy() { return s_panel_busy.load(); }
unsigned RefreshCount() { return s_refreshes.load(); }
int LastRefreshError() { return s_refresh_error.load(); }
void PrintInputDiagnostics() {
    ESP_LOGI(kTag, "TOUCH_FEEDBACK screen_down_requests=%u cover_down_requests=%u",
             s_screen_feedback_requests.load(), s_cover_feedback_requests.load());
    const auto t = metalio_touch_stats();
    pocket_hal_detail::TouchQueueStats queue_stats{};
    unsigned queued = 0, epoch = 0;
    portENTER_CRITICAL(&s_input_mu);
    queue_stats = s_touch_queue.Stats();
    queued = unsigned(s_touch_queue.Size());
    epoch = s_touch_queue.Epoch();
    portEXIT_CRITICAL(&s_input_mu);
    ESP_LOGI(kTag, "INPUT_STATUS ok=%d samples=%lu errors=%lu last_error=0x%x irqs=%lu irq_level=%d pause=%d lv_reads=%u lv_down=%u samples_during_refresh=%u",
        int(t.ok), (unsigned long)t.samples, (unsigned long)t.read_errors,
        t.last_error, (unsigned long)t.irqs, t.irq_level,
        t.pause_depth, s_input_reads.load(), s_input_down_reads.load(),
        s_touch_samples_during_refresh.load());
    ESP_LOGI(kTag, "INPUT_FIFO press=%u release=%u in=%u out=%u pending=%u overflow=%u epoch_discard=%u move_merge=%u move_skip=%u epoch=%u scene_target=%u completed=%u max_delay_us=%u",
        queue_stats.presses, queue_stats.releases, queue_stats.enqueued, queue_stats.delivered,
        queued, queue_stats.overflow, queue_stats.discarded, queue_stats.moves_merged,
        queue_stats.moves_skipped, epoch, unsigned(s_scene_generation.load()),
        unsigned(s_completed_generation.load()), queue_stats.max_delivery_us);
    ESP_LOGI(kTag, "TOUCH_REPORT zero=%lu down=%lu up=%lu contact=%lu reserved=%lu multi=%lu duplicate_down=%lu recovered=%lu explicit_release=%lu id_changes=%lu invalid=%lu boundary_suppressed=%lu max_valid_gap_us=%lu max_i2c_wait_us=%lu max_i2c_read_us=%lu",
        (unsigned long)t.raw_zero, (unsigned long)t.raw_down, (unsigned long)t.raw_up,
        (unsigned long)t.raw_contact, (unsigned long)t.raw_reserved, (unsigned long)t.raw_multi,
        (unsigned long)t.duplicate_down, (unsigned long)t.recovered_edges,
        (unsigned long)t.explicit_releases, (unsigned long)t.id_changes,
        (unsigned long)t.invalid_reports, (unsigned long)t.boundary_suppressed,
        (unsigned long)t.max_valid_gap_us, (unsigned long)t.max_i2c_wait_us,
        (unsigned long)t.max_i2c_read_us);
    const unsigned requested = s_motor_requested.load(), finished = s_motor_finished.load();
    const unsigned dropped = s_motor_dropped.load();
    ESP_LOGI(kTag, "MOTOR_FIFO requested=%u in=%u started=%u finished=%u dropped=%u pending=%u queued_now=%u epoch=%u max_delay_us=%u",
        requested, s_motor_queued.load(), s_motor_started.load(), finished, dropped,
        requested >= finished + dropped ? requested - finished - dropped : 0,
        s_motor_queue ? unsigned(uxQueueMessagesWaiting(s_motor_queue)) : 0,
        unsigned(s_motor_epoch.load()), s_motor_max_delay_us.load());
    ESP_LOGI(kTag, "RENDER_GATE checks=%u waits=%u pauses=%u resumes=%u gated=%d timer_calls=%u deferred=%u snapshots=%u replaced=%u failed_generation=%u retry_pending=%d retry_requests=%u",
        s_gate_checks.load(), s_gate_waits.load(), s_gate_pauses.load(), s_gate_resumes.load(),
        int(s_software_gate_paused.load()), s_refr_callbacks.load(), s_refr_deferred.load(),
        s_frame_snapshots.load(), s_snapshot_replaced.load(), unsigned(s_failed_generation.load()),
        int(s_frame_retry_pending.load()), s_frame_retries.load());
    ESP_LOGI(kTag, "RENDER_TIMING flush_calls=%u flush_total_us=%u flush_max_us=%u refr_total_us=%u refr_max_us=%u ui_cycles=%u ui_total_us=%u ui_max_us=%u",
        s_flush_calls.load(), s_flush_total_us.load(), s_flush_max_us.load(),
        s_refr_total_us.load(), s_refr_max_us.load(), s_ui_cycles.load(),
        s_ui_total_us.load(), s_ui_max_us.load());
}
int BatteryLevel() {
    static int cached = -1;
    static int64_t last = -10000000;
    const int64_t now = esp_timer_get_time();
    if (PanelBusy() || s_standby.load() || s_refresh_paused.load() ||
        s_powered_down.load() || now-last < 10000000) return cached;
    last = now;
    bool charging = false, discharging = false;
    int level = 0;
    if (Bq27220Gauge::GetInstance().GetBatteryLevel(level, charging, discharging))
        cached = std::clamp(level, 0, 100);
    return cached;
}
bool RtcTime(struct tm* value, bool* valid) {
    if (valid) *valid = false;
    if (!value || PanelBusy() || s_standby.load() || s_refresh_paused.load() ||
        s_powered_down.load()) return false;
    const auto bus = PowerBus();
    uint8_t d[7]{};
    if (power_i2c_write_read(&bus, PCF8563_I2C_ADDR, 0x02, d, sizeof(d), 100) != ESP_OK)
        return false;
    struct tm t{};
    t.tm_sec = FromBcd(d[0] & 0x7F);
    t.tm_min = FromBcd(d[1] & 0x7F);
    t.tm_hour = FromBcd(d[2] & 0x3F);
    t.tm_mday = FromBcd(d[3] & 0x3F);
    t.tm_wday = d[4] & 7;
    t.tm_mon = FromBcd(d[5] & 0x1F)-1;
    t.tm_year = 100+FromBcd(d[6]); // Board calendar uses 2000..2099.
    t.tm_isdst = -1;
    const bool ok = !(d[0]&0x80) && t.tm_sec <= 59 && t.tm_min <= 59 &&
        t.tm_hour <= 23 && t.tm_mday >= 1 && t.tm_mday <= 31 &&
        t.tm_mon >= 0 && t.tm_mon <= 11;
    if (ok) *value = t;
    if (valid) *valid = ok;
    return true;
}
bool PowerOff(bool only_if_idle) {
    if (!s_ready.load() || s_powered_down.load()) return false;
    if (only_if_idle && !IdleSleepDue()) return false;
    if (UsbActive() || UsbBusy() || UsbExported()) {
        // Do not silently disconnect a host-owned filesystem. Runtime may
        // request a proper stop first; a hardware key cannot tear it down.
        ESP_LOGE(kTag, "deep sleep refused: USB still owns TF");
        return false;
    }
    // Maintain the existing panel -> aux -> I2C order. It also waits for a
    // physical display already in progress, rather than an idle flag alone.
    if (s_flash_owner != xTaskGetCurrentTaskHandle() && !BeginFlashWrite(0, 30000)) {
        ESP_LOGE(kTag, "deep sleep refused: hardware could not be drained");
        return false;
    }
    // A touch may have arrived after queuing auto-sleep, while state was saved
    // or the previous panel frame drained. The hardware gate now owns sampling.
    if (only_if_idle && !IdleSleepDue()) {
        EndFlashWrite();
        return false;
    }
    // Board drawing/power routines take their normal I2C lock. Keep panel and
    // aux gates, but release only the Flash-side bus lease before calling them.
    if (s_flash_i2c_held) { metalio_i2c1_unlock(); s_flash_i2c_held = false; }
    CancelTouch();
    metalio_touch_set_ui_suppress(true);
    s_cover_event.store(0);
    CancelMotor();
    const bool was_locked = s_standby.load(std::memory_order_acquire);
    bool keys_masked = false;
    const auto refuse = [&](const char* reason) {
        ESP_LOGE(kTag, "deep sleep refused: %s", reason);
        if (keys_masked) epd_board_metalio_eink4_plus_ioexp_restore_keys();
        auto* hl = MetalioEpd_Hl();
        if (was_locked) DrawPocketLockScreen(hl->front_fb);
        else if (xSemaphoreTake(s_frame_mu, pdMS_TO_TICKS(300)) == pdTRUE) {
            memcpy(hl->front_fb, s_pending, kFrameBytes);
            xSemaphoreGive(s_frame_mu);
        } else memset(hl->front_fb, 0xFF, kFrameBytes);
        if (!DrawNativeFrame(false, "SLEEP_REFUSED_RESTORE", 0)) {
            // Never leave live input under a fake sleeping picture.
            s_standby.store(true, std::memory_order_release);
            ++s_standby_revision;
            Frontlight(false);
        } else Frontlight(!was_locked);
        EndFlashWrite();
        return false;
    };
    s_sleep_tca_addr = pca9555_get_addr();
    bool down = false;
    if (!ReadSleepKey(&down)) return refuse("power key cannot be verified");
    if (!ExpandNativeMono(pocket_deepsleep_start, pocket_deepsleep_end,
                          MetalioEpd_Hl()->front_fb))
        return refuse("sleep poster has invalid native size");
    if (!DrawNativeFrame(false, "DEEPSLEEP", 0))
        return refuse("sleep poster not physically displayed");
    Frontlight(false);

    // The entering hold must end before wake can be armed. Failed I2C samples
    // are not releases; reject cleanly instead of waiting forever on a fault.
    ESP_LOGI(kTag, "DEEP_SLEEP poster ready/light off; waiting for power release");
    unsigned released = 0, read_errors = 0;
    while (released < 4) {
        bool held = true;
        if (!ReadSleepKey(&held)) {
            released = 0;
            if (++read_errors >= 10) return refuse("power-key sampling failed");
        } else {
            read_errors = 0;
            released = held ? 0 : released + 1;
        }
        vTaskDelay(pdMS_TO_TICKS(20));
    }
    // Configure the only awake key before irreversibly cutting shared rails.
    epd_board_metalio_eink4_plus_ioexp_mask_for_sleep();
    keys_masked = true;
    if (!epd_board_metalio_eink4_plus_ioexp_enable_power_wake_pin())
        return refuse("power-wake input configuration failed");
    if (!ReadSleepKey(&down)) return refuse("power-wake input readback failed");
    if (!UnmountTf()) return refuse("TF unmount failed");
    s_powered_down.store(true);
    ledc_stop(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_0, 0);
    ledc_stop(LEDC_LOW_SPEED_MODE, LEDC_CHANNEL_1, 0);
    epd_poweroff();
    epd_board_metalio_eink4_plus_tps_enter_sleep();
    epd_board_metalio_eink4_plus_pa_set(false);
    epd_board_metalio_eink4_plus_bus_hold_low();
    epd_board_metalio_eink4_plus_bus_latch_for_sleep();
    epd_board_metalio_eink4_plus_sleep_cut_rails();
    ReadSleepKey(&down); // Clear any shared interrupt generated during shutdown.
    s_deep_sleep_magic = kDeepSleepMagic;
    EnterHardwareDeepSleep();
}
} // namespace pocket_hal

