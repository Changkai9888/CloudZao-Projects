#pragma once

#include <array>
#include <string>

#include "pocket_core.h"

namespace pocket {

// Pocket-only wake gate. The caller owns the existing TF directory, serializes
// storage access, and never exposes entered PINs in status/log output.
// This local UI lock is not TF encryption or protection against card replacement.
class WakePinStore {
public:
    explicit WakePinStore(std::string directory);
    bool Load(std::string* error);
    bool IsReady() const { return ready_; }
    bool NeedsUnlock() const { return !ready_ || needs_unlock_; }
    bool IsDefault() const { return ready_ && is_default_; }
    bool Verify(const std::string& pin) const;
    bool Change(const std::string& current, const std::string& next,
                std::string* error);
    bool SetNeedsUnlock(bool value, std::string* error);
    static bool ValidPin(const std::string& pin);

private:
    bool Save(const std::array<unsigned char, 16>& salt,
              const std::array<unsigned char, 32>& digest, bool needs_unlock,
              bool is_default, std::string* error);
    RecordStore records_;
    std::array<unsigned char, 16> salt_{};
    std::array<unsigned char, 32> digest_{};
    bool ready_ = false;
    bool ever_loaded_ = false;
    bool needs_unlock_ = true;
    bool is_default_ = false;
};

}  // namespace pocket
