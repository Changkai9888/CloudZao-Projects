#pragma once
#include <cstdint>
namespace pocket {
// Decimal MB, matching the user-visible thresholds. Equality is permitted.
constexpr uint64_t kSpaceWarningBytes = 500000000ULL;
constexpr uint64_t kSpaceBlockedBytes = 150000000ULL;
constexpr bool SpaceWarning(uint64_t bytes) { return bytes < kSpaceWarningBytes; }
constexpr bool SpaceBlocked(uint64_t bytes) { return bytes < kSpaceBlockedBytes; }
static_assert(SpaceWarning(499999999) && !SpaceWarning(500000000));
static_assert(SpaceBlocked(149999999) && !SpaceBlocked(150000000));
static_assert(SpaceWarning(150000000) && !SpaceBlocked(500000000));
}
