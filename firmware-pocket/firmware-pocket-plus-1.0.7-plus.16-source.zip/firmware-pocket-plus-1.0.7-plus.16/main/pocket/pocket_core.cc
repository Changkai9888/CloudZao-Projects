#include "pocket_core.h"

#include <algorithm>
#include <array>
#include <cerrno>
#include <cstdio>
#include <cstring>
#include <fcntl.h>
#include <limits>
#include <map>
#include <sys/stat.h>
#include <unistd.h>
#include <utility>

namespace pocket {
namespace {

constexpr std::size_t kHeaderSize = 32;
constexpr unsigned char kMagic[8] = {'P', 'K', 'R', 'E', 'C', '0', '1', 0};

bool Fail(std::string* error, const char* message) {
    if (error != nullptr) *error = message;
    return false;
}

bool ValidUtf8(const std::string& value) {
    for (std::size_t i = 0; i < value.size();) {
        const auto first = static_cast<unsigned char>(value[i]);
        if (first < 0x80) {
            if (first < 0x20 || first == 0x7f) return false;
            ++i;
            continue;
        }
        std::uint32_t code = 0;
        std::size_t length = 0;
        std::uint32_t minimum = 0;
        if (first >= 0xc2 && first <= 0xdf) {
            length = 2; code = first & 0x1f; minimum = 0x80;
        } else if (first >= 0xe0 && first <= 0xef) {
            length = 3; code = first & 0x0f; minimum = 0x800;
        } else if (first >= 0xf0 && first <= 0xf4) {
            length = 4; code = first & 0x07; minimum = 0x10000;
        } else {
            return false;
        }
        if (value.size() - i < length) return false;
        for (std::size_t j = 1; j < length; ++j) {
            const auto next = static_cast<unsigned char>(value[i + j]);
            if ((next & 0xc0) != 0x80) return false;
            code = (code << 6) | (next & 0x3f);
        }
        if (code < minimum || code > 0x10ffff || (code >= 0xd800 && code <= 0xdfff)) return false;
        if (code >= 0x80 && code <= 0x9f) return false;
        i += length;
    }
    return true;
}

bool Hash(const std::string& value) {
    if (value.size() != 64) return false;
    for (char c : value) {
        if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f'))) return false;
    }
    return true;
}

bool Decimal(const std::string& value, std::uint32_t maximum, std::uint32_t* result) {
    if (value.empty() || value.size() > 10) return false;
    if (value.size() > 1 && value[0] == '0') return false;
    std::uint32_t n = 0;
    for (char c : value) {
        if (c < '0' || c > '9') return false;
        const auto digit = static_cast<std::uint32_t>(c - '0');
        if (n > maximum / 10 || (n == maximum / 10 && digit > maximum % 10)) return false;
        n = n * 10 + digit;
    }
    *result = n;
    return true;
}

bool Version(const std::string& value) {
    if (value.empty() || value.size() > 31) return false;
    for (char c : value) {
        if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
              (c >= '0' && c <= '9') || c == '.' || c == '-' || c == '_' || c == '+')) return false;
    }
    return true;
}

std::uint32_t UpdateCrc(std::uint32_t crc, const unsigned char* data, std::size_t size) {
    for (std::size_t i = 0; i < size; ++i) {
        crc ^= data[i];
        for (unsigned bit = 0; bit < 8; ++bit) {
            crc = (crc >> 1) ^ (0xedb88320U & (0U - (crc & 1U)));
        }
    }
    return crc;
}

std::uint32_t Get32(const unsigned char* p) {
    return static_cast<std::uint32_t>(p[0]) | (static_cast<std::uint32_t>(p[1]) << 8) |
           (static_cast<std::uint32_t>(p[2]) << 16) | (static_cast<std::uint32_t>(p[3]) << 24);
}

std::uint64_t Get64(const unsigned char* p) {
    return Get32(p) | (static_cast<std::uint64_t>(Get32(p + 4)) << 32);
}

void Put32(unsigned char* p, std::uint32_t value) {
    for (unsigned i = 0; i < 4; ++i) p[i] = static_cast<unsigned char>(value >> (8 * i));
}

void Put64(unsigned char* p, std::uint64_t value) {
    Put32(p, static_cast<std::uint32_t>(value));
    Put32(p + 4, static_cast<std::uint32_t>(value >> 32));
}

RecordResult Result(RecordStatus status, const char* error) {
    RecordResult result;
    result.status = status;
    result.error = error;
    return result;
}

std::string SlotPath(const std::string& root, const std::string& key, int slot) {
    return root + "/" + key + (slot == 0 ? ".a.pkr" : ".b.pkr");
}

bool ValidRoot(const std::string& root) {
    return !root.empty() && root.size() <= 512 && root.find('\0') == std::string::npos &&
           root.find('\n') == std::string::npos && root.find('\r') == std::string::npos;
}

RecordResult ReadSlot(const std::string& path, int slot) {
    int flags = O_RDONLY;
#if defined(O_NOFOLLOW) && !defined(ESP_PLATFORM)
    // ESP-IDF FATFS has no symbolic links and ignores O_NOFOLLOW. On hosts that
    // do support links, refuse them instead of following paths out of the root.
    flags |= O_NOFOLLOW;
#endif
    const int descriptor = open(path.c_str(), flags);
    if (descriptor < 0) {
        return Result(errno == ENOENT ? RecordStatus::Missing : RecordStatus::IoError,
                      errno == ENOENT ? "record absent" : "cannot open record");
    }
    struct stat info {};
    if (fstat(descriptor, &info) != 0 || !S_ISREG(info.st_mode)) {
        close(descriptor);
        return Result(RecordStatus::IoError, "record is not a readable regular file");
    }
    if (info.st_size < static_cast<off_t>(kHeaderSize) ||
        info.st_size > static_cast<off_t>(kHeaderSize + kMaximumRecordBytes)) {
        close(descriptor);
        return Result(RecordStatus::Corrupt, "invalid record length");
    }
    std::array<unsigned char, kHeaderSize + kMaximumRecordBytes + 1> bytes {};
    const auto size = static_cast<std::size_t>(info.st_size);
    std::size_t received = 0;
    while (received < size) {
        const auto count = read(descriptor, bytes.data() + received, size - received);
        if (count < 0 && errno == EINTR) continue;
        if (count < 0) {
            close(descriptor);
            return Result(RecordStatus::IoError, "record read failed");
        }
        if (count == 0) {
            close(descriptor);
            return Result(RecordStatus::Corrupt, "record truncated while reading");
        }
        received += static_cast<std::size_t>(count);
    }
    unsigned char extra = 0;
    ssize_t trailing;
    do { trailing = read(descriptor, &extra, 1); } while (trailing < 0 && errno == EINTR);
    const int close_result = close(descriptor);
    if (trailing < 0 || close_result != 0) return Result(RecordStatus::IoError, "record read/close failed");
    if (trailing != 0) return Result(RecordStatus::Corrupt, "record changed while reading");
    if (std::memcmp(bytes.data(), kMagic, sizeof(kMagic)) != 0) {
        if (std::memcmp(bytes.data(), "PKREC", 5) == 0)
            return Result(RecordStatus::UnsupportedSchema, "unrecognized record envelope; originals preserved");
        return Result(RecordStatus::Corrupt, "damaged record envelope");
    }
    if (bytes[8] != 1 || bytes[9] != 0 || bytes[10] != 0 || bytes[11] != 0)
        return Result(RecordStatus::UnsupportedSchema, "unrecognized record envelope version; originals preserved");
    const auto schema = Get32(bytes.data() + 12);
    const auto generation = Get64(bytes.data() + 16);
    const auto payload_size = Get32(bytes.data() + 24);
    if (schema == 0 || generation == 0 || payload_size > kMaximumRecordBytes ||
        size != kHeaderSize + payload_size) return Result(RecordStatus::Corrupt, "invalid record fields");
    auto crc = UpdateCrc(0xffffffffU, bytes.data(), 28);
    crc = UpdateCrc(crc, bytes.data() + kHeaderSize, payload_size) ^ 0xffffffffU;
    if (crc != Get32(bytes.data() + 28)) return Result(RecordStatus::Corrupt, "record checksum mismatch");
    RecordResult result;
    result.status = RecordStatus::Ok;
    result.schema = schema;
    result.generation = generation;
    result.slot = slot;
    result.payload.assign(reinterpret_cast<const char*>(bytes.data() + kHeaderSize), payload_size);
    return result;
}

// Only the caller that successfully used O_EXCL while both slots were absent
// may invoke this, before returning from that write attempt. This is not a
// general corruption repair: after reboot there is no ownership evidence.
bool RemoveOwnedPartial(const std::string& path, const std::string& other_path,
                        const struct stat& created,
                        const std::array<unsigned char, kHeaderSize>& header,
                        const std::string& payload) {
    if (ReadSlot(other_path, 1).status != RecordStatus::Missing) return false;
    if (ReadSlot(path, 0).status != RecordStatus::Corrupt) return false;
    int flags = O_RDONLY;
#if defined(O_NOFOLLOW) && !defined(ESP_PLATFORM)
    flags |= O_NOFOLLOW;
#endif
    const int descriptor = open(path.c_str(), flags);
    if (descriptor < 0) return false;
    struct stat current {};
    bool owned = fstat(descriptor, &current) == 0 && S_ISREG(current.st_mode) &&
                 current.st_size >= 0 &&
                 current.st_size < static_cast<off_t>(kHeaderSize + payload.size());
#ifndef ESP_PLATFORM
    // FATFS reports no inode identity; its safety evidence is exclusive creation,
    // serialized lifecycle/access, exact byte prefix and absence of the other slot.
    owned = owned && current.st_dev == created.st_dev && current.st_ino == created.st_ino;
#else
    (void)created;
#endif
    std::array<unsigned char, 256> bytes {};
    std::size_t offset = 0;
    while (owned && offset < static_cast<std::size_t>(current.st_size)) {
        const auto count = read(descriptor, bytes.data(),
            std::min(bytes.size(), static_cast<std::size_t>(current.st_size) - offset));
        if (count < 0 && errno == EINTR) continue;
        if (count <= 0) { owned = false; break; }
        for (ssize_t i = 0; i < count; ++i) {
            const auto at = offset + static_cast<std::size_t>(i);
            const unsigned char expected = at < kHeaderSize ? header[at] :
                static_cast<unsigned char>(payload[at - kHeaderSize]);
            if (bytes[static_cast<std::size_t>(i)] != expected) { owned = false; break; }
        }
        offset += static_cast<std::size_t>(count);
    }
    if (close(descriptor) != 0) owned = false;
#ifndef ESP_PLATFORM
    struct stat final_identity {};
    owned = owned && lstat(path.c_str(), &final_identity) == 0 && S_ISREG(final_identity.st_mode) &&
            final_identity.st_dev == created.st_dev && final_identity.st_ino == created.st_ino &&
            final_identity.st_size == current.st_size;
#endif
    return owned && unlink(path.c_str()) == 0;
}

RecordResult SelectRecord(const RecordResult& a, const RecordResult& b, std::uint32_t maximum_schema) {
    // An unreadable slot might contain a newer record; never silently overwrite it.
    if (a.status == RecordStatus::IoError || b.status == RecordStatus::IoError)
        return Result(RecordStatus::IoError, "at least one record slot is unreadable");
    // A newer envelope cannot be ordered reliably by fields we do not understand.
    if (a.status == RecordStatus::UnsupportedSchema || b.status == RecordStatus::UnsupportedSchema)
        return Result(RecordStatus::UnsupportedSchema, "unrecognized record copy; originals preserved");
    if (!a.ok() && !b.ok()) {
        if (a.status == RecordStatus::Missing && b.status == RecordStatus::Missing)
            return Result(RecordStatus::Missing, "record absent");
        return Result(RecordStatus::Corrupt, "no valid record copy; originals preserved");
    }
    if (a.ok() && b.ok() && a.generation == b.generation &&
        (a.schema != b.schema || a.payload != b.payload))
        return Result(RecordStatus::Corrupt, "conflicting copies with the same generation");
    RecordResult result = a.ok() && (!b.ok() || a.generation >= b.generation) ? a : b;
    result.degraded = a.status == RecordStatus::Corrupt || b.status == RecordStatus::Corrupt;
    if (result.schema > maximum_schema) {
        result.status = RecordStatus::UnsupportedSchema;
        result.error = "newest record schema is newer than this application; originals preserved";
        result.payload.clear();
    }
    return result;
}

}  // namespace

bool IsSafeIdentifier(const std::string& value, std::size_t maximum) {
    if (value.empty() || value.size() > maximum || value.back() == '.') return false;
    const auto alphanumeric = [](char c) {
        return (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9');
    };
    if (!alphanumeric(value.front())) return false;
    for (char c : value) {
        if (!alphanumeric(c) && c != '.' && c != '_' && c != '-') return false;
    }
    return true;
}

bool ParseManifest(const std::string& text, Manifest* output, std::string* error) {
    if (output == nullptr) return Fail(error, "manifest output is null");
    if (text.empty() || text.size() > 2048) return Fail(error, "manifest length outside 1..2048 bytes");
    if (text.find('\0') != std::string::npos) return Fail(error, "manifest contains NUL");
    std::map<std::string, std::string> values;
    std::size_t position = text.compare(0, 3, "\xef\xbb\xbf") == 0 ? 3 : 0;
    while (position < text.size()) {
        const auto end = text.find('\n', position);
        std::string line = text.substr(position, end == std::string::npos ? end : end - position);
        position = end == std::string::npos ? text.size() : end + 1;
        if (!line.empty() && line.back() == '\r') line.pop_back();
        if (line.size() > 256) return Fail(error, "manifest line too long");
        if (line.empty()) continue;
        if (!ValidUtf8(line)) return Fail(error, "manifest contains invalid UTF-8 or controls");
        if (line[0] == '#') continue;
        const auto separator = line.find('=');
        if (separator == std::string::npos || separator == 0)
            return Fail(error, "manifest requires nonempty key=value lines");
        auto key = line.substr(0, separator);
        auto value = line.substr(separator + 1);
        if (value.empty() && key != "description")
            return Fail(error, "manifest requires nonempty key=value lines");
        if (!values.emplace(std::move(key), std::move(value)).second)
            return Fail(error, "duplicate manifest field");
    }
    const std::array<const char*, 11> mandatory = {
        "format", "id", "name", "version", "target", "layout", "image", "size",
        "sha256", "state_version", "resources"};
    for (const char* key : mandatory) {
        if (key != nullptr && values.count(key) == 0) return Fail(error, "missing required manifest field");
    }
    for (const auto& entry : values) {
        bool known = entry.first == "resource_font_sha256" || entry.first == "resource_ui_sha256" ||
                     entry.first == "description";
        for (const char* key : mandatory) if (key != nullptr && entry.first == key) known = true;
        if (!known) return Fail(error, "unknown manifest field");
    }
    if (values["format"] != "metalio-pocket-local/1") return Fail(error, "unsupported manifest format");
    if (!IsSafeIdentifier(values["id"])) return Fail(error, "unsafe application ID");
    if (values["name"].size() > 64) return Fail(error, "application name exceeds 64 UTF-8 bytes");
    const auto description = values.find("description");
    if (description != values.end() && description->second.size() > 96)
        return Fail(error, "application description exceeds 96 UTF-8 bytes");
    if (!Version(values["version"])) return Fail(error, "invalid application version");
    if (values["target"] != kTargetId) return Fail(error, "wrong target device");
    if (values["layout"] != kLayoutId) return Fail(error, "incompatible partition layout");
    if (values["image"] != "app.bin") return Fail(error, "image must be the local app.bin file");
    if (values["resources"] != "metalio-shared-v1") return Fail(error, "unsupported resource set");
    if (!Hash(values["sha256"])) return Fail(error, "invalid image SHA256");
    Manifest parsed;
    if (!Decimal(values["size"], kMaximumImageBytes, &parsed.size) || parsed.size == 0)
        return Fail(error, "image size outside application slot");
    if (!Decimal(values["state_version"], 2, &parsed.state_version) || parsed.state_version == 0)
        return Fail(error, "unsupported state version");
    for (const char* key : {"resource_font_sha256", "resource_ui_sha256"}) {
        const auto it = values.find(key);
        if (it != values.end() && !Hash(it->second)) return Fail(error, "invalid resource SHA256");
    }
    parsed.id = values["id"];
    parsed.name = values["name"];
    if (description != values.end()) parsed.description = description->second;
    parsed.version = values["version"];
    parsed.target = values["target"];
    parsed.layout = values["layout"];
    parsed.image = values["image"];
    parsed.sha256 = values["sha256"];
    parsed.resources = values["resources"];
    if (values.count("resource_font_sha256")) parsed.resource_font_sha256 = values["resource_font_sha256"];
    if (values.count("resource_ui_sha256")) parsed.resource_ui_sha256 = values["resource_ui_sha256"];
    *output = std::move(parsed);
    if (error != nullptr) error->clear();
    return true;
}

RecordStore::RecordStore(std::string root_directory) : root_(std::move(root_directory)) {}

RecordResult RecordStore::Load(const std::string& key, std::uint32_t max_schema) const {
    if (!ValidRoot(root_) || !IsSafeIdentifier(key) || max_schema == 0)
        return Result(RecordStatus::InvalidArgument, "invalid storage root, key or schema");
    // A missing mount/directory is storage failure, never a new user's empty state.
    struct stat info {};
    if (stat(root_.c_str(), &info) != 0 || !S_ISDIR(info.st_mode))
        return Result(RecordStatus::IoError, "record directory unavailable");
    return SelectRecord(ReadSlot(SlotPath(root_, key, 0), 0),
                        ReadSlot(SlotPath(root_, key, 1), 1), max_schema);
}

RecordResult RecordStore::Save(const std::string& key, std::uint32_t schema,
                               const std::string& payload) const {
    if (payload.size() > kMaximumRecordBytes)
        return Result(RecordStatus::InvalidArgument, "record payload exceeds 4096 bytes");
    const auto previous = Load(key, schema);
    if (!previous.ok() && previous.status != RecordStatus::Missing) return previous;
    if (previous.generation == std::numeric_limits<std::uint64_t>::max())
        return Result(RecordStatus::GenerationOverflow, "record generation exhausted");
    const int target = previous.ok() ? 1 - previous.slot : 0;
    const std::uint64_t generation = previous.generation + 1;
    std::array<unsigned char, kHeaderSize> header {};
    std::memcpy(header.data(), kMagic, sizeof(kMagic));
    header[8] = 1;
    Put32(header.data() + 12, schema);
    Put64(header.data() + 16, generation);
    Put32(header.data() + 24, static_cast<std::uint32_t>(payload.size()));
    auto crc = UpdateCrc(0xffffffffU, header.data(), 28);
    crc = UpdateCrc(crc, reinterpret_cast<const unsigned char*>(payload.data()), payload.size()) ^ 0xffffffffU;
    Put32(header.data() + 28, crc);
    const auto path = SlotPath(root_, key, target);
    const bool first_write = previous.status == RecordStatus::Missing;
    int flags = O_WRONLY | O_CREAT | (first_write ? O_EXCL : O_TRUNC);
#if defined(O_NOFOLLOW) && !defined(ESP_PLATFORM)
    flags |= O_NOFOLLOW;
#endif
    const int descriptor = open(path.c_str(), flags, 0600);
    if (descriptor < 0) return Result(RecordStatus::IoError, "cannot open alternate record slot");
    struct stat created {};
    const bool owned_new_file = first_write && fstat(descriptor, &created) == 0 &&
                                S_ISREG(created.st_mode) && created.st_size == 0;
    const auto failed_write = [&]() {
        const bool cleaned = owned_new_file && RemoveOwnedPartial(
            path, SlotPath(root_, key, 1 - target), created, header, payload);
        return Result(RecordStatus::IoError, cleaned ?
            "write failed; own new partial slot removed, retry after restoring storage" :
            "record write, flush, sync or close failed; existing files preserved");
    };
    FILE* file = fdopen(descriptor, "wb");
    if (file == nullptr) {
        close(descriptor);
        return failed_write();
    }
    bool success = fwrite(header.data(), 1, header.size(), file) == header.size();
    if (success && !payload.empty()) success = fwrite(payload.data(), 1, payload.size(), file) == payload.size();
    if (success) success = fflush(file) == 0;
    if (success) success = fsync(fileno(file)) == 0;
    // Always close, including error paths. A close failure cannot be reported as saved.
    if (fclose(file) != 0) success = false;
    if (!success) return failed_write();
    auto verified = ReadSlot(path, target);
    if (!verified.ok() || verified.schema != schema || verified.generation != generation || verified.payload != payload)
        return Result(RecordStatus::IoError, "written record failed readback verification");
    return verified;
}

RecordResult RecordStore::LoadConfirmed(const std::string& key, std::uint32_t max_schema) const {
    auto ordinary = Load(key, max_schema);
    if (!ordinary.ok()) return ordinary;
    const auto a = ReadSlot(SlotPath(root_, key, 0), 0);
    const auto b = ReadSlot(SlotPath(root_, key, 1), 1);
    if (!a.ok() || !b.ok() || a.schema != b.schema || a.payload != b.payload)
        return Result(RecordStatus::Corrupt, "control copies disagree; overwrite is blocked");
    ordinary.degraded = false;
    return ordinary;
}

RecordResult RecordStore::SaveConfirmed(const std::string& key, std::uint32_t schema,
                                       const std::string& payload) const {
    // While either commit is incomplete the reader blocks, rather than using
    // the previous acknowledgement. Callers do not resume business until both
    // copies agree. General business snapshots keep ordinary fallback semantics.
    auto result = Save(key, schema, payload);
    if (!result.ok()) return result;
    result = Save(key, schema, payload);
    if (!result.ok()) return result;
    return LoadConfirmed(key, schema);
}

std::uint32_t Crc32(const void* data, std::size_t size) {
    return UpdateCrc(0xffffffffU, static_cast<const unsigned char*>(data), size) ^ 0xffffffffU;
}

const char* RecordStatusName(RecordStatus status) {
    switch (status) {
        case RecordStatus::Ok: return "ok";
        case RecordStatus::Missing: return "missing";
        case RecordStatus::InvalidArgument: return "invalid_argument";
        case RecordStatus::IoError: return "io_error";
        case RecordStatus::Corrupt: return "corrupt";
        case RecordStatus::UnsupportedSchema: return "unsupported_schema";
        case RecordStatus::GenerationOverflow: return "generation_overflow";
    }
    return "unknown";
}

}  // namespace pocket
