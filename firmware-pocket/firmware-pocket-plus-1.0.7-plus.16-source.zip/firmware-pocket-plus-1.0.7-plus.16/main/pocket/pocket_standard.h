#pragma once
#include "pocket_handoff.h"
#include "pocket_wifi.h"

namespace pocket::standard {
// Public guide revision 1.1 / FPOCKET ABI 1.0. This module only encodes and
// validates payloads; the caller owns record storage and transaction routing.
struct Run {
    std::string run_id, user_id, app_id, version, image_sha256, phase;
};
struct Receipt { std::string run_id, user_id, app_id, phase; };
struct WifiResult {
    std::string run_id;
    std::uint64_t offer_generation = 0;
    std::string result;
};
std::string EncodeRun(const RunContext& run);
bool DecodeRun(const std::string& payload, Run* output);
bool Matches(const Run& public_run, const RunContext& run);
std::string EncodeReceipt(const RunContext& run, bool saved);
bool DecodeReceipt(const std::string& payload, Receipt* output);
bool Matches(const Receipt& receipt, const RunContext& run);

// Raw byte fields: non-UTF-8 SSIDs are valid. NUL is never permitted.
std::string EncodeNetwork(const WifiNetwork& network);
bool DecodeNetwork(const std::string& payload, WifiNetwork* output);
std::string EncodeOffer(const WifiOffer& offer);
bool DecodeOffer(const RecordResult& record, WifiOffer* output);
std::string EncodeWifiResult(const WifiOffer& offer, const std::string& result);
bool DecodeWifiResult(const std::string& payload, WifiResult* output);
}  // namespace pocket::standard
