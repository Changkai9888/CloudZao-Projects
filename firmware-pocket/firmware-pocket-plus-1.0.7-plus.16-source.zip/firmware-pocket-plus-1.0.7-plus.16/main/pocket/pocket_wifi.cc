#include "pocket_wifi.h"
#include "pocket_core.h"

#include <algorithm>
#include <array>
#include <cstdint>
#include <cerrno>
#include <mutex>
#include <utility>
#include <unistd.h>

#include <nvs.h>

namespace pocket {
namespace {

constexpr char kNamespace[] = "pocket_wifi";
constexpr char kBlobKey[] = "networks";
// Manager-only migration bookkeeping; not part of the shared Wi-Fi payload.
// Once a user forgets a network, missing TF records must not resurrect old NVS
// credentials. Other applications' private NVS settings remain untouched.
constexpr char kLegacyRetiredKey[] = "wifi_legacy_retired";
constexpr char kLegacyRetiredPayload[] = "no-nvs-reimport-v1";
// Private host transaction; applications neither read nor write this record.
constexpr char kProjectionKey[] = "wifi_projection16";
constexpr char kProjectionMagic[] = "FPWPROJ16";
constexpr std::array<std::uint8_t, 8> kMagic = {'P', 'K', 'W', 'I', 'F', 'I', 1, 0};
constexpr std::size_t kHeaderBytes = kMagic.size() + 1;
constexpr std::size_t kMaximumBlobBytes = kHeaderBytes + kMaximumSharedWifiNetworks *
    (2 + kMaximumWifiSsidBytes + kMaximumWifiPasswordBytes);
std::mutex wifi_mutex;
std::string shared_directory;
std::vector<WifiNetwork> cached_networks;
bool storage_ready = false;

bool Fail(std::string* error, const char* message) {
    if (error != nullptr) *error = message;
    return false;
}

bool Success(std::string* error) {
    if (error != nullptr) error->clear();
    return true;
}

bool ValidSsid(const std::string& value) {
    return !value.empty() && value.size() <= kMaximumWifiSsidBytes && value.find('\0') == std::string::npos;
}

bool ValidPassword(const std::string& value) {
    return value.size() <= kMaximumWifiPasswordBytes && value.find('\0') == std::string::npos;
}

class Handle {
public:
    Handle() = default;
    ~Handle() { Close(); }
    Handle(const Handle&) = delete;
    Handle& operator=(const Handle&) = delete;
    esp_err_t Open(const char* name, nvs_open_mode_t mode) {
        Close();
        const esp_err_t result = nvs_open(name, mode, &value_);
        open_ = result == ESP_OK;
        return result;
    }
    void Close() {
        if (open_) nvs_close(value_);
        open_ = false;
    }
    nvs_handle_t Get() const { return value_; }
private:
    nvs_handle_t value_ = 0;
    bool open_ = false;
};

enum class ReadResult { Ok, Missing, Error };

ReadResult ReadBlob(std::vector<std::uint8_t>* bytes, std::string* error) {
    Handle handle;
    const esp_err_t opened = handle.Open(kNamespace, NVS_READONLY);
    if (opened == ESP_ERR_NVS_NOT_FOUND) return ReadResult::Missing;
    if (opened != ESP_OK) {
        Fail(error, "Cannot open shared Wi-Fi storage");
        return ReadResult::Error;
    }
    std::size_t size = 0;
    const esp_err_t measured = nvs_get_blob(handle.Get(), kBlobKey, nullptr, &size);
    if (measured == ESP_ERR_NVS_NOT_FOUND) return ReadResult::Missing;
    if (measured != ESP_OK || size < kHeaderBytes || size > kMaximumBlobBytes) {
        Fail(error, "Shared Wi-Fi record cannot be read or has an invalid size");
        return ReadResult::Error;
    }
    std::vector<std::uint8_t> result(size);
    std::size_t actual = size;
    if (nvs_get_blob(handle.Get(), kBlobKey, result.data(), &actual) != ESP_OK || actual != size) {
        Fail(error, "Cannot read the complete shared Wi-Fi record");
        return ReadResult::Error;
    }
    *bytes = std::move(result);
    return ReadResult::Ok;
}

bool Decode(const std::vector<std::uint8_t>& bytes, std::vector<WifiNetwork>* networks, std::string* error) {
    if (bytes.size() < kHeaderBytes || !std::equal(kMagic.begin(), kMagic.end(), bytes.begin()) ||
        bytes[kMagic.size()] > kMaximumSharedWifiNetworks)
        return Fail(error, "Invalid or unsupported shared Wi-Fi record");
    std::vector<WifiNetwork> result;
    std::size_t position = kHeaderBytes;
    const std::size_t count = bytes[kMagic.size()];
    for (std::size_t i = 0; i < count; ++i) {
        if (position + 2 > bytes.size()) return Fail(error, "Truncated shared Wi-Fi record");
        const std::size_t ssid_size = bytes[position++];
        const std::size_t password_size = bytes[position++];
        if (ssid_size == 0 || ssid_size > kMaximumWifiSsidBytes || password_size > kMaximumWifiPasswordBytes ||
            ssid_size + password_size > bytes.size() - position)
            return Fail(error, "Invalid shared Wi-Fi field length");
        WifiNetwork item;
        item.ssid.assign(reinterpret_cast<const char*>(bytes.data() + position), ssid_size);
        position += ssid_size;
        item.password.assign(reinterpret_cast<const char*>(bytes.data() + position), password_size);
        position += password_size;
        if (!ValidSsid(item.ssid) || !ValidPassword(item.password) ||
            std::any_of(result.begin(), result.end(), [&](const WifiNetwork& entry) { return entry.ssid == item.ssid; }))
            return Fail(error, "Invalid or duplicate shared Wi-Fi entry");
        result.push_back(std::move(item));
    }
    if (position != bytes.size()) return Fail(error, "Unexpected trailing shared Wi-Fi data");
    *networks = std::move(result);
    return true;
}

ReadResult LegacyString(nvs_handle_t handle, const std::string& key, std::size_t maximum,
                        std::string* value, std::string* error) {
    std::size_t size = 0;
    const esp_err_t measured = nvs_get_str(handle, key.c_str(), nullptr, &size);
    if (measured == ESP_ERR_NVS_NOT_FOUND) return ReadResult::Missing;
    if (measured != ESP_OK || size == 0 || size > maximum + 1) {
        Fail(error, "Invalid or unreadable legacy Wi-Fi field");
        return ReadResult::Error;
    }
    std::string text(size, '\0');
    std::size_t actual = size;
    if (nvs_get_str(handle, key.c_str(), text.data(), &actual) != ESP_OK || actual != size || text.back() != '\0') {
        Fail(error, "Cannot read a complete legacy Wi-Fi field");
        return ReadResult::Error;
    }
    text.pop_back();
    if (text.find('\0') != std::string::npos) {
        Fail(error, "Invalid legacy Wi-Fi string");
        return ReadResult::Error;
    }
    *value = std::move(text);
    return ReadResult::Ok;
}

bool ReadLegacy(std::vector<WifiNetwork>* networks, std::string* error) {
    Handle handle;
    const esp_err_t opened = handle.Open("wifi", NVS_READONLY);
    if (opened == ESP_ERR_NVS_NOT_FOUND) {
        networks->clear();
        return true;
    }
    if (opened != ESP_OK) return Fail(error, "Cannot read legacy Wi-Fi storage");
    std::vector<WifiNetwork> result;
    for (std::size_t i = 0; i < kMaximumSharedWifiNetworks; ++i) {
        const std::string suffix = i == 0 ? "" : std::to_string(i);
        WifiNetwork item;
        const auto ssid = LegacyString(handle.Get(), "ssid" + suffix, kMaximumWifiSsidBytes, &item.ssid, error);
        if (ssid == ReadResult::Error) return false;
        const auto password = LegacyString(handle.Get(), "password" + suffix, kMaximumWifiPasswordBytes, &item.password, error);
        if (password == ReadResult::Error) return false;
        if (ssid == ReadResult::Missing && password == ReadResult::Missing) continue;
        if (ssid != ReadResult::Ok || password != ReadResult::Ok || !ValidSsid(item.ssid) ||
            !ValidPassword(item.password) ||
            std::any_of(result.begin(), result.end(), [&](const WifiNetwork& entry) { return entry.ssid == item.ssid; }))
            return Fail(error, "Incomplete, invalid or duplicate legacy Wi-Fi entry");
        result.push_back(std::move(item));
    }
    *networks = std::move(result);
    return true;
}

bool ReadLegacyStore(std::vector<WifiNetwork>* networks, std::string* error) {
    std::vector<std::uint8_t> bytes;
    const ReadResult result = ReadBlob(&bytes, error);
    if (result == ReadResult::Error) return false;
    return result == ReadResult::Missing ? ReadLegacy(networks, error) : Decode(bytes, networks, error);
}

std::string Encode(const std::vector<WifiNetwork>& networks) {
    std::string bytes(reinterpret_cast<const char*>(kMagic.data()), kMagic.size());
    bytes.push_back(static_cast<char>(networks.size()));
    for (const auto& item : networks) {
        bytes.push_back(static_cast<char>(item.ssid.size()));
        bytes.push_back(static_cast<char>(item.password.size()));
        bytes += item.ssid; bytes += item.password;
    }
    return bytes;
}
bool LegacyImportRetired(bool* retired, std::string* error) {
    const auto record = RecordStore(shared_directory).Load(kLegacyRetiredKey, 1);
    if (record.status == RecordStatus::Missing) {
        *retired = false;
        return true;
    }
    if (!record.ok() || record.payload != kLegacyRetiredPayload)
        return Fail(error, "Wi-Fi migration policy is unreadable; old NVS was not imported");
    // This flag is monotonic. One surviving valid copy still prohibits import.
    *retired = true;
    return true;
}

bool RetireLegacyImport(std::string* error) {
    bool retired = false;
    if (!LegacyImportRetired(&retired, error)) return false;
    const RecordStore store(shared_directory);
    // Repair an interrupted first retirement before reporting a later forget
    // as complete. Ordinary migration reads still honor one surviving flag.
    if (retired && store.LoadConfirmed(kLegacyRetiredKey, 1).ok()) return true;
    const auto saved = store.SaveConfirmed(kLegacyRetiredKey, 1, kLegacyRetiredPayload);
    if (!saved.ok()) return Fail(error, "Cannot confirm Wi-Fi migration policy; forget was not completed");
    return true;
}

std::string CurrentPayload(const std::vector<WifiNetwork>& networks) {
    if (networks.empty()) return {};
    const auto& n = networks.back();
    std::string result;
    result.push_back(static_cast<char>(n.ssid.size()));
    result.push_back(static_cast<char>(n.password.size()));
    return result + n.ssid + n.password;
}
bool ValidCurrentPayload(const std::string& payload) {
    if (payload.size() < 3) return false;
    const auto sn = static_cast<unsigned char>(payload[0]);
    const auto pn = static_cast<unsigned char>(payload[1]);
    return sn > 0 && sn <= kMaximumWifiSsidBytes && pn <= kMaximumWifiPasswordBytes &&
        payload.size() == 2U + sn + pn && payload.find('\0', 2) == std::string::npos;
}
bool ReadCurrent(std::string* payload, std::string* error) {
    const auto record = RecordStore(shared_directory).Load("wifi_current", 1);
    if (record.status == RecordStatus::Missing) { payload->clear(); return true; }
    if (!record.ok() || record.schema != 1 || !ValidCurrentPayload(record.payload))
        return Fail(error, "Standard shared Wi-Fi record is unreadable or unsupported; preserved");
    *payload = record.payload;
    return true;
}
bool DecodeListPayload(const std::string& payload, std::vector<WifiNetwork>* networks) {
    return Decode(std::vector<std::uint8_t>(payload.begin(), payload.end()), networks, nullptr);
}
struct Projection {
    bool pending = false, confirm_both = false;
    // Empty before means that the internal list genuinely did not exist.
    std::string before, target, current_before;
    // Last observed internal-list generation. Different record generations
    // are never compared to each other; this is only wifi_networks' watermark.
    std::uint64_t list_generation = 0;
};
void Size16(std::string* value, size_t n) {
    value->push_back(static_cast<char>(n)); value->push_back(static_cast<char>(n >> 8));
}
std::string EncodeProjection(const Projection& p) {
    std::string result(kProjectionMagic);
    result.push_back(p.pending ? 'P' : 'D');
    result.push_back(p.confirm_both ? 1 : 0);
    for (const auto* field : {&p.before, &p.target, &p.current_before}) Size16(&result, field->size());
    for (unsigned i = 0; i < 8; ++i) result.push_back(static_cast<char>(p.list_generation >> (8*i)));
    return result + p.before + p.target + p.current_before;
}
bool DecodeProjection(const std::string& data, Projection* out) {
    constexpr size_t head = sizeof(kProjectionMagic) - 1 + 2 + 6 + 8;
    if (data.size() < head || data.compare(0, sizeof(kProjectionMagic)-1, kProjectionMagic) ||
        (data[9] != 'P' && data[9] != 'D') || static_cast<unsigned char>(data[10]) > 1) return false;
    Projection p; p.pending = data[9] == 'P'; p.confirm_both = data[10] != 0;
    for (unsigned i = 0; i < 8; ++i)
        p.list_generation |= std::uint64_t(static_cast<unsigned char>(data[17+i])) << (8*i);
    size_t at = head;
    std::string* fields[] = {&p.before, &p.target, &p.current_before};
    for (size_t i = 0; i < 3; ++i) {
        const size_t pos = 11 + i * 2;
        const size_t length = static_cast<unsigned char>(data[pos]) |
            (size_t(static_cast<unsigned char>(data[pos+1])) << 8);
        if (length > data.size() - at) return false;
        *fields[i] = data.substr(at, length); at += length;
    }
    std::vector<WifiNetwork> unused;
    if (at != data.size() || (!p.before.empty() && !DecodeListPayload(p.before, &unused)) ||
        !DecodeListPayload(p.target, &unused) ||
        (!p.current_before.empty() && !ValidCurrentPayload(p.current_before))) return false;
    if (!p.pending && (p.before != p.target || p.list_generation == 0 ||
        p.current_before != CurrentPayload(unused))) return false;
    *out = std::move(p);
    return true;
}
bool ReadProjection(Projection* p, bool* present, std::string* error) {
    const auto record = RecordStore(shared_directory).Load(kProjectionKey, 1);
    *present = record.status != RecordStatus::Missing;
    if (!*present) return true;
    if (!record.ok() || record.schema != 1 || !DecodeProjection(record.payload, p))
        return Fail(error, "Shared Wi-Fi projection transaction is unreadable; originals preserved");
    return true;
}
bool WriteProjection(const Projection& p, std::string* error) {
    const auto saved = RecordStore(shared_directory).SaveConfirmed(kProjectionKey, 1, EncodeProjection(p));
    return saved.ok() || Fail(error, "Cannot persist shared Wi-Fi projection transaction; re-read TF");
}
bool PublishCurrent(const std::vector<WifiNetwork>& networks, bool confirm_both, std::string* error) {
    const RecordStore store(shared_directory);
    const auto existing = store.Load("wifi_current", 1);
    const auto payload = CurrentPayload(networks);
    if (payload.empty()) {
        if (existing.status == RecordStatus::Missing) return true;
        if (!existing.ok() || existing.schema != 1 || !ValidCurrentPayload(existing.payload))
            return Fail(error, "Cannot safely remove an unrecognized shared Wi-Fi record");
        // Remove the fallback first, keeping the selected latest copy readable
        // until the final unlink. The pending transaction survives interruption.
        for (int slot : {1-existing.slot, existing.slot}) {
            const auto file = shared_directory + "/wifi_current" + (slot ? ".b.pkr" : ".a.pkr");
            if (unlink(file.c_str()) != 0 && errno != ENOENT)
                return Fail(error, "Cannot complete removal of standard shared Wi-Fi; retry after re-read");
        }
        return store.Load("wifi_current", 1).status == RecordStatus::Missing ||
            Fail(error, "Standard shared Wi-Fi removal could not be confirmed");
    }
    if (!confirm_both && existing.ok() && existing.schema == 1 && existing.payload == payload) return true;
    if (existing.status != RecordStatus::Missing &&
        (!existing.ok() || existing.schema != 1 || !ValidCurrentPayload(existing.payload)))
        return Fail(error, "Standard shared Wi-Fi record is unreadable; preserved");
    // A user-requested forget also clears credentials from the fallback view.
    // This is a host write policy, not a requirement on standard app readers.
    const auto saved = confirm_both ? store.SaveConfirmed("wifi_current", 1, payload) :
                                     store.Save("wifi_current", 1, payload);
    const auto verified = store.Load("wifi_current", 1);
    return (saved.ok() && verified.ok() && verified.schema == 1 &&
            verified.generation == saved.generation && verified.payload == payload) ||
        Fail(error, "Standard shared Wi-Fi publication could not be verified");
}
bool FinishProjection(const Projection& p, std::string* error) {
    const RecordStore store(shared_directory);
    const auto list = store.Load("wifi_networks", 1);
    if (list.status != RecordStatus::Missing && (!list.ok() || list.schema != 1))
        return Fail(error, "Internal shared Wi-Fi record is unreadable; preserved");
    const std::string actual = list.ok() ? list.payload : std::string{};
    std::string current;
    if (!ReadCurrent(&current, error)) return false;
    std::vector<WifiNetwork> networks;
    if (!DecodeListPayload(p.target, &networks) || (actual != p.before && actual != p.target) ||
        (list.ok() && (list.generation < p.list_generation ||
         (actual != p.before && list.generation == p.list_generation))) ||
        (current != p.current_before && current != CurrentPayload(networks)))
        return Fail(error, "Shared Wi-Fi changed outside the pending transaction; originals preserved");
    if (actual != p.target || p.confirm_both) {
        const auto written = p.confirm_both ? store.SaveConfirmed("wifi_networks", 1, p.target) :
                                             store.Save("wifi_networks", 1, p.target);
        const auto verified = p.confirm_both ? store.LoadConfirmed("wifi_networks", 1) :
                                              store.Load("wifi_networks", 1);
        if (!written.ok() || !verified.ok() || verified.payload != p.target ||
            verified.schema != 1 || verified.generation != written.generation)
            return Fail(error, "Internal shared Wi-Fi commit could not be verified; re-read TF");
    }
    if (!PublishCurrent(networks, p.confirm_both, error)) return false;
    // Drop old credentials from both effective private journal copies as well.
    const auto committed = store.Load("wifi_networks", 1);
    if (!committed.ok() || committed.schema != 1 || committed.payload != p.target)
        return Fail(error, "Shared Wi-Fi list changed before publication confirmation");
    const Projection done{false, false, p.target, p.target, CurrentPayload(networks), committed.generation};
    if (!WriteProjection(done, error)) return false;
    cached_networks = std::move(networks);
    storage_ready = true;
    return Success(error);
}

bool WriteLocked(const std::vector<WifiNetwork>& networks, std::string* error,
                 bool confirm_both = false) {
    if (!storage_ready || shared_directory.empty()) return Fail(error, "Shared Wi-Fi TF storage is unavailable");
    const RecordStore store(shared_directory);
    const auto previous = store.Load("wifi_networks", 1);
    Projection old; bool present = false;
    std::string current;
    if (!previous.ok() || previous.schema != 1) {
        storage_ready = false;
        return Fail(error, "Internal shared Wi-Fi record changed or cannot be read");
    }
    if (!ReadProjection(&old, &present, error) || !ReadCurrent(&current, error)) {
        storage_ready = false; return false;
    }
    if (!present || old.pending || old.target != previous.payload ||
        old.current_before != current) {
        storage_ready = false;
        return Fail(error, "Shared Wi-Fi changed; re-read before submitting a new update");
    }
    const Projection p{true, confirm_both, previous.payload, Encode(networks), current, previous.generation};
    storage_ready = false;
    return WriteProjection(p, error) && FinishProjection(p, error);
}

}  // namespace

bool InitializeSharedWifi(const std::string& directory, std::string* error) {
    if (directory.empty()) return Fail(error, "Shared Wi-Fi directory is required");
    std::lock_guard<std::mutex> lock(wifi_mutex);
    storage_ready = false;
    shared_directory = directory;
    const auto record = RecordStore(directory).Load("wifi_networks", 1);
    std::vector<WifiNetwork> networks;
    if (record.status != RecordStatus::Missing &&
        (!record.ok() || record.schema != 1 || !DecodeListPayload(record.payload, &networks)))
        return Fail(error, "Shared Wi-Fi TF record is unreadable or unsupported");
    Projection journal; bool present = false;
    std::string current;
    if (!ReadProjection(&journal, &present, error) || !ReadCurrent(&current, error)) return false;
    if (present && journal.pending) return FinishProjection(journal, error);
    if (present && journal.current_before != current)
        return Fail(error, "Standard shared Wi-Fi differs from the last completed publication; preserved");
    if (present && record.ok() && (record.generation < journal.list_generation ||
        (record.generation == journal.list_generation && record.payload != journal.target)))
        return Fail(error, "Internal shared Wi-Fi fell behind its committed publication; originals preserved");
    if (record.status == RecordStatus::Missing && present && !journal.target.empty()) {
        std::vector<WifiNetwork> expected;
        if (!DecodeListPayload(journal.target, &expected) || !expected.empty())
            return Fail(error, "Internal shared Wi-Fi list disappeared; existing standard record preserved");
    }
    if (record.status == RecordStatus::Missing && !present) {
        if (!current.empty()) return Fail(error, "Standard Wi-Fi exists without its host list; preserved");
        bool retired = false;
        if (!LegacyImportRetired(&retired, error)) return false;
        if (!retired && !ReadLegacyStore(&networks, error)) return false;
    }
    const auto target = Encode(networks);
    if (!present && !current.empty() && current != CurrentPayload(networks))
        return Fail(error, "Existing standard Wi-Fi conflicts with the host list; preserved");
    if (present && record.ok() && journal.target == record.payload && current == CurrentPayload(networks)) {
        cached_networks = std::move(networks); storage_ready = true; return Success(error);
    }
    // A legacy application may have updated only wifi_networks. The completed
    // journal above proves the standard view is still the last host value.
    const Projection p{true, false, record.ok() ? record.payload : std::string{}, target, current,
                       record.ok() ? record.generation : 0};
    return WriteProjection(p, error) && FinishProjection(p, error);
}
void DisableSharedWifiStorage() {
    std::lock_guard<std::mutex> lock(wifi_mutex);
    storage_ready = false;
    cached_networks.clear();
    shared_directory.clear();
}
bool ReadSharedWifi(std::vector<WifiNetwork>* networks, std::string* error) {
    if (networks == nullptr) return Fail(error, "Wi-Fi output list is required");
    std::lock_guard<std::mutex> lock(wifi_mutex);
    if (!storage_ready) return Fail(error, "Shared Wi-Fi TF storage is unavailable");
    *networks = cached_networks;
    return Success(error);
}
bool SaveSharedWifi(const std::string& ssid, const std::string& password, std::string* error) {
    if (!ValidSsid(ssid) || !ValidPassword(password)) return Fail(error, "Invalid Wi-Fi SSID or password length/NUL");
    std::lock_guard<std::mutex> lock(wifi_mutex);
    if (!storage_ready) return Fail(error, "Shared Wi-Fi TF storage is unavailable");
    auto networks = cached_networks;
    auto found = std::find_if(networks.begin(), networks.end(), [&](const WifiNetwork& item) { return item.ssid == ssid; });
    if (found != networks.end()) networks.erase(found);
    else if (networks.size() >= kMaximumSharedWifiNetworks)
        return Fail(error, "Shared Wi-Fi list is full; forget a network before adding one");
    networks.push_back({ssid, password});
    return WriteLocked(networks, error);
}
bool ForgetSharedWifi(const std::string& ssid, std::string* error) {
    if (!ValidSsid(ssid)) return Fail(error, "Invalid Wi-Fi SSID length/NUL");
    std::lock_guard<std::mutex> lock(wifi_mutex);
    if (!storage_ready) return Fail(error, "Shared Wi-Fi TF storage is unavailable");
    auto networks = cached_networks;
    auto found = std::find_if(networks.begin(), networks.end(), [&](const WifiNetwork& item) { return item.ssid == ssid; });
    if (found != networks.end()) networks.erase(found);
    // Commit the no-reimport policy first. Never erase global/other-app NVS.
    if (!RetireLegacyImport(error)) {
        storage_ready = false;
        return false;
    }
    // Do this even if already absent in the newest copy: a previous failed
    // second write may have left the credential in the older fallback slot.
    // Ordinary Save/Load stay unchanged for existing plus.13 applications.
    return WriteLocked(networks, error, true);
}
}  // namespace pocket
