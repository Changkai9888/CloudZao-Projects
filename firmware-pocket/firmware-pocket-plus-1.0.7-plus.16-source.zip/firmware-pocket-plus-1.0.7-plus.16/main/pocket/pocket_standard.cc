#include "pocket_standard.h"
#include <cJSON.h>
#include <algorithm>
#include <array>
#include <cstddef>
#include <initializer_list>
#include <limits>
#include <utility>

namespace pocket::standard {
namespace {
bool Hex(const std::string& s, std::size_t n) {
    return s.size() == n && std::all_of(s.begin(), s.end(), [](unsigned char c) {
        return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f');
    });
}
bool AppId(const std::string& s) {
    return !s.empty() && s.size() <= 31 && s != "pocket_manager" &&
        s.front() >= 'a' && s.front() <= 'z' &&
        std::all_of(s.begin(), s.end(), [](unsigned char c) {
            return (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '_';
        });
}
bool Version(const std::string& s) {
    return !s.empty() && s.size() <= 31 && std::all_of(s.begin(), s.end(), [](unsigned char c) {
        return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
               (c >= '0' && c <= '9') || c == '_' || c == '.' || c == '+' || c == '-';
    });
}
bool Identity(const std::string& run, const std::string& user, const std::string& app) {
    return Hex(run, 32) && IsSafeIdentifier(user) && AppId(app);
}
bool RunValid(const Run& r) {
    return Identity(r.run_id, r.user_id, r.app_id) && Version(r.version) &&
           Hex(r.image_sha256, 64) &&
           (r.phase == "prepared" || r.phase == "active" || r.phase == "closed");
}
bool ReceiptValid(const Receipt& r) {
    return Identity(r.run_id, r.user_id, r.app_id) &&
           (r.phase == "started" || r.phase == "saved");
}
bool ResultValid(const std::string& s) {
    return s == "processing" || s == "duplicate" || s == "accepted" || s == "failed" || s == "cancelled";
}
bool NetworkValid(const WifiNetwork& n) {
    return !n.ssid.empty() && n.ssid.size() <= 32 && n.password.size() <= 64 &&
           n.ssid.find('\0') == std::string::npos && n.password.find('\0') == std::string::npos;
}
bool Generation(const std::string& s, std::uint64_t* out) {
    if (s.empty() || s.size() > 20 || s[0] == '0') return false;
    std::uint64_t value = 0;
    for (unsigned char c : s) {
        if (c < '0' || c > '9') return false;
        const auto digit = std::uint64_t(c - '0');
        if (value > (std::numeric_limits<std::uint64_t>::max() - digit) / 10) return false;
        value = value * 10 + digit;
    }
    *out = value;
    return true;
}
bool Utf8(const std::string& s) {
    for (std::size_t i = 0; i < s.size();) {
        const auto c = static_cast<unsigned char>(s[i++]);
        if (c < 0x80) continue;
        unsigned count = 0;
        std::uint32_t value = 0, minimum = 0;
        if (c >= 0xc2 && c <= 0xdf) { count = 1; value = c & 31; minimum = 0x80; }
        else if (c >= 0xe0 && c <= 0xef) { count = 2; value = c & 15; minimum = 0x800; }
        else if (c >= 0xf0 && c <= 0xf4) { count = 3; value = c & 7; minimum = 0x10000; }
        else return false;
        if (count > s.size() - i) return false;
        while (count--) {
            const auto next = static_cast<unsigned char>(s[i++]);
            if ((next & 0xc0) != 0x80) return false;
            value = (value << 6) | (next & 63);
        }
        if (value < minimum || value > 0x10ffff || (value >= 0xd800 && value <= 0xdfff)) return false;
    }
    return true;
}
bool Hex4(const std::string& s, std::size_t at, unsigned* out) {
    if (at > s.size() || s.size() - at < 4) return false;
    unsigned value = 0;
    for (std::size_t i = at; i < at + 4; ++i) {
        const auto c = static_cast<unsigned char>(s[i]);
        unsigned digit = 0;
        if (c >= '0' && c <= '9') digit = c - '0';
        else if (c >= 'a' && c <= 'f') digit = c - 'a' + 10;
        else if (c >= 'A' && c <= 'F') digit = c - 'A' + 10;
        else return false;
        value = value * 16 + digit;
    }
    *out = value;
    return true;
}
// cJSON stores decoded strings as C strings. Reject escaped NUL before that
// conversion, plus malformed UTF-8/UTF-16 and non-JSON whitespace. The contract
// has only a root object of strings, so nesting is rejected before recursion.
bool JsonLexical(const std::string& s) {
    if (s.empty() || s.size() > kMaximumRecordBytes || s.find('\0') != std::string::npos ||
        s.compare(0, 3, "\xef\xbb\xbf") == 0 || !Utf8(s)) return false;
    bool quoted = false;
    unsigned objects = 0;
    for (std::size_t i = 0; i < s.size(); ++i) {
        const auto c = static_cast<unsigned char>(s[i]);
        if (!quoted) {
            if (c == '"') quoted = true;
            else if (c == '[' || (c == '{' && ++objects > 1)) return false;
            else if (c < 0x20 && c != '\t' && c != '\n' && c != '\r') return false;
            continue;
        }
        if (c < 0x20) return false;
        if (c == '"') { quoted = false; continue; }
        if (c != '\\') continue;
        if (++i >= s.size()) return false;
        const char escape = s[i];
        if (escape == '"' || escape == '\\' || escape == '/' || escape == 'b' ||
            escape == 'f' || escape == 'n' || escape == 'r' || escape == 't') continue;
        if (escape != 'u') return false;
        unsigned cp = 0;
        if (!Hex4(s, i + 1, &cp) || cp == 0) return false;
        i += 4;
        if (cp >= 0xd800 && cp <= 0xdbff) {
            if (s.size() - i < 7 || s[i + 1] != '\\' || s[i + 2] != 'u') return false;
            unsigned low = 0;
            if (!Hex4(s, i + 3, &low) || low < 0xdc00 || low > 0xdfff) return false;
            i += 6;
        } else if (cp >= 0xdc00 && cp <= 0xdfff) return false;
    }
    return !quoted && objects == 1;
}
struct Json {
    cJSON* root = nullptr;
    ~Json() { cJSON_Delete(root); }
};
template<std::size_t N>
bool Fields(const std::string& payload, const std::array<const char*, N>& names,
            std::array<std::string, N>* values) {
    if (!JsonLexical(payload)) return false;
    Json json;
    const char* end = nullptr;
    json.root = cJSON_ParseWithLengthOpts(payload.c_str(), payload.size() + 1, &end, true);
    if (!json.root || !cJSON_IsObject(json.root) || !end || end != payload.c_str() + payload.size()) return false;
    std::array<bool, N> seen{};
    std::array<std::string, N> parsed;
    for (auto* item = json.root->child; item; item = item->next) {
        if (!item->string || !cJSON_IsString(item) || !item->valuestring) return false;
        std::size_t i = 0;
        while (i < N && names[i] != std::string(item->string)) ++i;
        if (i == N || seen[i]) return false;
        seen[i] = true;
        parsed[i] = item->valuestring;
    }
    if (!std::all_of(seen.begin(), seen.end(), [](bool present) { return present; })) return false;
    *values = std::move(parsed);
    return true;
}
// All callers validate their fields as restricted ASCII first. No source field
// can contain a quote, backslash or control byte, so this does not need escaping.
std::string Object(std::initializer_list<std::pair<const char*, std::string>> fields) {
    std::string result = "{";
    for (const auto& f : fields) {
        if (result.size() > 1) result += ',';
        result += '"'; result += f.first; result += "\":\""; result += f.second; result += '"';
    }
    result += '}';
    return result;
}
}  // namespace

std::string EncodeRun(const RunContext& r) {
    const Run p{r.run_id, r.user_id, r.app_id, r.version, r.image_sha256, r.phase};
    if (!RunValid(p)) return {};
    return Object({{"run_id", p.run_id}, {"user_id", p.user_id}, {"app_id", p.app_id},
                   {"version", p.version}, {"image_sha256", p.image_sha256}, {"phase", p.phase}});
}
bool DecodeRun(const std::string& payload, Run* output) {
    if (!output) return false;
    std::array<std::string, 6> v;
    if (!Fields(payload, std::array<const char*, 6>{"run_id", "user_id", "app_id", "version", "image_sha256", "phase"}, &v)) return false;
    Run r{v[0], v[1], v[2], v[3], v[4], v[5]};
    if (!RunValid(r)) return false;
    *output = std::move(r);
    return true;
}
bool Matches(const Run& p, const RunContext& r) {
    return RunValid(p) && p.run_id == r.run_id && p.user_id == r.user_id && p.app_id == r.app_id &&
           p.version == r.version && p.image_sha256 == r.image_sha256 && p.phase == r.phase;
}
std::string EncodeReceipt(const RunContext& r, bool saved) {
    const Receipt receipt{r.run_id, r.user_id, r.app_id, saved ? "saved" : "started"};
    if (!ReceiptValid(receipt)) return {};
    return Object({{"run_id", receipt.run_id}, {"user_id", receipt.user_id},
                   {"app_id", receipt.app_id}, {"phase", receipt.phase}});
}
bool DecodeReceipt(const std::string& payload, Receipt* output) {
    if (!output) return false;
    std::array<std::string, 4> v;
    if (!Fields(payload, std::array<const char*, 4>{"run_id", "user_id", "app_id", "phase"}, &v)) return false;
    Receipt r{v[0], v[1], v[2], v[3]};
    if (!ReceiptValid(r)) return false;
    *output = std::move(r);
    return true;
}
bool Matches(const Receipt& p, const RunContext& r) {
    return ReceiptValid(p) && p.run_id == r.run_id && p.user_id == r.user_id && p.app_id == r.app_id;
}
std::string EncodeNetwork(const WifiNetwork& n) {
    if (!NetworkValid(n)) return {};
    std::string result;
    result.push_back(static_cast<char>(n.ssid.size()));
    result.push_back(static_cast<char>(n.password.size()));
    return result + n.ssid + n.password;
}
bool DecodeNetwork(const std::string& payload, WifiNetwork* output) {
    if (!output || payload.size() < 3 || payload.size() > 98) return false;
    const auto sn = static_cast<unsigned char>(payload[0]);
    const auto pn = static_cast<unsigned char>(payload[1]);
    if (payload.size() != 2U + sn + pn) return false;
    WifiNetwork n{payload.substr(2, sn), payload.substr(2 + sn, pn)};
    if (!NetworkValid(n)) return false;
    *output = std::move(n);
    return true;
}
std::string EncodeOffer(const WifiOffer& o) {
    if (!Hex(o.run_id, 32)) return {};
    const auto network = EncodeNetwork({o.ssid, o.password});
    if (network.empty()) return {};
    std::string result;
    for (std::size_t i = 0; i < 32; i += 2) {
        const auto digit = [](char c) { return c <= '9' ? c - '0' : c - 'a' + 10; };
        result.push_back(static_cast<char>(digit(o.run_id[i]) * 16 + digit(o.run_id[i + 1])));
    }
    return result + network;
}
bool DecodeOffer(const RecordResult& record, WifiOffer* output) {
    if (!output || !record.ok() || record.schema != 1 || !record.generation ||
        record.payload.size() < 19 || record.payload.size() > 114) return false;
    WifiNetwork network;
    if (!DecodeNetwork(record.payload.substr(16), &network)) return false;
    WifiOffer offer;
    static constexpr char hex[] = "0123456789abcdef";
    for (std::size_t i = 0; i < 16; ++i) {
        const auto c = static_cast<unsigned char>(record.payload[i]);
        offer.run_id += hex[c >> 4]; offer.run_id += hex[c & 15];
    }
    offer.ssid = std::move(network.ssid); offer.password = std::move(network.password);
    offer.generation = record.generation;
    offer.protocol = HandoffProtocol::Standard10;
    *output = std::move(offer);
    return true;
}
std::string EncodeWifiResult(const WifiOffer& offer, const std::string& result) {
    if (!Hex(offer.run_id, 32) || !offer.generation || !ResultValid(result)) return {};
    return Object({{"run_id", offer.run_id}, {"offer_generation", std::to_string(offer.generation)}, {"result", result}});
}
bool DecodeWifiResult(const std::string& payload, WifiResult* output) {
    if (!output) return false;
    std::array<std::string, 3> v;
    if (!Fields(payload, std::array<const char*, 3>{"run_id", "offer_generation", "result"}, &v)) return false;
    WifiResult r;
    r.run_id = std::move(v[0]); r.result = std::move(v[2]);
    if (!Hex(r.run_id, 32) || !Generation(v[1], &r.offer_generation) || !ResultValid(r.result)) return false;
    *output = std::move(r);
    return true;
}
}  // namespace pocket::standard
