#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace pocket {

struct WifiAccessPoint {
    std::string ssid;
    int rssi = -100;
    bool secured = true;
};

struct WifiConnectionView {
    uint32_t revision = 0;
    // Candidate completion belongs only to this token. No password is exposed.
    uint32_t candidate_token = 0;
    bool candidate_done = false, candidate_connected = false;
    bool ready = false;
    bool scanning = false;
    bool connecting = false;
    bool connected = false;
    int signal_bars = 0;
    std::string ssid;
    std::string ip;
    std::string message;
    std::vector<WifiAccessPoint> access_points;
};

// Start once from an internal-RAM task after board/NVS initialization. The
// service owns radio operations; UI calls below only copy cached data or queue
// requests. Credentials remain in pocket_wifi and are never exposed in View.
void StartWifiConnection();
WifiConnectionView WifiConnectionSnapshot();
bool RequestWifiScan();
// Caller saves/validates the user's entered password first. This API reads the
// latest saved credential on its worker, including every automatic reconnect.
bool RequestWifiConnect(const std::string& ssid);
bool RequestWifiDisconnect();
// Temporary credentials stay in RAM. Returns zero on invalid input/queue failure.
// A newer manual connect/disconnect request supersedes this attempt. The caller
// must match the token and candidate_done before adopting; IP success is not an
// assertion of Internet/API reachability or successful shared persistence.
uint32_t RequestWifiCandidate(const std::string& ssid, const std::string& password);
// After TF SaveSharedWifi/readback, promote the exact successful candidate to
// ordinary reconnect policy, without disconnecting the newly established link.
bool AcceptWifiCandidate(uint32_t token);

}  // namespace pocket
