#include "pocket_pin.h"

#include <algorithm>
#include <cstring>
#include <utility>

#ifdef ESP_PLATFORM
#include "esp_random.h"
#else
#include <random>
#endif

#include "pocket_hash.h"

namespace pocket {
namespace {
constexpr char kKey[] = "wake_pin";
constexpr char kMagic[] = "WAKEPIN1";
constexpr char kDomain[] = "FPOCKET-WAKE-PIN-SHA256-v1";
constexpr std::size_t kPayloadSize = 64;
constexpr std::uint32_t kSchema = 1;

bool Fail(std::string* error, const char* message) {
    if (error != nullptr) *error = message;
    return false;
}

bool FillSalt(std::array<unsigned char, 16>* salt) {
#ifdef ESP_PLATFORM
    esp_fill_random(salt->data(), salt->size());
    return true;
#else
    try {
        std::random_device random;
        for (auto& byte : *salt) byte = static_cast<unsigned char>(random());
        return true;
    } catch (...) {
        return false;
    }
#endif
}

bool Digest(const std::array<unsigned char, 16>& salt, const std::string& pin,
            std::array<unsigned char, 32>* output) {
    Sha256 sha;
    return sha.Add(kDomain, sizeof(kDomain) - 1) &&
           sha.Add(salt.data(), salt.size()) && sha.Add(pin.data(), pin.size()) &&
           sha.Finish(output->data());
}

// Avoid returning at the first mismatching digest byte. This does not turn a
// short numeric PIN into an encrypted-card security boundary.
bool SameDigest(const std::array<unsigned char, 32>& a,
                const std::array<unsigned char, 32>& b) {
    volatile unsigned char difference = 0;
    for (std::size_t i = 0; i < a.size(); ++i)
        difference = static_cast<unsigned char>(difference | (a[i] ^ b[i]));
    return difference == 0;
}
}  // namespace

WakePinStore::WakePinStore(std::string directory) : records_(std::move(directory)) {}

bool WakePinStore::ValidPin(const std::string& pin) {
    return pin.size() >= 4 && pin.size() <= 8 &&
           std::all_of(pin.begin(), pin.end(), [](unsigned char value) {
               return value >= '0' && value <= '9';
           });
}

bool WakePinStore::Load(std::string* error) {
    ready_ = false;
    needs_unlock_ = true;
    is_default_ = false;
    const auto result = records_.LoadConfirmed(kKey, kSchema);
    if (result.status == RecordStatus::Missing) {
        if (ever_loaded_) return Fail(error, "wake PIN record disappeared during this session");
        std::array<unsigned char, 16> salt{};
        std::array<unsigned char, 32> digest{};
        if (!FillSalt(&salt) || !Digest(salt, "1234", &digest))
            return Fail(error, "wake PIN initialization failed");
        return Save(salt, digest, false, true, error);
    }
    if (!result.ok()) return Fail(error, "wake PIN record is unavailable or inconsistent");
    const std::string& payload = result.payload;
    if (result.schema != kSchema || payload.size() != kPayloadSize ||
        std::memcmp(payload.data(), kMagic, 8) != 0 ||
        static_cast<unsigned char>(payload[8]) > 1)
        return Fail(error, "wake PIN record format is invalid");
    for (std::size_t i = 9; i < 16; ++i)
        if (payload[i] != 0) return Fail(error, "wake PIN record reserved field is invalid");
    std::memcpy(salt_.data(), payload.data() + 16, salt_.size());
    std::memcpy(digest_.data(), payload.data() + 32, digest_.size());
    needs_unlock_ = payload[8] != 0;
    ready_ = true;
    ever_loaded_ = true;
    is_default_ = Verify("1234");
    if (error != nullptr) error->clear();
    return true;
}

bool WakePinStore::Verify(const std::string& pin) const {
    if (!ready_ || !ValidPin(pin)) return false;
    std::array<unsigned char, 32> candidate{};
    return Digest(salt_, pin, &candidate) && SameDigest(candidate, digest_);
}

bool WakePinStore::Save(const std::array<unsigned char, 16>& salt,
                        const std::array<unsigned char, 32>& digest,
                        bool needs_unlock, bool is_default, std::string* error) {
    if (ever_loaded_ && !records_.LoadConfirmed(kKey, kSchema).ok()) {
        ready_ = false;
        needs_unlock_ = true;
        is_default_ = false;
        return Fail(error, "wake PIN record changed or disappeared before write");
    }
    std::string payload(kPayloadSize, '\0');
    std::memcpy(&payload[0], kMagic, 8);
    payload[8] = needs_unlock ? 1 : 0;
    std::memcpy(&payload[16], salt.data(), salt.size());
    std::memcpy(&payload[32], digest.data(), digest.size());
    const auto saved = records_.SaveConfirmed(kKey, kSchema, payload);
    if (!saved.ok() || saved.payload != payload) {
        // One slot may contain the new value after a failed second write. Do
        // not keep serving a stale in-memory password or claim the lock saved.
        ready_ = false;
        needs_unlock_ = true;
        is_default_ = false;
        return Fail(error, "wake PIN storage write or verification failed");
    }
    salt_ = salt;
    digest_ = digest;
    needs_unlock_ = needs_unlock;
    is_default_ = is_default;
    ready_ = true;
    ever_loaded_ = true;
    if (error != nullptr) error->clear();
    return true;
}

bool WakePinStore::Change(const std::string& current, const std::string& next,
                          std::string* error) {
    if (!ready_) return Fail(error, "wake PIN record is not ready");
    if (!ValidPin(next)) return Fail(error, "PIN must contain 4 to 8 digits");
    if (!Verify(current)) return Fail(error, "current PIN is incorrect");
    std::array<unsigned char, 16> salt{};
    std::array<unsigned char, 32> digest{};
    if (!FillSalt(&salt) || !Digest(salt, next, &digest))
        return Fail(error, "wake PIN hashing failed");
    return Save(salt, digest, needs_unlock_, next == "1234", error);
}

bool WakePinStore::SetNeedsUnlock(bool value, std::string* error) {
    if (!ready_) return Fail(error, "wake PIN record is not ready");
    // Even an unchanged value is confirmed on TF before entering deep sleep.
    return Save(salt_, digest_, value, is_default_, error);
}

}  // namespace pocket
