#pragma once

#include "pocket_handoff.h"
#include <string>

namespace pocket {

// Caller serializes this with scanning/install/TF ownership changes. Both roots
// are existing trusted directories, scoped to the current TF/user. Only control
// records are copied, including both public and legacy control channels when
// present. New eight-slot archives use archive16/FPARCHIVE2; previous four-slot
// archive107/FPARCHIVE1 histories remain verifiable. No business data, NVS, or
// receipt is rewritten here.
// A valid Unfinished run is archived and fault-marked before SaveRun(closed).
// Repeating an already completed isolation is an integrity-checked no-op.
// Invalid/global I/O states stay blocked; this is not a corrupt-record repair.
bool IsolateUnfinished(const std::string& status_dir,
                      const std::string& recovery_root,
                      const std::string& user_id, std::string* error);

// Explicit confirmation releases only the exact archived failed run. Both fault
// and history stay intact; no saved receipt or business data is manufactured.
// Caller must use the ORIGINAL active RunContext shown by LoadIsolated and hold
// the same scan/install/TF ownership serialization as IsolateUnfinished.
// Interrupted matching release commits may be retried; unknown damage is refused.
bool ReleaseIsolated(const std::string& recovery_root,
                     const RunContext& expected, std::string* error);

// Missing means no per-app/version fault, or the exact fault has a confirmed
// release. A later failed run is blocked again, even for the identical image.
// Ok returns the ORIGINAL active run,
// including the full image hash. Runtime decides whether the selected package
// is that same image; a different hash is not implicitly blocked by this API.
// Other statuses must not be treated as Missing. Output changes only on Ok.
RecordStatus LoadIsolated(const std::string& recovery_root,
                          const std::string& app_id, const std::string& version,
                          RunContext* output, std::string* error);

}  // namespace pocket
