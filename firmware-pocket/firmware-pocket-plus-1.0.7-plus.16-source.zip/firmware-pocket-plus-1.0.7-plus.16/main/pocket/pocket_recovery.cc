#include "pocket_recovery.h"
#include "pocket_hash.h"
#include "pocket_standard.h"

#include <algorithm>
#include <array>
#include <cerrno>
#include <cstdio>
#include <cstring>
#include <fcntl.h>
#include <limits>
#include <string>
#include <sys/stat.h>
#include <unistd.h>

namespace pocket {
namespace {
constexpr size_t kArchiveLimit = 8192;
// Legacy slots stay first: a pre-plus16 archive contains exactly these four.
// Public control slots are preserved as raw evidence, not translated receipts.
constexpr size_t kLegacySlots = 4;
constexpr std::array<const char*, 8> kSlots{
    "run107.a.pkr", "run107.b.pkr", "receipt107.a.pkr", "receipt107.b.pkr",
    "run.a.pkr", "run.b.pkr", "receipt.a.pkr", "receipt.b.pkr"};
struct Raw { bool present = false; std::string bytes; };
using Originals = std::array<Raw, kSlots.size()>;

bool Fail(std::string* error, const char* value) { if (error) *error = value; return false; }
RecordStatus Status(RecordStatus status, std::string* error, const char* value) {
    if (error) *error = value;
    return status;
}
bool Root(const std::string& path) {
    return !path.empty() && path.size() <= 360 && path.find('\0') == std::string::npos &&
           path.find('\n') == std::string::npos && path.find('\r') == std::string::npos;
}
bool Version(const std::string& version) {
    return !version.empty() && version.size() <= 31 && version != "." && version != ".." &&
        std::all_of(version.begin(), version.end(), [](unsigned char c) {
            return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
                   (c >= '0' && c <= '9') || c == '.' || c == '_' || c == '+' || c == '-';
        });
}
int PathStat(const std::string& path, struct stat* value) {
#if defined(ESP_PLATFORM)
    return stat(path.c_str(), value); // FATFS has no symbolic links.
#else
    return lstat(path.c_str(), value);
#endif
}
RecordStatus Directory(const std::string& path, bool create, std::string* error) {
    struct stat info{};
    if (PathStat(path, &info) == 0)
        return S_ISDIR(info.st_mode) ? RecordStatus::Ok :
               Status(RecordStatus::IoError, error, "recovery path is not a directory");
    if (errno != ENOENT) return Status(RecordStatus::IoError, error, "cannot inspect recovery directory");
    if (!create) return RecordStatus::Missing;
    if (mkdir(path.c_str(), 0700) != 0 && errno != EEXIST)
        return Status(RecordStatus::IoError, error, "cannot create recovery directory");
    if (PathStat(path, &info) != 0 || !S_ISDIR(info.st_mode))
        return Status(RecordStatus::IoError, error, "recovery directory could not be confirmed");
    return RecordStatus::Ok;
}
RecordStatus ReadRaw(const std::string& path, Raw* out, std::string* error) {
    int flags = O_RDONLY;
#if defined(O_NOFOLLOW) && !defined(ESP_PLATFORM)
    flags |= O_NOFOLLOW;
#endif
    const int fd = open(path.c_str(), flags);
    if (fd < 0) return errno == ENOENT ? RecordStatus::Missing :
        Status(RecordStatus::IoError, error, "cannot read original recovery control file");
    struct stat info{};
    if (fstat(fd, &info) != 0 || !S_ISREG(info.st_mode) || info.st_size < 0 ||
        info.st_size > static_cast<off_t>(kArchiveLimit)) {
        close(fd);
        return Status(RecordStatus::IoError, error, "control file is not regular or exceeds 8 KiB");
    }
    std::string bytes(static_cast<size_t>(info.st_size), '\0');
    size_t at = 0;
    while (at < bytes.size()) {
        const auto count = read(fd, &bytes[at], bytes.size() - at);
        if (count < 0 && errno == EINTR) continue;
        if (count <= 0) { close(fd); return Status(RecordStatus::IoError, error, "control file read was incomplete"); }
        at += static_cast<size_t>(count);
    }
    char extra = 0;
    ssize_t trailing;
    do { trailing = read(fd, &extra, 1); } while (trailing < 0 && errno == EINTR);
    const int closed = close(fd);
    if (trailing != 0 || closed != 0)
        return Status(RecordStatus::IoError, error, "control file changed or failed to close");
    out->present = true; out->bytes = std::move(bytes);
    return RecordStatus::Ok;
}
bool OriginalsAt(const std::string& dir, Originals* out, std::string* error) {
    for (size_t i = 0; i < kSlots.size(); ++i) {
        const auto state = ReadRaw(dir + "/" + kSlots[i], &(*out)[i], error);
        if (state != RecordStatus::Ok && state != RecordStatus::Missing) return false;
        if (i < 2 && state != RecordStatus::Ok) return Fail(error, "original run control slot is absent");
    }
    return true;
}
bool Same(const Originals& a, const Originals& b) {
    for (size_t i = 0; i < a.size(); ++i)
        if (a[i].present != b[i].present || a[i].bytes != b[i].bytes) return false;
    return true;
}
bool Digest(const std::string& data, std::string* out) {
    std::array<unsigned char, 32> digest{};
    Sha256 context;
    const bool ok = context.Add(data.data(), data.size()) && context.Finish(digest.data());
    if (!ok) return false;
    static constexpr char hex[] = "0123456789abcdef";
    std::string text; text.reserve(64);
    for (unsigned char byte : digest) { text.push_back(hex[byte >> 4]); text.push_back(hex[byte & 15]); }
    *out = std::move(text); return true;
}
bool HasStandard(const Originals& originals) {
    for (size_t i = kLegacySlots; i < originals.size(); ++i)
        if (originals[i].present) return true;
    return false;
}
std::string ArchivePayload(const std::string& run, const Originals& originals, bool standard) {
    std::string payload = std::string(standard ? "FPARCHIVE2\n" : "FPARCHIVE1\n") + run + "\n";
    const size_t count = standard ? originals.size() : kLegacySlots;
    for (size_t i = 0; i < count; ++i) {
        payload += std::string(kSlots[i]) + "\n";
        if (!originals[i].present) payload += "missing\n";
        else {
            std::string digest;
            if (!Digest(originals[i].bytes, &digest)) return {};
            payload += std::to_string(originals[i].bytes.size()) + ":" + digest + "\n";
        }
    }
    return payload;
}

// Atomic publication of one immutable raw archive. An interrupted temporary
// file may be completed only when its complete contents are an exact prefix of
// the intended original. An existing final archive is never overwritten.
bool CopyImmutable(const std::string& destination, const std::string& bytes, std::string* error) {
    Raw current;
    auto state = ReadRaw(destination, &current, error);
    if (state == RecordStatus::Ok) return current.bytes == bytes || Fail(error, "archive already exists with different original bytes");
    if (state != RecordStatus::Missing) return false;
    const std::string temporary = destination + ".tmp";
    Raw pending;
    state = ReadRaw(temporary, &pending, error);
    if (state != RecordStatus::Ok && state != RecordStatus::Missing) return false;
    if (pending.present && (pending.bytes.size() > bytes.size() ||
        bytes.compare(0, pending.bytes.size(), pending.bytes) != 0))
        return Fail(error, "temporary archive does not match the original; preserved");
    int flags = O_WRONLY | (pending.present ? O_APPEND : O_CREAT | O_EXCL);
#if defined(O_NOFOLLOW) && !defined(ESP_PLATFORM)
    flags |= O_NOFOLLOW;
#endif
    const int fd = open(temporary.c_str(), flags, 0600);
    if (fd < 0) return Fail(error, "cannot create or resume temporary archive");
    size_t at = pending.bytes.size();
    bool ok = true;
    while (at < bytes.size()) {
        const auto count = write(fd, bytes.data() + at, bytes.size() - at);
        if (count < 0 && errno == EINTR) continue;
        if (count <= 0) { ok = false; break; }
        at += static_cast<size_t>(count);
    }
    if (ok) ok = fsync(fd) == 0;
    if (close(fd) != 0) ok = false;
    if (!ok) return Fail(error, "archive write or sync failed; original run remains active");
    Raw verified;
    if (ReadRaw(temporary, &verified, error) != RecordStatus::Ok || verified.bytes != bytes)
        return Fail(error, "temporary archive readback failed");
    // Caller serialization is mandatory: FATFS has no rename-no-replace API.
    Raw latest;
    state = ReadRaw(destination, &latest, error);
    if (state == RecordStatus::Ok) return latest.bytes == bytes || Fail(error, "archive appeared with different original bytes");
    if (state != RecordStatus::Missing) return false;
    if (rename(temporary.c_str(), destination.c_str()) != 0) return Fail(error, "archive publication failed");
    Raw published;
    if (ReadRaw(destination, &published, error) != RecordStatus::Ok || published.bytes != bytes)
        return Fail(error, "published archive readback failed");
    return true;
}

bool Confirm(const std::string& directory, const char* key,
             const std::string& payload, std::string* error) {
    RecordStore store(directory);
    const auto confirmed = store.LoadConfirmed(key, 1);
    if (confirmed.ok()) {
        if (confirmed.payload != payload) return Fail(error, "immutable archive manifest differs; preserved");
        return true;
    }
    if (confirmed.status != RecordStatus::Missing) {
        // A completed first commit followed by an interrupted second commit can
        // be repeated only if the surviving production record is exactly ours.
        const auto surviving = store.Load(key, 1);
        if (!surviving.ok() || surviving.payload != payload) return Fail(error, "archive manifest cannot be confirmed; preserved");
    }
    const auto written = store.SaveConfirmed(key, 1, payload);
    return written.ok() || Fail(error, "archive manifest could not be committed");
}
bool ValidReceipt(const RecordResult& receipt, const std::string& user) {
    if (receipt.status == RecordStatus::Missing) return true;
    if (!receipt.ok() || receipt.schema != 1 || receipt.payload.empty() || receipt.payload.back() != '\n' ||
        receipt.payload.find('\0') != std::string::npos) return false;
    std::array<std::string, 5> lines;
    size_t at = 0;
    for (auto& line : lines) {
        const auto end = receipt.payload.find('\n', at);
        if (end == std::string::npos || end == at) return false;
        line = receipt.payload.substr(at, end - at); at = end + 1;
    }
    return at == receipt.payload.size() && lines[0] == "FPRECEIPT1" && ValidRunId(lines[1]) &&
        lines[2] == user && IsSafeIdentifier(lines[3]) && lines[3] != "pocket_manager" &&
        (lines[4] == "started" || lines[4] == "saved");
}
bool ValidStandardReceipt(const RecordResult& receipt, const std::string& user) {
    if (receipt.status == RecordStatus::Missing) return true;
    standard::Receipt decoded;
    return receipt.ok() && receipt.schema == 1 &&
        standard::DecodeReceipt(receipt.payload, &decoded) && decoded.user_id == user;
}
bool ValidRecoveryReceipt(const std::string& dir, const HandoffView& view) {
    const RecordStore store(dir);
    if (view.protocol == HandoffProtocol::Standard10) {
        const auto receipt = store.Load("receipt", 1);
        standard::Receipt decoded;
        // The public contract permits one valid latest slot. Its source data
        // is preserved below even when the inactive legacy channel is absent
        // or contains old damage; that is not an extra public admission rule.
        return receipt.ok() && receipt.schema == 1 &&
            standard::DecodeReceipt(receipt.payload, &decoded) &&
            standard::Matches(decoded, view.run) && decoded.phase == "started";
    }
    if (view.protocol == HandoffProtocol::Legacy107)
        return ValidReceipt(store.LoadConfirmed("receipt107", 1), view.run.user_id);
    // A run that never published started can still be isolated truthfully.
    // Unknown/corrupt control data must not be silently called absent.
    return ValidReceipt(store.LoadConfirmed("receipt107", 1), view.run.user_id) &&
        ValidStandardReceipt(store.Load("receipt", 1), view.run.user_id);
}
bool FaultDirectory(const std::string& root, const std::string& app, const std::string& version,
                    bool create, std::string* directory, RecordStatus* state, std::string* error) {
    *directory = root;
    for (const auto& part : {std::string("blocked"), app, std::string("v_") + version}) {
        *directory += "/" + part;
        *state = Directory(*directory, create, error);
        if (*state != RecordStatus::Ok) return false;
    }
    return true;
}
bool VerifyArchive(const std::string& history, const RunContext& run, std::string* error) {
    if (Directory(history, false, error) != RecordStatus::Ok)
        return Fail(error, "archive directory cannot be confirmed");
    Originals archived;
    if (!OriginalsAt(history, &archived, error)) return false;
    const bool has_standard = HasStandard(archived);
    const auto expected = ArchivePayload(run.run_id, archived, has_standard);
    const RecordStore store(history);
    const auto manifest = store.LoadConfirmed(has_standard ? "archive16" : "archive107", 1);
    const auto other = store.LoadConfirmed(has_standard ? "archive107" : "archive16", 1);
    const auto view = InspectHandoff(history, run.user_id);
    if (expected.empty() || !manifest.ok() || manifest.payload != expected ||
        other.status != RecordStatus::Missing ||
        view.state != HandoffState::Unfinished || EncodeRun(view.run) != EncodeRun(run) ||
        !ValidRecoveryReceipt(history, view))
        return Fail(error, "archived original control records cannot be confirmed");
    return true;
}
bool SaveFault(const std::string& directory, const RunContext& run, std::string* error) {
    RecordStore store(directory);
    const std::string payload = EncodeRun(run);
    const auto before = store.LoadConfirmed("fault107", 1);
    if (before.ok() && before.payload == payload) return true;
    if (before.status != RecordStatus::Missing) {
        const auto previous = before.ok() ? before : store.Load("fault107", 1);
        RunContext parsed;
        if (!previous.ok() || !DecodeRun(previous.payload, &parsed) || parsed.phase != "active" ||
            parsed.user_id != run.user_id || parsed.app_id != run.app_id || parsed.version != run.version ||
            (!before.ok() && previous.payload != payload))
            return Fail(error, "existing fault record cannot be confirmed; original run remains active");
    }
    const auto saved = store.SaveConfirmed("fault107", 1, payload);
    return saved.ok() || Fail(error, "fault record write failed; original run remains active");
}
RecordStatus FaultAt(const std::string& directory, const std::string& app,
                     const std::string& version, RunContext* output, std::string* error) {
    const auto record = RecordStore(directory).LoadConfirmed("fault107", 1);
    if (!record.ok()) {
        if (error) *error = record.status == RecordStatus::Missing ? "" : record.error;
        return record.status;
    }
    RunContext parsed;
    if (!DecodeRun(record.payload, &parsed) || parsed.phase != "active" ||
        parsed.app_id != app || parsed.version != version)
        return Status(RecordStatus::Corrupt, error, "isolated-application record does not match its directory");
    *output = std::move(parsed);
    return RecordStatus::Ok;
}
bool RetryIdentity(const std::string& payload, const RunContext& fault) {
    RunContext retry;
    return DecodeRun(payload, &retry) && retry.phase == "active" &&
        retry.user_id == fault.user_id && retry.app_id == fault.app_id && retry.version == fault.version;
}
RecordStatus RetryAt(const std::string& directory, const RunContext& fault,
                     bool* released, std::string* error) {
    *released = false;
    const auto retry = RecordStore(directory).LoadConfirmed("retry107", 1);
    if (retry.status == RecordStatus::Missing) return RecordStatus::Missing;
    if (!retry.ok()) return Status(retry.status, error, retry.error.c_str());
    if (!RetryIdentity(retry.payload, fault))
        return Status(RecordStatus::Corrupt, error, "release record does not match its application and user");
    // An older, valid release is evidence for that run only. Hash equality on
    // its own must never become a permanent exemption for future crashes.
    *released = retry.payload == EncodeRun(fault);
    return RecordStatus::Ok;
}
}  // namespace

RecordStatus LoadIsolated(const std::string& root, const std::string& app, const std::string& version,
                          RunContext* output, std::string* error) {
    if (error) error->clear();
    if (!output || !Root(root) || !IsSafeIdentifier(app) || app == "pocket_manager" || !Version(version))
        return Status(RecordStatus::InvalidArgument, error, "invalid isolated-application identity or path");
    auto state = Directory(root, false, error);
    if (state != RecordStatus::Ok) return state == RecordStatus::Missing ?
        Status(RecordStatus::IoError, error, "recovery root unavailable") : state;
    std::string directory;
    if (!FaultDirectory(root, app, version, false, &directory, &state, error)) return state;
    RunContext parsed;
    state = FaultAt(directory, app, version, &parsed, error);
    if (state != RecordStatus::Ok) return state;
    bool released = false;
    state = RetryAt(directory, parsed, &released, error);
    if (state != RecordStatus::Ok && state != RecordStatus::Missing) return state;
    if (released) return RecordStatus::Missing;
    *output = std::move(parsed);
    return RecordStatus::Ok;
}

bool ReleaseIsolated(const std::string& root, const RunContext& expected, std::string* error) {
    if (error) error->clear();
    const std::string payload = EncodeRun(expected);
    if (!Root(root) || payload.empty() || expected.phase != "active" || !Version(expected.version))
        return Fail(error, "invalid release context or recovery root");
    if (Directory(root, false, error) != RecordStatus::Ok)
        return Fail(error, "release recovery root unavailable");
    RecordStatus state;
    std::string directory;
    if (!FaultDirectory(root, expected.app_id, expected.version, false, &directory, &state, error))
        return Fail(error, "isolated application directory unavailable");
    RunContext fault;
    if (FaultAt(directory, expected.app_id, expected.version, &fault, error) != RecordStatus::Ok ||
        EncodeRun(fault) != payload)
        return Fail(error, "isolated run changed or cannot be confirmed; release refused");
    if (Directory(root + "/history", false, error) != RecordStatus::Ok ||
        !VerifyArchive(root + "/history/" + expected.run_id, expected, error))
        return Fail(error, "original failed-run archive cannot be confirmed; release refused");
    RecordStore store(directory);
    const auto before = store.LoadConfirmed("retry107", 1);
    if (before.ok()) {
        if (!RetryIdentity(before.payload, expected))
            return Fail(error, "existing release identity is invalid; preserved");
        if (before.payload == payload) return true;
    } else if (before.status != RecordStatus::Missing) {
        // Only explicit confirmation can complete a known matching first
        // commit. Scan-time readers continue to reject the half transaction.
        // Degraded copies, future formats and I/O failures are never repaired.
        const auto surviving = store.Load("retry107", 1);
        if (before.status != RecordStatus::Corrupt || !surviving.ok() || surviving.degraded ||
            surviving.payload != payload)
            return Fail(error, "release copies cannot be confirmed; preserved");
    }
    const auto written = store.SaveConfirmed("retry107", 1, payload);
    if (!written.ok()) return Fail(error, "release record could not be committed; retry requires confirmation");
    // Caller serialization protects this snapshot; still re-read the exact
    // fault so a stale selection cannot report that a newer failure was freed.
    if (FaultAt(directory, expected.app_id, expected.version, &fault, error) != RecordStatus::Ok ||
        EncodeRun(fault) != payload)
        return Fail(error, "isolated run changed during release");
    if (error) error->clear();
    return true;
}

bool IsolateUnfinished(const std::string& status_dir, const std::string& root,
                      const std::string& user, std::string* error) {
    if (error) error->clear();
    if (!Root(status_dir) || !Root(root) || !IsSafeIdentifier(user))
        return Fail(error, "invalid recovery root or user identity");
    if (Directory(status_dir, false, error) != RecordStatus::Ok ||
        Directory(root, false, error) != RecordStatus::Ok)
        return Fail(error, "recovery or control root unavailable; originals preserved");
    const auto view = InspectHandoff(status_dir, user);
    if ((view.state != HandoffState::Unfinished && view.state != HandoffState::Closed) ||
        !Version(view.run.version)) return Fail(error, "only a valid unfinished handoff may be isolated");
    RunContext original = view.run; original.phase = "active";
    const std::string history = root + "/history/" + original.run_id;
    if (view.state == HandoffState::Closed) {
        RunContext fault;
        RecordStatus state;
        std::string directory;
        bool released = false;
        if (Directory(root + "/history", false, error) != RecordStatus::Ok ||
            !FaultDirectory(root, original.app_id, original.version, false, &directory, &state, error) ||
            FaultAt(directory, original.app_id, original.version, &fault, error) != RecordStatus::Ok ||
            EncodeRun(fault) != EncodeRun(original) || !VerifyArchive(history, original, error))
            return Fail(error, "closed handoff has no matching confirmed isolation");
        state = RetryAt(directory, fault, &released, error);
        if (state != RecordStatus::Ok && state != RecordStatus::Missing) return false;
        return true;
    }
    if (!ValidRecoveryReceipt(status_dir, view))
        return Fail(error, "receipt is unreadable or invalid; originals preserved");
    Originals source;
    if (!OriginalsAt(status_dir, &source, error)) return false;
    if (Directory(root + "/history", true, error) != RecordStatus::Ok ||
        Directory(history, true, error) != RecordStatus::Ok) return false;
    for (size_t i = 0; i < source.size(); ++i) {
        if (source[i].present) {
            if (!CopyImmutable(history + "/" + kSlots[i], source[i].bytes, error)) return false;
        } else {
            Raw existing;
            if (ReadRaw(history + "/" + kSlots[i], &existing, error) != RecordStatus::Missing)
                return Fail(error, "archive contains a receipt that was absent from the original");
        }
    }
    const bool has_standard = HasStandard(source);
    const auto payload = ArchivePayload(original.run_id, source, has_standard);
    if (RecordStore(history).LoadConfirmed(has_standard ? "archive107" : "archive16", 1).status != RecordStatus::Missing)
        return Fail(error, "different archive manifest already exists; originals preserved");
    if (payload.empty() || !Confirm(history, has_standard ? "archive16" : "archive107", payload, error) ||
        !VerifyArchive(history, original, error)) return false;
    RecordStatus state;
    std::string fault_directory;
    if (!FaultDirectory(root, original.app_id, original.version, true, &fault_directory, &state, error) ||
        !SaveFault(fault_directory, original, error)) return false;
    // Nothing before this point changes the global handoff. Refuse a stale
    // snapshot if an app has meanwhile published saved or another run appeared.
    const auto latest = InspectHandoff(status_dir, user);
    Originals last_source;
    if (latest.state != HandoffState::Unfinished || EncodeRun(latest.run) != EncodeRun(original) ||
        !OriginalsAt(status_dir, &last_source, error) || !Same(source, last_source))
        return Fail(error, "handoff changed during isolation; original control files preserved");
    RunContext closed = original; closed.phase = "closed";
    if (!SaveRun(status_dir, closed, error)) return false;
    const auto final = InspectHandoff(status_dir, user);
    if (final.state != HandoffState::Closed || EncodeRun(final.run) != EncodeRun(closed))
        return Fail(error, "isolated handoff close could not be confirmed");
    if (error) error->clear();
    return true;
}

}  // namespace pocket
