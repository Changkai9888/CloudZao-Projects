#pragma once
#include <cstddef>

namespace pocket_legal {
// Generated from the versioned, complete license texts. No network/TF needed.
std::size_t DocumentCount();
const char* Title(std::size_t document);
std::size_t PageCount(std::size_t document);
const char* Page(std::size_t document, std::size_t page);
}
