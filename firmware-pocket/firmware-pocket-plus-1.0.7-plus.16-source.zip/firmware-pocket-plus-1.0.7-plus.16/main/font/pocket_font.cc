#include "pocket_font.h"
#include "plus_font.h"
#include <algorithm>
#include <array>
#include <atomic>
#include <cstring>
#include <cstdlib>
#include <esp_heap_caps.h>
#include <esp_timer.h>
#include <miniz.h>

extern const uint8_t pocket_font_start[] asm("_binary_pocket_ui_fontpack_start");
extern const uint8_t pocket_font_end[] asm("_binary_pocket_ui_fontpack_end");

namespace pocket_font {
namespace {
using Glyph = plus_font::Glyph;
struct Font {
    lv_font_t lv{};
    plus_font::Font native;
    uint8_t* storage = nullptr;
    uint16_t size = 0;
    bool attempted = false;
};
std::array<Font, 4> fonts;
constexpr size_t kCacheSlots = 64;
constexpr size_t kCacheSlotBytes = 2048;
struct CacheEntry {
    uint32_t codepoint = 0;
    uint32_t used = 0;
    uint16_t size = 0, width = 0, height = 0, stride = 0;
};
// LVGL is the sole bitmap caller. Cache metadata and pixels need no cross-task
// lock; only the diagnostic counters below are read by the runtime task.
std::array<CacheEntry, kCacheSlots> cache;
uint8_t* cache_pixels = nullptr;
bool cache_attempted = false;
uint32_t cache_clock = 0;
struct AtomicStats {
    std::atomic<uint32_t> requests{0}, hits{0}, expanded{0}, uncached{0};
    std::atomic<uint32_t> allocation_failures{0}, cache_bytes{0};
    std::atomic<uint32_t> expand_us_total{0}, expand_us_max{0};
} stats;

bool CacheReady() {
    if (!cache_attempted) {
        cache_attempted = true;
        cache_pixels = static_cast<uint8_t*>(heap_caps_malloc(kCacheSlots * kCacheSlotBytes,
            MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
        if (cache_pixels) stats.cache_bytes.store(kCacheSlots * kCacheSlotBytes, std::memory_order_relaxed);
        else stats.allocation_failures.fetch_add(1, std::memory_order_relaxed);
    }
    return cache_pixels != nullptr;
}

uint32_t CacheTick() {
    if (++cache_clock == 0) {
        // Clear metadata only on counter wrap; no caller ever owns these pixel
        // pointers, so invalidating all cache entries cannot invalidate a draw.
        for (auto& entry : cache) entry.used = 0;
        ++cache_clock;
    }
    return cache_clock;
}
uint32_t U32(const uint8_t* p) {
    return uint32_t(p[0]) | uint32_t(p[1]) << 8 | uint32_t(p[2]) << 16 | uint32_t(p[3]) << 24;
}
uint16_t U16(const uint8_t* p) { return uint16_t(p[0]) | uint16_t(p[1]) << 8; }
// Font data is losslessly compressed in Flash, expanded once in PSRAM, then
// read directly for the lifetime of the UI. No decompression on key presses.
bool Load(Font* font) {
    if (font->attempted) return font->native.valid();
    font->attempted = true;
    const auto* data = pocket_font_start;
    const size_t length = pocket_font_end - pocket_font_start;
    if (length < 112 || std::memcmp(data, "PNF1", 4) || U16(data + 4) != 1 ||
        U16(data + 6) != 4 || U32(data + 8) != length || U32(data + 12)) return false;
    for (unsigned i = 0; i < 4; ++i) {
        const auto* entry = data + 16 + i * 24;
        if (U16(entry) != font->size) continue;
        const size_t offset = U32(entry + 4), packed = U32(entry + 8), raw = U32(entry + 12);
        if (U16(entry + 2) != 500 || U32(entry + 20) || offset < 112 ||
            offset > length || packed > length - offset || raw < 64 || raw > 2 * 1024 * 1024)
            return false;
        auto* target = static_cast<uint8_t*>(heap_caps_malloc(raw, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
        auto* decoder = static_cast<tinfl_decompressor*>(std::malloc(sizeof(tinfl_decompressor)));
        if (!target || !decoder) { std::free(target); std::free(decoder); return false; }
        tinfl_init(decoder);
        size_t input = packed, output = raw;
        const auto status = tinfl_decompress(decoder, data + offset, &input, target, target, &output,
            TINFL_FLAG_PARSE_ZLIB_HEADER | TINFL_FLAG_USING_NON_WRAPPING_OUTPUT_BUF);
        std::free(decoder);
        if (status != TINFL_STATUS_DONE || input != packed || output != raw ||
            !font->native.Open(target, raw) || font->native.spec().pixels != font->size ||
            font->native.spec().weight != 500 || font->native.spec().threshold != 112) {
            font->native = plus_font::Font();
            std::free(target);
            return false;
        }
        font->storage = target;
        return true;
    }
    return false;
}
bool Lookup(uint32_t cp, const Font* font, Glyph* out) {
    if (cp == '\t') cp = ' ';
    return font->native.Find(cp, out) || font->native.Find('?', out);
}
bool Descriptor(const lv_font_t* f, lv_font_glyph_dsc_t* out, uint32_t cp, uint32_t) {
    const auto* font = static_cast<const Font*>(f->dsc);
    Glyph g{};
    if (!font || !out || !Lookup(cp, font, &g)) return false;
    out->adv_w = g.advance;
    out->box_w = g.width;
    out->box_h = g.height;
    out->ofs_x = g.x_offset;
    // NTF top is relative to the baseline, down positive. LVGL ofs_y is
    // measured from the glyph's bottom to the baseline, up positive.
    out->ofs_y = -g.y_offset - g.height;
    out->stride = 0;
    out->format = LV_FONT_GLYPH_FORMAT_A8;
    out->is_placeholder = 0;
    out->gid.index = cp;
    return true;
}
void Expand(const Glyph& g, int w, int h, uint32_t stride, uint8_t* pixels) {
    const int64_t started = esp_timer_get_time();
    std::memset(pixels, 0, size_t(stride) * h);
    for (int y = 0; y < h; ++y) {
        for (int x = 0; x < w; ++x) {
            const size_t bit = size_t(y) * g.width + x;
            pixels[y * stride + x] = (g.bitmap[bit / 8] & (0x80u >> (bit & 7))) ? 255 : 0;
        }
    }
    stats.expanded.fetch_add(1, std::memory_order_relaxed);
    const uint32_t elapsed = uint32_t(std::max<int64_t>(0, esp_timer_get_time() - started));
    stats.expand_us_total.fetch_add(elapsed, std::memory_order_relaxed);
    if (elapsed > stats.expand_us_max.load(std::memory_order_relaxed))
        stats.expand_us_max.store(elapsed, std::memory_order_relaxed);
}
const void* Bitmap(lv_font_glyph_dsc_t* dsc, lv_draw_buf_t* draw) {
    if (!dsc || !dsc->resolved_font) return nullptr;
    const auto* font = static_cast<const Font*>(dsc->resolved_font->dsc);
    Glyph g{};
    if (!font || !Lookup(dsc->gid.index, font, &g) || !g.width || !g.height) return nullptr;
    const int w = dsc->box_w, h = dsc->box_h;
    if (w <= 0 || h <= 0 || w > 128 || h > 128 || w != g.width || h != g.height) return nullptr;
    const uint32_t stride = lv_draw_buf_width_to_stride(w, LV_COLOR_FORMAT_A8);
    // The LVGL task is the only consumer. This scratch area is used only for
    // explicit raw-bitmap requests; normal rendering writes its owned draw buf.
    static uint8_t raw[128 * 128];
    auto* pixels = dsc->req_raw_bitmap ? raw : draw ? draw->data : nullptr;
    if (!pixels) return nullptr;
    stats.requests.fetch_add(1, std::memory_order_relaxed);
    const size_t bytes = size_t(stride) * h;
    if (bytes <= kCacheSlotBytes && CacheReady()) {
        const uint32_t tick = CacheTick();
        CacheEntry* victim = &cache.front();
        size_t slot = 0;
        bool hit = false;
        for (size_t i = 0; i < cache.size(); ++i) {
            auto& entry = cache[i];
            if (entry.used && entry.codepoint == dsc->gid.index && entry.size == font->size &&
                entry.width == w && entry.height == h && entry.stride == stride) {
                victim = &entry; slot = i; hit = true; break;
            }
            if (entry.used < victim->used) { victim = &entry; slot = i; }
        }
        auto* expanded = cache_pixels + slot * kCacheSlotBytes;
        if (hit) stats.hits.fetch_add(1, std::memory_order_relaxed);
        else {
            Expand(g, w, h, stride, expanded);
            *victim = {dsc->gid.index, tick, font->size,
                       uint16_t(w), uint16_t(h), uint16_t(stride)};
        }
        victim->used = tick;
        // Always return LVGL's owned output (or the established raw scratch),
        // never a cache slot that a subsequent glyph request could evict.
        std::memcpy(pixels, expanded, bytes);
    } else {
        stats.uncached.fetch_add(1, std::memory_order_relaxed);
        Expand(g, w, h, stride, pixels);
    }
    if (dsc->req_raw_bitmap) return pixels;
    lv_draw_buf_flush_cache(draw, nullptr);
    return draw;
}
}
const lv_font_t* Get(uint16_t pixels) {
    if (pixels != 18 && pixels != 25 && pixels != 32 && pixels != 38) return nullptr;
    for (auto& f : fonts) if (f.size == pixels) return f.native.valid() ? &f.lv : nullptr;
    for (auto& f : fonts) if (!f.size) {
        f.size = pixels;
        if (!Load(&f)) return nullptr;
        f.lv.get_glyph_dsc = Descriptor;
        f.lv.get_glyph_bitmap = Bitmap;
        f.lv.release_glyph = nullptr;
        f.lv.dsc = &f;
        const auto metrics = f.native.metrics();
        f.lv.line_height = metrics.ascent + metrics.descent;
        f.lv.base_line = metrics.descent;
        f.lv.subpx = LV_FONT_SUBPX_NONE;
        f.lv.kerning = LV_FONT_KERNING_NONE;
        f.lv.static_bitmap = 0;
        f.lv.underline_position = -1;
        f.lv.underline_thickness = 1;
        return &f.lv;
    }
    return nullptr;
}
CacheStats GetCacheStats() {
    return {stats.requests.load(std::memory_order_relaxed), stats.hits.load(std::memory_order_relaxed),
            stats.expanded.load(std::memory_order_relaxed), stats.uncached.load(std::memory_order_relaxed),
            stats.allocation_failures.load(std::memory_order_relaxed), stats.cache_bytes.load(std::memory_order_relaxed),
            stats.expand_us_total.load(std::memory_order_relaxed), stats.expand_us_max.load(std::memory_order_relaxed)};
}
}
