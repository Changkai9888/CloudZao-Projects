#pragma once

#include <string>
#include <vector>

namespace notepad_ime {

// One complete, toneless pinyin syllable. ASCII uppercase is accepted; use v for u-umlaut.
// Unknown/incomplete syllables return an empty list. No prediction or learning.
std::vector<std::string> Candidates(const std::string& syllable);
// True only for a nonempty prefix of a supported syllable (including a whole syllable).
bool IsPrefix(const std::string& syllable);

}  // namespace notepad_ime
