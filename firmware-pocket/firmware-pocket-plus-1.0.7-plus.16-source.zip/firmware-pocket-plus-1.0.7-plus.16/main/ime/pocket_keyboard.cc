#include "pocket_keyboard.h"
#include "notepad_ime.h"
#include <esp_log.h>

#include <algorithm>
#include <array>
#include <atomic>
#include <cstring>
#include <new>
#include <string>
#include <vector>

namespace pocket_ime {
namespace {
struct Diagnostics {
    std::atomic<unsigned> matrix_pressed{0}, matrix_enabled{0}, matrix_disabled{0};
    std::atomic<unsigned> matrix_released{0}, matrix_lost{0};
    std::atomic<unsigned> key_callbacks{0}, key_disabled{0}, key_no_selection{0}, key_empty{0}, key_accepted{0};
    std::atomic<unsigned> edit_attempts{0}, edit_changed{0}, edit_unchanged{0}, edit_limit{0};
    std::atomic<unsigned> compose_changed{0}, compose_limit{0}, compose_blocked{0}, mode_changed{0};
    std::atomic<unsigned> auxiliary_pressed{0}, auxiliary_actions{0}, auxiliary_disabled{0};
};
Diagnostics s_diagnostics;
enum class Action { Clear, Mode, Prev, Next, Candidate };
struct Keyboard;
struct Hit { Keyboard* owner = nullptr; Action action{}; int index = 0; lv_obj_t* object = nullptr; };
struct Keyboard {
    lv_obj_t* root = nullptr;
    lv_obj_t* target = nullptr;
    lv_obj_t* compose = nullptr;
    lv_obj_t* mode_label = nullptr;
    lv_obj_t* matrix = nullptr;
    std::array<lv_obj_t*, 5> candidate_labels{};
    std::array<Hit, 9> hits{};
    const lv_font_t* font = nullptr;
    std::string pinyin;
    std::vector<std::string> candidates;
    size_t page = 0;
    bool chinese = false, upper = false, symbols = false;
};
static const char* const lower[] = {
    "1","2","3","4","5","6","7","8","9","0","\n",
    "q","w","e","r","t","y","u","i","o","p","\n",
    "a","s","d","f","g","h","j","k","l","\n",
    "z","x","c","v","b","n","m",".","-","/","\n",
    "符号","退格","空格","换行","大写",""};
static const char* const upper[] = {
    "1","2","3","4","5","6","7","8","9","0","\n",
    "Q","W","E","R","T","Y","U","I","O","P","\n",
    "A","S","D","F","G","H","J","K","L","\n",
    "Z","X","C","V","B","N","M",".","-","/","\n",
    "符号","退格","空格","换行","小写",""};
static const char* const symbols[] = {
    "1","2","3","4","5","6","7","8","9","0","\n",
    ":","/","?","&","=","%","#","@",".","_","\n",
    "-","+","~","!","$","*","(",")","[","]","\n",
    "{","}",";",",","\\","'","\"","<",">","|","\n",
    "字母","退格","空格","换行","大写",""};
void Plain(lv_obj_t* obj) {
    lv_obj_remove_style_all(obj);
    lv_obj_set_style_bg_color(obj, lv_color_white(), 0);
    lv_obj_set_style_bg_opa(obj, LV_OPA_COVER, 0);
    lv_obj_set_style_text_color(obj, lv_color_black(), 0);
    lv_obj_set_style_text_opa(obj, LV_OPA_COVER, 0);
    lv_obj_set_style_border_opa(obj, LV_OPA_COVER, 0);
    lv_obj_set_style_opa(obj, LV_OPA_COVER, 0);
    lv_obj_set_style_anim_duration(obj, 0, 0);
    lv_obj_remove_local_style_prop(obj, LV_STYLE_TRANSITION, 0);
    lv_obj_clear_flag(obj, LV_OBJ_FLAG_SCROLLABLE);
}
lv_obj_t* Label(lv_obj_t* parent, const lv_font_t* font, const char* text) {
    auto* label = lv_label_create(parent);
    lv_obj_remove_style_all(label);
    lv_obj_set_style_text_font(label, font, 0);
    lv_obj_set_style_text_color(label, lv_color_black(), 0);
    lv_obj_set_style_text_opa(label, LV_OPA_COVER, 0);
    lv_label_set_text(label, text);
    lv_obj_clear_flag(label, LV_OBJ_FLAG_CLICKABLE);
    return label;
}
bool Enabled(const Keyboard* k) {
    return k && k->target && !lv_obj_has_state(k->root, LV_STATE_DISABLED) &&
           !lv_obj_has_state(k->target, LV_STATE_DISABLED);
}
// The counters observe editor operations without retaining characters or the
// current length. In particular PrintDiagnostics can run on the runtime worker
// without touching LVGL objects or credential fields.
void AddText(Keyboard* k, const char* text) {
    ++s_diagnostics.edit_attempts;
    const size_t before = std::strlen(lv_textarea_get_text(k->target));
    const uint32_t maximum = lv_textarea_get_max_length(k->target);
    size_t characters = 0;
    // Textarea limits count UTF-8 characters, not bytes; retain neither count.
    for (const auto* p = reinterpret_cast<const unsigned char*>(lv_textarea_get_text(k->target)); *p; ++p)
        if ((*p & 0xC0) != 0x80) ++characters;
    const bool at_limit = maximum && characters >= maximum;
    lv_textarea_add_text(k->target, text);
    if (std::strlen(lv_textarea_get_text(k->target)) != before) ++s_diagnostics.edit_changed;
    else {
        ++s_diagnostics.edit_unchanged;
        if (at_limit) ++s_diagnostics.edit_limit;
    }
}
void DeleteCharacter(Keyboard* k) {
    ++s_diagnostics.edit_attempts;
    const size_t before = std::strlen(lv_textarea_get_text(k->target));
    lv_textarea_delete_char(k->target);
    if (std::strlen(lv_textarea_get_text(k->target)) != before) ++s_diagnostics.edit_changed;
    else ++s_diagnostics.edit_unchanged;
}
void OnMatrixEvent(lv_event_t* event) {
    auto* k = static_cast<Keyboard*>(lv_event_get_user_data(event));
    switch (lv_event_get_code(event)) {
    case LV_EVENT_PRESSED:
        ++s_diagnostics.matrix_pressed;
        if (Enabled(k)) ++s_diagnostics.matrix_enabled;
        else ++s_diagnostics.matrix_disabled;
        break;
    case LV_EVENT_RELEASED: ++s_diagnostics.matrix_released; break;
    case LV_EVENT_PRESS_LOST: ++s_diagnostics.matrix_lost; break;
    default: break;
    }
}
void Update(Keyboard* k) {
    const std::string compose = k->pinyin.empty() ? (k->chinese ? "拼音，v 代替 ü" : "英文 / 数字") :
        k->pinyin + "  " + std::to_string(k->page + 1) + "/" + std::to_string(std::max<size_t>(1, (k->candidates.size() + 4) / 5));
    lv_label_set_text(k->compose, compose.c_str());
    lv_label_set_text(k->mode_label, k->chinese ? "英数" : "拼音");
    for (size_t i = 0; i < 5; ++i) {
        const size_t index = k->page * 5 + i;
        const bool present = index < k->candidates.size();
        lv_label_set_text(k->candidate_labels[i], present ? k->candidates[index].c_str() : "");
        auto* object = k->hits[i + 4].object;
        if (present) lv_obj_remove_state(object, LV_STATE_DISABLED);
        else lv_obj_add_state(object, LV_STATE_DISABLED);
    }
    if (k->page) lv_obj_remove_state(k->hits[2].object, LV_STATE_DISABLED);
    else lv_obj_add_state(k->hits[2].object, LV_STATE_DISABLED);
    if ((k->page + 1) * 5 < k->candidates.size()) lv_obj_remove_state(k->hits[3].object, LV_STATE_DISABLED);
    else lv_obj_add_state(k->hits[3].object, LV_STATE_DISABLED);
}
void Clear(Keyboard* k) {
    if (!k->pinyin.empty()) ++s_diagnostics.compose_changed;
    k->pinyin.clear(); k->candidates.clear(); k->page = 0; Update(k);
}
void Compose(Keyboard* k) { k->candidates = notepad_ime::Candidates(k->pinyin); k->page = 0; Update(k); }
void ConfigureMatrix(Keyboard* k);
void Commit(Keyboard* k, const std::string& text) {
    if (!Enabled(k)) return;
    AddText(k, text.c_str());
    Clear(k);
}
void OnPress(lv_event_t*) {
    ++s_diagnostics.auxiliary_pressed;
}
void OnAction(lv_event_t* event) {
    ++s_diagnostics.auxiliary_actions;
    auto* hit = static_cast<Hit*>(lv_event_get_user_data(event));
    if (!hit || !Enabled(hit->owner) || lv_obj_has_state(hit->object, LV_STATE_DISABLED)) {
        ++s_diagnostics.auxiliary_disabled;
        return;
    }
    auto* k = hit->owner;
    switch (hit->action) {
    case Action::Clear: Clear(k); break;
    case Action::Mode:
        if (!k->pinyin.empty()) { ++s_diagnostics.compose_blocked; lv_label_set_text(k->compose, "先选字，或清空拼音"); return; }
        k->chinese = !k->chinese; k->symbols = k->upper = false;
        ++s_diagnostics.mode_changed;
        ConfigureMatrix(k); Update(k); break;
    case Action::Prev: if (k->page) { --k->page; Update(k); } break;
    case Action::Next: if ((k->page + 1) * 5 < k->candidates.size()) { ++k->page; Update(k); } break;
    case Action::Candidate: {
        const size_t index = k->page * 5 + hit->index;
        if (index < k->candidates.size()) Commit(k, k->candidates[index]);
        break;
    }
    }
}
void ConfigureMatrix(Keyboard* k) {
    const auto* map = k->symbols ? symbols : k->upper ? upper : lower;
    lv_buttonmatrix_set_map(k->matrix, map);
    size_t count = 0;
    for (const char* const* key = map; **key; ++key) if (std::strcmp(*key, "\n")) ++count;
    for (size_t i = 0; i < count; ++i)
        lv_buttonmatrix_set_button_ctrl(k->matrix, i, LV_BUTTONMATRIX_CTRL_NO_REPEAT);
}
void OnKey(lv_event_t* event) {
    ++s_diagnostics.key_callbacks;
    auto* k = static_cast<Keyboard*>(lv_event_get_user_data(event));
    if (!Enabled(k)) { ++s_diagnostics.key_disabled; return; }
    const auto index = lv_buttonmatrix_get_selected_button(k->matrix);
    if (index == LV_BUTTONMATRIX_BUTTON_NONE) { ++s_diagnostics.key_no_selection; return; }
    const char* key = lv_buttonmatrix_get_button_text(k->matrix, index);
    if (!key || !*key) { ++s_diagnostics.key_empty; return; }
    ++s_diagnostics.key_accepted;
    if (!std::strcmp(key, "退格")) {
        if (k->pinyin.empty()) DeleteCharacter(k);
        else { k->pinyin.pop_back(); ++s_diagnostics.compose_changed; Compose(k); }
    } else if (!std::strcmp(key, "空格")) {
        if (k->pinyin.empty()) AddText(k, " ");
        else if (k->page * 5 < k->candidates.size()) Commit(k, k->candidates[k->page * 5]);
    } else if (!std::strcmp(key, "换行")) {
        // SSID/password are single-line fields. LVGL ignores an empty-composition
        // newline there; the shared IME still commits nonempty pinyin as ASCII.
        if (!k->pinyin.empty()) Commit(k, k->pinyin);
        else AddText(k, "\n");
    } else if (!std::strcmp(key, "大写") || !std::strcmp(key, "小写")) {
        k->upper = !k->upper; ++s_diagnostics.mode_changed; ConfigureMatrix(k);
    } else if (!std::strcmp(key, "符号") || !std::strcmp(key, "字母")) {
        if (!k->pinyin.empty()) { ++s_diagnostics.compose_blocked; lv_label_set_text(k->compose, "先选字，或清空拼音"); return; }
        k->symbols = !k->symbols; ++s_diagnostics.mode_changed; ConfigureMatrix(k);
    } else if (k->chinese && !k->symbols && std::strlen(key) == 1 &&
               ((key[0] >= 'a' && key[0] <= 'z') || (key[0] >= 'A' && key[0] <= 'Z'))) {
        if (k->pinyin.size() < 6) {
            k->pinyin += char(key[0] >= 'A' && key[0] <= 'Z' ? key[0] + 32 : key[0]);
            ++s_diagnostics.compose_changed; Compose(k);
        } else ++s_diagnostics.compose_limit;
    } else if (!k->pinyin.empty()) {
        if (std::strlen(key) == 1 && key[0] >= '1' && key[0] <= '5') {
            const size_t selected = k->page * 5 + key[0] - '1';
            if (selected < k->candidates.size()) Commit(k, k->candidates[selected]);
        } else { ++s_diagnostics.compose_blocked; lv_label_set_text(k->compose, "请先选字，再输入符号"); }
    } else AddText(k, key);
}
lv_obj_t* Button(Keyboard* k, int slot, int x, int y, int w, int h,
                 const char* text, Action action, int index = 0) {
    auto* button = lv_button_create(k->root); Plain(button);
    lv_obj_set_pos(button, x, y); lv_obj_set_size(button, w, h);
    lv_obj_set_style_border_width(button, 2, 0);
    lv_obj_set_style_border_color(button, lv_color_black(), 0);
    lv_obj_set_style_bg_color(button, lv_color_white(), LV_STATE_PRESSED);
    lv_obj_set_style_text_color(button, lv_color_black(), LV_STATE_PRESSED);
    lv_obj_remove_local_style_prop(button, LV_STYLE_TRANSITION, LV_STATE_PRESSED);
    auto* label = Label(button, k->font, text); lv_obj_center(label);
    k->hits[slot] = {k, action, index, button};
    lv_obj_add_event_cb(button, OnPress, LV_EVENT_PRESSED, &k->hits[slot]);
    lv_obj_add_event_cb(button, OnAction, LV_EVENT_CLICKED, &k->hits[slot]);
    if (action == Action::Mode) k->mode_label = label;
    return label;
}
void Deleted(lv_event_t* event) {
    auto* k = static_cast<Keyboard*>(lv_event_get_user_data(event));
    if (k && lv_event_get_target(event) == k->root) delete k;
}
}
lv_obj_t* Create(lv_obj_t* parent, int x, int y, int width, int height, const lv_font_t* font) {
    auto* k = new (std::nothrow) Keyboard;
    if (!k) return nullptr;
    k->root = lv_obj_create(parent); Plain(k->root);
    lv_obj_set_pos(k->root, x, y); lv_obj_set_size(k->root, width, height);
    lv_obj_set_user_data(k->root, k); k->font = font;
    lv_obj_add_event_cb(k->root, Deleted, LV_EVENT_DELETE, k);
    k->compose = Label(k->root, font, "英文 / 数字");
    lv_obj_set_pos(k->compose, 2, 5); lv_obj_set_width(k->compose, width - 230);
    lv_label_set_long_mode(k->compose, LV_LABEL_LONG_DOT);
    Button(k, 0, width - 218, 0, 104, 48, "清空", Action::Clear);
    Button(k, 1, width - 106, 0, 106, 48, "拼音", Action::Mode);
    const int row_y = 54, row_h = 52, edge = 48, gap = 5;
    const int cell = (width - edge * 2 - gap * 6) / 5;
    Button(k, 2, 0, row_y, edge, row_h, "<", Action::Prev);
    Button(k, 3, width - edge, row_y, edge, row_h, ">", Action::Next);
    for (int i = 0; i < 5; ++i)
        k->candidate_labels[i] = Button(k, i + 4, edge + gap + i * (cell + gap), row_y,
                                        cell, row_h, "", Action::Candidate, i);
    k->matrix = lv_buttonmatrix_create(k->root); Plain(k->matrix);
    // Give all five rows a comfortable key height and retain four physical
    // pixels below the matrix so its bottom border is never parent-clipped.
    lv_obj_set_pos(k->matrix, 0, 116); lv_obj_set_size(k->matrix, width, height - 120);
    lv_obj_set_style_pad_all(k->matrix, 4, 0);
    lv_obj_set_style_pad_row(k->matrix, 6, 0); lv_obj_set_style_pad_column(k->matrix, 4, 0);
    lv_obj_set_style_text_font(k->matrix, font, LV_PART_ITEMS);
    lv_obj_set_style_text_color(k->matrix, lv_color_black(), LV_PART_ITEMS);
    lv_obj_set_style_text_opa(k->matrix, LV_OPA_COVER, LV_PART_ITEMS);
    lv_obj_set_style_bg_color(k->matrix, lv_color_white(), LV_PART_ITEMS);
    lv_obj_set_style_bg_opa(k->matrix, LV_OPA_COVER, LV_PART_ITEMS);
    lv_obj_set_style_border_width(k->matrix, 2, LV_PART_ITEMS);
    lv_obj_set_style_border_color(k->matrix, lv_color_black(), LV_PART_ITEMS);
    lv_obj_set_style_border_opa(k->matrix, LV_OPA_COVER, LV_PART_ITEMS);
    lv_obj_set_style_bg_color(k->matrix, lv_color_white(), lv_style_selector_t(LV_PART_ITEMS) | LV_STATE_PRESSED);
    lv_obj_set_style_text_color(k->matrix, lv_color_black(), lv_style_selector_t(LV_PART_ITEMS) | LV_STATE_PRESSED);
    lv_obj_remove_local_style_prop(k->matrix, LV_STYLE_TRANSITION, LV_PART_ITEMS);
    lv_obj_remove_local_style_prop(k->matrix, LV_STYLE_TRANSITION, lv_style_selector_t(LV_PART_ITEMS) | LV_STATE_PRESSED);
    lv_obj_set_style_anim_duration(k->matrix, 0, LV_PART_ITEMS);
    ConfigureMatrix(k);
    lv_obj_add_event_cb(k->matrix, OnMatrixEvent, LV_EVENT_PRESSED, k);
    lv_obj_add_event_cb(k->matrix, OnMatrixEvent, LV_EVENT_RELEASED, k);
    lv_obj_add_event_cb(k->matrix, OnMatrixEvent, LV_EVENT_PRESS_LOST, k);
    lv_obj_add_event_cb(k->matrix, OnKey, LV_EVENT_VALUE_CHANGED, k);
    Update(k); return k->root;
}
void SetTarget(lv_obj_t* keyboard, lv_obj_t* textarea, bool chinese) {
    if (!keyboard) return;
    auto* k = static_cast<Keyboard*>(lv_obj_get_user_data(keyboard));
    if (!k) return;
    if (k->target != textarea) {
        k->target = textarea; k->chinese = chinese; k->upper = k->symbols = false;
        Clear(k); ConfigureMatrix(k);
    }
}
lv_obj_t* Target(lv_obj_t* keyboard) {
    auto* k = keyboard ? static_cast<Keyboard*>(lv_obj_get_user_data(keyboard)) : nullptr;
    return k ? k->target : nullptr;
}
void PrintDiagnostics() {
    ESP_LOGI("pocket_ime", "IME_MATRIX pressed=%u enabled=%u disabled=%u released=%u lost=%u callbacks=%u key_disabled=%u no_selection=%u empty=%u accepted=%u",
        s_diagnostics.matrix_pressed.load(), s_diagnostics.matrix_enabled.load(), s_diagnostics.matrix_disabled.load(),
        s_diagnostics.matrix_released.load(), s_diagnostics.matrix_lost.load(), s_diagnostics.key_callbacks.load(),
        s_diagnostics.key_disabled.load(), s_diagnostics.key_no_selection.load(), s_diagnostics.key_empty.load(),
        s_diagnostics.key_accepted.load());
    ESP_LOGI("pocket_ime", "IME_EDIT attempts=%u changed=%u unchanged=%u at_limit=%u compose_changed=%u compose_limit=%u compose_blocked=%u mode_changed=%u auxiliary_pressed=%u auxiliary_actions=%u auxiliary_disabled=%u",
        s_diagnostics.edit_attempts.load(), s_diagnostics.edit_changed.load(), s_diagnostics.edit_unchanged.load(),
        s_diagnostics.edit_limit.load(), s_diagnostics.compose_changed.load(), s_diagnostics.compose_limit.load(),
        s_diagnostics.compose_blocked.load(), s_diagnostics.mode_changed.load(), s_diagnostics.auxiliary_pressed.load(),
        s_diagnostics.auxiliary_actions.load(), s_diagnostics.auxiliary_disabled.load());
}
}
