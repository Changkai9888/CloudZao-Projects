#include "notepad_ime.h"

#include <algorithm>
#include <cstring>
#include <iterator>

#include "notepad_pinyin_data.h"

namespace notepad_ime {
namespace {
std::string Normalize(const std::string& text) {
    if (text.empty() || text.size() > 6) return {};
    std::string result;
    result.reserve(text.size());
    for (char c : text) {
        if (c >= 'A' && c <= 'Z') c = static_cast<char>(c - 'A' + 'a');
        if (c < 'a' || c > 'z') return {};
        result.push_back(c);
    }
    return result;
}

const data::Entry* Find(const std::string& text) {
    return std::lower_bound(std::begin(data::kEntries), std::end(data::kEntries), text,
        [](const data::Entry& entry, const std::string& key) {
            return std::strcmp(entry.syllable, key.c_str()) < 0;
        });
}
}  // namespace

std::vector<std::string> Candidates(const std::string& syllable) {
    const std::string key = Normalize(syllable);
    if (key.empty()) return {};
    const auto* entry = Find(key);
    if (entry == std::end(data::kEntries) || key != entry->syllable) return {};
    // The generator validates every glyph is U+4E00..U+9FFF: exactly 3 UTF-8 bytes.
    const std::size_t size = std::strlen(entry->characters);
    std::vector<std::string> result;
    result.reserve(size / 3);
    for (std::size_t offset = 0; offset < size; offset += 3)
        result.emplace_back(entry->characters + offset, 3);
    return result;
}

bool IsPrefix(const std::string& syllable) {
    const std::string key = Normalize(syllable);
    if (key.empty()) return false;
    const auto* entry = Find(key);
    return entry != std::end(data::kEntries) &&
        std::strncmp(entry->syllable, key.c_str(), key.size()) == 0;
}
}  // namespace notepad_ime
