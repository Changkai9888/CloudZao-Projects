#pragma once
#include "lvgl.h"

namespace pocket_ime {
// Pixel coordinates. Parent owns this keyboard; delete parent under LVGL lock.
lv_obj_t* Create(lv_obj_t* parent, int x, int y, int width, int height,
                 const lv_font_t* font);
// A target change clears only uncommitted pinyin, never field contents.
void SetTarget(lv_obj_t* keyboard, lv_obj_t* textarea, bool chinese = false);
lv_obj_t* Target(lv_obj_t* keyboard);
// Thread-safe cumulative counters only; never reads or prints input contents.
// Compare two snapshots around a test round rather than resetting live counts.
void PrintDiagnostics();
}
