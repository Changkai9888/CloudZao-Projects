#include "hal/pocket_hal.h"
#include "hal/idle_sleep.h"
#include "pocket/pocket_runtime.h"
#include "ui/pocket_screen.h"
#include <esp_app_desc.h>
#include <esp_log.h>
#include <esp_timer.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <lvgl.h>
#include <nvs_flash.h>
#include <algorithm>
#include <string>

extern "C" void app_main() {
    // A short hardware wake must not start UI, networking or frontlight.
    pocket_hal::EarlyWakeGate();
    ESP_LOGI("PocketPlus", "BOOT version=%s target=esp32s31", esp_app_get_description()->version);
    const esp_err_t nvs = nvs_flash_init();
    if (nvs != ESP_OK) {
        // Never erase existing user data as an initialization fallback.
        ESP_LOGE("PocketPlus", "NVS initialization failed: %s", esp_err_to_name(nvs));
        return;
    }
    lv_init();
    std::string error;
    if (!pocket_hal::Init(&error)) {
        ESP_LOGE("PocketPlus", "Board initialization failed: %s", error.c_str());
        return;
    }
    pocket::Start();
    lv_obj_t* screen = pocket::CreateScreen();
    if (!screen) {
        ESP_LOGE("PocketPlus", "UI allocation failed");
        return;
    }
    lv_screen_load(screen);
    pocket_hal::RequestFullRefresh();
    uint32_t standby_revision = pocket_hal::StandbyRevision();
    bool pending_power_off = false;
    bool was_standby = false;
    uint32_t last_policy_update = 0;
    bool policy_initialized = false;
    plus_hal_detail::IdleSleepPolicy idle_sleep;
    for (;;) {
        if (pocket_hal::PollPowerOff()) pending_power_off = true;
        if (pending_power_off && pocket::Post(pocket::Command::PowerOff))
            pending_power_off = false;
        const uint32_t now = lv_tick_get();
        if (!policy_initialized || now - last_policy_update >= 50U) {
            // Snapshot owns strings and up to 128 package records. Do not copy
            // it on every input tick merely to refresh the standby policy.
            const auto view = pocket::Snapshot();
            pocket_hal::SetStandbyAllowed(view.ready && !view.busy && !view.switching);
            // The manager alone owns this policy. Short lock intentionally is
            // not an exclusion. Never interrupt host-owned TF or queued work.
            const bool idle_safe = view.manager && view.ready && view.pin_ready &&
                view.storage_ok && !view.busy && !view.switching && !pending_power_off &&
                !pocket_hal::UsbActive() && !pocket_hal::UsbBusy() &&
                !pocket_hal::UsbExported() && pocket_hal::IdleSleepDue();
            const uint64_t monotonic_ms = uint64_t(esp_timer_get_time() / 1000);
            if (idle_sleep.ShouldRequest(monotonic_ms, pocket_hal::LastUserActivityMs(), idle_safe) &&
                pocket::Post(pocket::Command::PowerOff, 1)) {
                idle_sleep.Requested(monotonic_ms);
                ESP_LOGI("PocketPlus", "AUTO_DEEP_SLEEP idle_ms=600000");
            }
            last_policy_update = now;
            policy_initialized = true;
        }
        const uint32_t revision = pocket_hal::StandbyRevision();
        if (revision != standby_revision) {
            // Forget a pre-standby LVGL press: wake must never complete a click.
            lv_indev_reset(nullptr, nullptr);
            standby_revision = revision;
        }
        if (pocket_hal::IsStandby()) {
            was_standby = true;
            vTaskDelay(pdMS_TO_TICKS(20));
            continue;
        }
        if (was_standby) {
            // An LVGL stripe render interrupted by lock admission may have
            // completed logically without being sent. Reconcile the full UI.
            lv_obj_invalidate(lv_screen_active());
            was_standby = false;
        }
        if (const char* key = pocket_hal::PollHardwareKey()) {
            const std::string route = std::string("vk_") + key;
            pocket::HardwareKey(route.c_str());
        }
        // Keep LVGL input/business timers running while the physical panel is
        // occupied. The display timer alone waits, then renders the latest UI.
        pocket_hal::ServiceRendering();
        const int64_t ui_started_us = esp_timer_get_time();
        const auto wait = lv_timer_handler();
        pocket_hal::RecordUiCycle(uint32_t(esp_timer_get_time() - ui_started_us));
        // Keep indev consumption timely while yielding at least one RTOS tick
        // so the independent motor and display tasks can make progress.
        const uint32_t delay_ms = std::min<uint32_t>(wait, 5U);
        vTaskDelay(std::max<TickType_t>(1, pdMS_TO_TICKS(delay_ms)));
    }
}
