#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
: "${IDF_PATH:?Source the ESP-IDF export.sh for the pinned SDK first}"
expected=fff9895c82d744c7237be8847347bdd1b07c6643
actual="$(git -C "$IDF_PATH" rev-parse HEAD)"
if [[ "$actual" != "$expected" ]]; then
  echo "SDK revision differs from the released build: $actual (expected $expected)" >&2
  echo "Porting to another SDK is possible; this script records the original build." >&2
  exit 2
fi
cd "$root"
export IDF_TARGET=esp32s31
export IDF_COMPONENT_CHECK_NEW_VERSION=0
export CMAKE_BUILD_PARALLEL_LEVEL=1
python scripts/generate_pinyin.py --check
python scripts/generate_legal.py
idf.py --preview -DPOCKET_INTERNAL_DIAGNOSTICS=OFF reconfigure
cmake --build build -- -j 1 -k 0
python scripts/package.py
