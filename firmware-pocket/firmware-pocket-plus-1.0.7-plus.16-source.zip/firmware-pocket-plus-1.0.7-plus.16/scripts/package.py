"""Merge a rebuild at address zero, without an artificial 16-MiB padding tail."""
from pathlib import Path
import hashlib
import json
import struct

ROOT = Path(__file__).resolve().parents[1]


def main():
    build = ROOT / 'build'
    app = (build / 'pocket_manager.bin').read_bytes()
    assert app[0] == 0xe9 and struct.unpack_from('<H', app, 12)[0] == 32
    assert app[288:304] == b'FPOCKET-ABI-0001'
    assert struct.unpack_from('<HHII', app, 304) == (1, 0, 512, 1)
    assert app[324:356].split(b'\0')[0] == b'metalio-eink4-plus'
    assert app[356:388].split(b'\0')[0] == b'metalio16m-plus-pocket2'
    assert len(app) <= 0x2f0000, 'Manager must fit without shrinking the application slot'
    version = app[48:80].split(b'\0')[0].decode()
    table = (build / 'partition_table/partition-table.bin').read_bytes()
    entries = []
    for at in range(0, len(table), 32):
        if table[at:at+2] != b'\xaa\x50': break
        _, kind, sub, offset, size, label, _ = struct.unpack_from('<HBBII16sI', table, at)
        entries.append((kind, sub, offset, size, label.split(b'\0')[0]))
    assert (0, 0x10, 0x10000, 0x2f0000, b'ota_0') in entries
    assert (0, 0x11, 0x300000, 0xd00000, b'ota_1') in entries
    image = bytearray(b'\xff' * (0x10000 + len(app)))
    parts = [(0x2000, 'bootloader/bootloader.bin', 0x6000),
             (0x8000, 'partition_table/partition-table.bin', 0x1000),
             (0xd000, 'ota_data_initial.bin', 0x2000),
             (0x10000, 'pocket_manager.bin', 0x2f0000)]
    for address, name, limit in parts:
        data = (build / name).read_bytes()
        assert len(data) <= limit, name
        image[address:address+len(data)] = data
    out = ROOT / 'dist'
    out.mkdir(exist_ok=True)
    dest = out / ('firmware-pocket-plus-' + version + '-empty.bin')
    dest.write_bytes(image)
    sha = hashlib.sha256(image).hexdigest()
    (out / 'SHA256.txt').write_text(sha + '  ' + dest.name + '\n', encoding='utf-8')
    print(json.dumps(dict(bin=dest.name, bytes=len(image), sha256=sha,
                          application_capacity=0xd00000)))


if __name__ == '__main__':
    main()
