#!/usr/bin/env python3
"""Build a deduplicated, full-text offline notice list. No firmware edits."""
import hashlib
import json
from pathlib import Path
import zlib

ROOT = Path(__file__).resolve().parents[1]
L = ROOT / 'licenses'

def save(name, text):
    (L / name).write_text(text.rstrip() + '\n', encoding='utf-8', newline='\n')

def main():
    ofl = (L/'NotoSansSC-OFL.txt').read_text(encoding='utf-8')
    ofl = ofl[ofl.index('SIL OPEN FONT LICENSE Version 1.1'):]
    save('OFL-1.1.txt', ofl)
    save('Font-Copyrights.txt', '''Embedded font copyright notices (all governed by SIL OFL 1.1 below)

Plus Mono Sans / Pocket Native derived from Noto Sans SC:
Copyright 2014-2021 Adobe (http://www.adobe.com/), with Reserved Font Name 'Source'

Plus Mono Sans / Pocket Native Latin/Greek/Cyrillic fallback derived from Noto Sans:
Copyright 2022 The Noto Project Authors (https://github.com/notofonts/latin-greek-cyrillic)

LVGL built-in Montserrat font:
Copyright 2011 The Montserrat Project Authors (https://github.com/JulietaUla/Montserrat)

LVGL built-in Font Awesome 5 font glyphs:
Copyright (c) 2022 Fonticons, Inc. (https://fontawesome.com)
with Reserved Font Name: "Font Awesome".

This Font Software is licensed under the SIL Open Font License, Version 1.1.
The complete license is included in the following SIL OFL section.
Original upstream notices are retained as NotoSansSC-OFL.txt, NotoSans-OFL.txt,
Montserrat-OFL.txt and FontAwesome5-LICENSE.txt. The latter's SVG/JS/code sections
refer to other formats, not the embedded font glyphs used here.
''')
    save('Runtime-Attributions.txt', '''Runtime and source attributions

ESP-IDF / ESP Wi-Fi / ESP PHY / ESP coexistence / esp_tinyusb:
Espressif Systems and respective file authors; Apache License 2.0.
ESP-IDF commit fff9895c82d744c7237be8847347bdd1b07c6643.
The unmodified complete Apache text below also applies to the Rime dictionary.

EPDiy display engine: https://github.com/vroland/epdiy
LGPL version 3; complete LGPL and referenced GPL texts follow.
Derived via CloudZao/Metalio-E-INK4-Plus commit
ad8edf4150a688737c0d7c00cae4413079b262ef; earliest EPDiy import commit unknown.
Corresponding source and relinking materials must accompany the matching release.

Gray waveforms and referenced LCD timing:
Copyright 2026 mindreset
Apache License 2.0; historical source wegooo-cell/read-pico-reader
commit a0573252388609f65e6aba0a7f78ab579fd1f4fd.

ESP-ROM miniz interface used for lossless offline-license and native-font decoding:
SPDX-FileCopyrightText: 2021-2022 Espressif Systems (Shanghai) CO LTD
SPDX-License-Identifier: Apache-2.0
Source: ESP-IDF components/esp_rom/include/miniz.h at the SDK commit above.
Calls the chip ROM tinfl implementation; no removed EPDiy font decoder is used.

Mbed TLS / TF-PSA-Crypto: https://github.com/Mbed-TLS/mbedtls
The upstream dual license is Apache-2.0 OR GPL-2.0-or-later.
This distribution selects Apache-2.0. Original dual-license files are retained
in the source distribution. See the complete Apache License below.

picolibc: https://github.com/picolibc/picolibc
Complete toolchain-provided per-file copyright/license inventories follow.
The inventory includes source, build, test and documentation files; inclusion
of an entry does not assert that an optional file is linked into this firmware.
CONFIG_LIBC_PICOLIBC is enabled. COPYING.NEWLIB is supplied inside picolibc;
it does not mean that a separate newlib runtime was added.

libgcc runtime: GNU General Public License version 3 with GCC Runtime Library
Exception 3.1. Both complete texts are included below. Compiler host binaries
are not distributed inside this firmware.

Exact license-file hashes and runtime versions: sources/runtime-license-snapshot.json
Actual managed dependency versions: sources/runtime-dependencies.lock
''')
    # Exact common Apache text from the pinned Rime/SDK sources, one offline copy.
    (L/'Apache-2.0.txt').write_bytes((L/'Rime-pinyin-simp-Apache-2.0.txt').read_bytes())
    pairs = [
      ('Runtime attributions','Runtime-Attributions.txt'),
      ('CloudZao MIT','CloudZao-MIT.txt'),
      ('Plus Noto Font component MIT','Plus-Noto-Font-MIT.txt'),
      ('Font copyright notices','Font-Copyrights.txt'),
      ('SIL Open Font License 1.1','OFL-1.1.txt'),
      ('Rime pinyin authors','Rime-pinyin-simp-AUTHORS.txt'),
      ('Apache License 2.0','Apache-2.0.txt'),
      ('pypinyin MIT','pypinyin-MIT.txt'),
      ('pinyin-data MIT','pinyin-data-MIT.txt'),
      ('Unicode License V3','Unicode.txt'),
      ('LVGL MIT','LVGL-MIT.txt'),
      ('TinyUSB MIT','TinyUSB-MIT.txt'),
      ('cJSON MIT (including Espressif package)','cJSON-MIT.txt'),
      ('FreeRTOS MIT','FreeRTOS-MIT.txt'),
      ('lwIP BSD','lwIP-BSD.txt'),
      ('FatFs R0.16','FatFs-R0.16.txt'),
      ('GNU Lesser General Public License 3','LGPL-3.0.txt'),
      ('GNU General Public License 3','GPL-3.0.txt'),
      ('GCC Runtime Library Exception 3.1','GCC-Runtime-Exception-3.1.txt'),
      ('picolibc per-file copyrights and licenses','picolibc-COPYING.picolibc.txt'),
      ('picolibc historical Newlib notices','picolibc-COPYING.NEWLIB.txt'),
      ('picolibc GPL2 referenced text','picolibc-COPYING.GPL2.txt'),
    ]
    docs=[]
    for title, name in pairs:
        data=(L/name).read_bytes()
        data.decode('utf-8')
        docs.append(dict(title=title,file='licenses/'+name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
    # cJSON wrapper and core licenses must truly match before deduplicating.
    assert (L/'cJSON-MIT.txt').read_bytes() == (L/'esp-cJSON-MIT.txt').read_bytes()
    aliases={}
    for name in ['ESP-IDF-Apache-2.0.txt','ESP-WiFi-LICENSE.txt','ESP-PHY-LICENSE.txt','ESP-Coex-LICENSE.txt','esp_tinyusb-Apache-2.0.txt','Rime-pinyin-simp-Apache-2.0.txt']:
        assert (L/name).read_bytes() == (L/'Apache-2.0.txt').read_bytes(), name
        aliases['licenses/'+name]='licenses/Apache-2.0.txt'
    aliases['licenses/esp-cJSON-MIT.txt']='licenses/cJSON-MIT.txt'
    all_data=b'\n'.join((ROOT/x['file']).read_bytes() for x in docs)
    report=dict(schema=1,description='Complete offline texts, deduplicated common licenses; raw upstream files retained.',
                offline_documents=docs,exact_duplicate_aliases=aliases,
                explicit_license_choices={'Mbed TLS / TF-PSA-Crypto':'Apache-2.0 branch; originals retain both choices',
                                         'Font Awesome':'font glyphs under OFL-1.1; other formats not embedded'},
                total_offline_utf8_bytes=len(all_data),
                approximate_zlib_independent_2400_byte_pages=sum(len(zlib.compress(all_data[i:i+2400],9)) for i in range(0,len(all_data),2400)))
    (ROOT/'licenses-list.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps({'documents':len(docs),'raw_bytes':len(all_data),'compressed_pages':report['approximate_zlib_independent_2400_byte_pages']}))

if __name__=='__main__': main()
