#!/usr/bin/env python3
"""Snapshot notices from the already-installed, pinned build inputs; no downloads.

Run inside WSL. Files in licenses/ remain verbatim. This is a source-license
inventory, not a declaration that every optional toolchain file is linked.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--idf', type=Path, required=True)
    p.add_argument('--components', type=Path, required=True)
    p.add_argument('--toolchain', type=Path, required=True)
    args = p.parse_args()
    root = Path(__file__).resolve().parents[1]
    out = root / 'licenses'
    out.mkdir(exist_ok=True)
    records = []
    def copy(base, relative, output, component, license_id, extract=None):
        src = base / relative
        raw = src.read_bytes()
        data = extract(raw) if extract else raw
        (out / output).write_bytes(data)
        records.append(dict(component=component, source_file=relative,
                            file='licenses/' + output, license=license_id,
                            bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
                            source_sha256=hashlib.sha256(raw).hexdigest(),
                            extraction='leading source copyright comment' if extract else 'verbatim'))
    def header(raw):
        end = raw.index(b'*/') + 2
        return raw[:end] + b'\n'
    sdk_files = [
      ('LICENSE', 'ESP-IDF-Apache-2.0.txt', 'ESP-IDF', 'Apache-2.0'),
      ('components/esp_wifi/lib/LICENSE','ESP-WiFi-LICENSE.txt','ESP Wi-Fi','Apache-2.0'),
      ('components/esp_phy/lib/LICENSE','ESP-PHY-LICENSE.txt','ESP PHY','Apache-2.0'),
      ('components/esp_coex/lib/LICENSE','ESP-Coex-LICENSE.txt','ESP coexistence','Apache-2.0'),
      ('components/freertos/FreeRTOS-Kernel/LICENSE.md','FreeRTOS-MIT.txt','FreeRTOS','MIT'),
      ('components/lwip/lwip/COPYING','lwIP-BSD.txt','lwIP','BSD-3-Clause'),
      ('components/mbedtls/mbedtls/LICENSE','MbedTLS-LICENSE.txt','Mbed TLS','Apache-2.0 OR GPL-2.0-or-later'),
      ('components/mbedtls/mbedtls/tf-psa-crypto/LICENSE','TF-PSA-Crypto-LICENSE.txt','TF-PSA-Crypto','Apache-2.0 OR GPL-2.0-or-later'),
    ]
    for row in sdk_files: copy(args.idf, *row)
    copy(args.idf,'components/fatfs/src/ff.c','FatFs-R0.16.txt','FatFs R0.16','FatFs permissive',header)
    component_files = [
      ('espressif__tinyusb/LICENSE','TinyUSB-MIT.txt','TinyUSB 0.21.0~2','MIT'),
      ('espressif__esp_tinyusb/LICENSE','esp_tinyusb-Apache-2.0.txt','esp_tinyusb 2.4.0','Apache-2.0'),
      ('espressif__cjson/LICENSE','esp-cJSON-MIT.txt','cJSON wrapper 1.7.19~2','MIT'),
      ('espressif__cjson/cJSON/LICENSE','cJSON-MIT.txt','cJSON 1.7.19','MIT'),
      ('lvgl__lvgl/LICENCE.txt','LVGL-MIT.txt','LVGL 9.4.0','MIT'),
      ('lvgl__lvgl/scripts/built_in_font/font_license/Montserrat/OFL.txt','Montserrat-OFL.txt','LVGL Montserrat Medium','OFL-1.1'),
      ('lvgl__lvgl/scripts/built_in_font/font_license/FontAwesome5/LICENSE.txt','FontAwesome5-LICENSE.txt','LVGL FontAwesome5 font glyphs','OFL-1.1 (font portion)'),
    ]
    for row in component_files: copy(args.components, *row)
    for name in ('COPYING.picolibc','COPYING.NEWLIB','COPYING.GPL2'):
        copy(args.toolchain, 'share/licenses/picolibc/'+name, 'picolibc-'+name+'.txt',
             'picolibc toolchain copyright inventory', 'per-file; see complete inventory')
    copy(args.toolchain,'share/licenses/gcc/COPYING.RUNTIME','GCC-Runtime-Exception-3.1.txt',
         'libgcc runtime','GPL-3.0-with-GCC-exception')
    submodules = {}
    for sub in ('components/lwip/lwip','components/mbedtls/mbedtls','components/mbedtls/mbedtls/tf-psa-crypto'):
        r = subprocess.run(['git','-C',str(args.idf/sub),'rev-parse','HEAD'], capture_output=True,text=True)
        submodules[sub] = r.stdout.strip() if r.returncode == 0 else None
    report = dict(schema=1, sdk_commit='fff9895c82d744c7237be8847347bdd1b07c6643',
                  toolchain=args.toolchain.parent.name, submodule_commits=submodules, licenses=records)
    (root/'sources'/'runtime-license-snapshot.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    lock = args.components.parent / 'dependencies.lock'
    (root/'sources'/'runtime-dependencies.lock').write_bytes(lock.read_bytes())
    print(json.dumps({'files':len(records),'bytes':sum(x['bytes'] for x in records),'submodules':submodules}))

if __name__ == '__main__': main()
