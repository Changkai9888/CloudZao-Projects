# 第三方代码、字体与数据许可

本说明对应固件口袋 Plus 的本次源码与资源。项目自行编写部分的 MIT 许可，不替代以下第三方许可。完整原文位于 `licenses/`；`licenses-list.json` 指定设备离线查看的正文和各文件 SHA-256。设备可将相同正文只存一份，但必须保留各来源的版权和适用关系。

## 设备参考、显示引擎和波形

- 设备参考：CloudZao/Metalio-E-INK4-Plus，提交 `ad8edf4150a688737c0d7c00cae4413079b262ef`。MIT 原文及 2025 Shenzhen Xinzhi Future Technology Co., Ltd. / Project Contributors 版权见 `licenses/CloudZao-MIT.txt`。
- EPDiy 显示引擎源自 https://github.com/vroland/epdiy，经设备参考工程适配。无法仅从当前副本确定最初导入的 EPDiy 提交，不作虚假的固定版本声明。上游 LGPL-3.0 继续适用，见 `licenses/LGPL-3.0.txt` 和其引用的 `GPL-3.0.txt`。设备工程的 MIT 根许可不能重新许可 LGPL 库。
- 发行静态链接 BIN 时，应同步提供对应版本的库源码、应用源码、修改、构建/重链接材料及适用的安装信息，允许对库修改进行调试；源码链接须指向该 BIN 对应版本，不能只放 MIT 文本。材料的实际上传/发布由交付流程核对。
- 灰阶波形与部分 LCD 时序参考：`wegooo-cell/read-pico-reader`，历史 Apache-2.0 提交 `a0573252388609f65e6aba0a7f78ab579fd1f4fd`。已有文件版权为 `Copyright 2026 mindreset`；原 `components/epdiy/waveforms/LICENSE.gray8` 保留，完整条款见 `licenses/Apache-2.0.txt`。其他后续版本的条款不能替代此历史来源的授权。
- 未使用的旧 Rosetta 字体解码模块不作为本版发布内容；本说明不将其误列为本版运行依赖。

## 字体

- `main/assets/pocket_ui.fontpack` 为 **Plus Mono Sans / Pocket Native**：Noto Sans SC 与少量 Noto Sans 回退的 OFL-1.1 位图衍生字体。18/25/32/38px分别原生生成，字重500、覆盖阈值112、纯黑白；保留自身字形度量和统一基线，不缩放进旧字框。25/32px保留旧6008可见字符，tab由运行时映射空格。具体参数/来源/SHA见资源旁 `.provenance.json`。
- `components/plus_font/` 与 `scripts/font_support/` 复用 Plus Noto Font 组件，原创代码MIT，版权及完整原文见 `licenses/Plus-Noto-Font-MIT.txt`。本许可不覆盖本项目的其他第三方代码及字库。
- Noto Sans SC：Google Fonts 提交 `2894aab31764f10f29c421bdfd2340d3b382d384`；版权 `Copyright 2014-2021 Adobe`，保留字体名 `Source`。Noto Sans：提交 `8b0a1d0f5983c89bc2b93f1b5fb55f9e252744b5`；版权 `Copyright 2022 The Noto Project Authors`。完整原文分别见 `NotoSansSC-OFL.txt`、`NotoSans-OFL.txt`。
- LVGL 9.4.0 自带的 `lv_font_montserrat_14.c` 来自 Montserrat-Medium.ttf 和 FontAwesome5-Solid+Brands+Regular.woff。Montserrat 版权 `Copyright 2011 The Montserrat Project Authors`；Font Awesome 字体版权 `Copyright (c) 2022 Fonticons, Inc.`，保留字体名 `Font Awesome`。字体均按 OFL-1.1 使用，原文见 `Montserrat-OFL.txt`、`FontAwesome5-LICENSE.txt`。
- Font Awesome 原许可文件还描述 SVG/JS 图标和代码的其他许可。本工程使用的是字体字形，不据此声明使用未引入的 SVG/JS 资源。离线界面合并显示字体版权及完整 OFL 正文。

## 拼音输入数据

- 仅含 4262 个单字、402 个拼音键和 4415 个字音对应；没有 Rime 运行时、词组预测或联网输入。
- 候选权重来源 `rime/rime-pinyin-simp`，固定提交 `0c6861ef7420ee780270ca6d993d18d4101049d0`，Apache-2.0。只提取原词典的单字权重，并按权重降序排列，等权按 Unicode 排序；不延续 Jun Da 候选排序。原词典和 AUTHORS 保留于 `sources/rime-pinyin-simp/`，完整许可见 `Rime-pinyin-simp-Apache-2.0.txt` 与 `Rime-pinyin-simp-AUTHORS.txt`。
- 为兼容已有输入行为，保留原单字读音成员关系；其来自 pypinyin 0.55.0 / pinyin-data（MIT）及原工程显式读音调整。新的 `sources/pinyin_readings.json` 使用 Unicode 顺序，不存旧频率排序。pypinyin、pinyin-data 版权和许可、相关 Unicode 数据许可分别在 `pypinyin-MIT.txt`、`pinyin-data-MIT.txt`、`Unicode.txt`。
- 12 个字音在 Rime 中无精确单字权重，以同一 Rime 词典中该字其他读音的最大权重排序；完整明细在 `sources/pinyin-generation.json`。这不是所有稀有读音均已经语言学审定的声明。生成脚本拒绝未匹配固定 SHA 的输入，见 `scripts/generate_pinyin.py`。
- 原完整词典作为可再现构建输入保存在源码，不编译进固件。

## SDK 和实际组件

SDK 固定为 ESP-IDF `fff9895c82d744c7237be8847347bdd1b07c6643`（6.1 开发分支，ESP32-S31）。实际组件锁定副本见 `sources/runtime-dependencies.lock`。许可取自现有 SDK/组件缓存，没有为收集许可另装工具链。

| 内容 | 版本/来源 | 许可原文 |
| --- | --- | --- |
| ESP-IDF、Wi-Fi / PHY / coexistence | 上述 SDK 与其子模块 | Apache-2.0；ESP-* 文件 |
| LVGL | 9.4.0 | LVGL-MIT.txt |
| TinyUSB | 0.21.0~2 | TinyUSB-MIT.txt |
| esp_tinyusb | 2.4.0 | esp_tinyusb-Apache-2.0.txt |
| cJSON 与 Espressif 包装 | 1.7.19~2 | cJSON-MIT.txt、esp-cJSON-MIT.txt |
| FreeRTOS | 此 SDK 附带版本 | FreeRTOS-MIT.txt |
| lwIP | 子模块 `c6f2f878e7b0f86033214b85547d579be43351e3` | lwIP-BSD.txt |
| Mbed TLS / TF-PSA-Crypto | 此 SDK 固定子模块 | MbedTLS-LICENSE.txt、TF-PSA-Crypto-LICENSE.txt |
| FatFs | R0.16 | FatFs-R0.16.txt（从 ff.c 原头部原样提取） |
| ESP-ROM miniz 解码接口 | 此 SDK `components/esp_rom/include/miniz.h` | Apache-2.0；`2021-2022 Espressif Systems (Shanghai) CO LTD` |
| picolibc | 实际 RISC-V 工具链随附 | picolibc-COPYING.picolibc.txt、COPYING.NEWLIB、COPYING.GPL2 |
| GCC libgcc 运行库 | 实际 RISC-V 工具链随附 | GCC-Runtime-Exception-3.1.txt 与 GPL-3.0.txt |

Mbed TLS / TF-PSA-Crypto 允许 Apache-2.0 或 GPL-2.0-or-later 二选一；本工程选择 Apache-2.0 分支，离线显示完整 Apache 文本，源码中保留上游完整双许可文件。不能因其原文件包含 GPL 选项而称本工程选择了该选项。

许可证资源可无损压缩存储，经 ESP-ROM `tinfl` 解码后分页显示完整原文；压缩不删节许可证或版权。该接口独立于本版移除的旧 EPDiy 字体解码模块。

picolibc 是按文件具有不同许可的 C 运行库。保留工具链随附的完整版权清单及引用文本，而非笼统标为一个 BSD 许可。清单也列出工具、测试、文档等未必进入 BIN 的文件；保留这份清单不表示这些文件都被静态链接或全部许可都约束本应用。实际构建选择 `CONFIG_LIBC_PICOLIBC=y`，非另行引入 newlib 运行库；COPYING.NEWLIB 是该 picolibc 分发中的历史许可材料。完整源路径、SHA-256、工具链版本在 `sources/runtime-license-snapshot.json`。

## 图像与发布

锁屏/深休图为项目维护者已确认自绘并提供的资源。本次不另行更改图像。这里的软件许可不授予第三方商标、名称或服务使用权。

字体和字典允许开源/商业使用不等于省略署名、全文许可或 LGPL 对应材料。BIN-only 下载平台可在说明中给出对应版本源码和许可的稳定链接；设备离线许可也保留完整正文。尚未真正上传的材料不得表述为已经发布。
