# Metalio E-INK4 3.97 英寸固件口袋设备绑定

本绑定用于 Metalio E-INK4 3.97 英寸 ESP32-S3。对外协议为 FPOCKET ABI 1.0，参照公开指南修订 1.1（2026-11-02），Git blob 为 `9fb506d0934aa1f286f7bcccd81b0aa9955e24e5`。

| 项目 | 值 |
| --- | --- |
| 目标 | `metalio-eink4`，ESP32-S3，16 MiB Flash，DIO 80 MHz |
| 布局标识 | `metalio16m-s3-pocket13` |
| 完整 BIN 烧录起点、引导 | `0x0` |
| 分区表 | `0x8000` |
| NVS、OTA 选择、PHY | `0x9000 / 0x4000`、`0xd000 / 0x2000`、`0xf000 / 0x1000` |
| 管理器 OTA0 | `0x10000 / 0x2f0000` |
| 应用 OTA1 | `0x300000 / 0xd00000`（13 MiB） |
| 紧凑独立 BIN | 文件起点为引导，`0x10000` 为 factory 应用，完整文件可独立烧录 |
| 接入标记 | 应用镜像内偏移 `288` 的 512 字节 `FPOCKET-ABI-0001`，ABI 1.0 |

已验证工具链为 ESP-IDF 5.5.4，提交 `735507283d5b2f9fb363a1901172dbd9e847945d`。使用标准 ESP32-S3 应用描述符，链接保留 `.rodata_custom_desc` 中的身份头。启用 Bootloader OTA 回滚，集成应用在业务初始化和恢复成功后确认自己的待验证 OTA 镜像。

## 应用的紧凑独立 BIN

开发者可使用以下分区表生成紧凑双模式应用。条目顺序、名称、类型、偏移和容量按下表生成，flags 留空，保留 ESP-IDF 分区表 MD5。

```csv
# Name, Type, SubType, Offset, Size, Flags
nvs,data,nvs,0x9000,0x4000,
otadata,data,ota,0xd000,0x2000,
phy_init,data,phy,0xf000,0x1000,
factory,app,factory,0x10000,0xd00000,
```

整机文件的 ESP32-S3 引导位于 `0x0`，分区表位于 `0x8000`，应用位于 `0x10000`。引导与应用均使用 DIO、80 MHz、16 MiB 和 ESP 镜像内置摘要。应用标记从整机文件 `0x10120` 开始。NVS、OTA 初始选择、PHY 区以及各镜像间的留白填 `0xff`，以应用有效镜像结尾。

```sh
python -m esptool --chip esp32s3 merge_bin -o my-app.bin \
    --flash_mode dio --flash_freq 80m --flash_size 16MB \
    0x0 build/bootloader/bootloader.bin \
    0x8000 build/partition_table/partition-table.bin \
    0x10000 build/my-app.bin
```

在实际应用中使用指南的公开 `run` 和 `receipt` 记录完成启动、保存返回。独立运行识别实际 factory 分区。集成运行核对 OTA1、管理器身份和活动事务，并按协议返回 OTA0。镜像的可接受条件可以在 `main/pocket/pocket_image.cc` 核对。

宿主也识别包含 `ota_0`、`ota_1` 的独立整机封装。该封装按表中管理器与应用分区映射生成分区表，应用位于 `0x300000`，`0xd000` 的 ESP-IDF OTA 选择记录为 `ota_seq=2`、状态 `NEW`，其余非镜像区间填 `0xff`。应使用 ESP-IDF 生成分区表和镜像。

## 导入与容量

集成时，口袋从 `firmware-pocket/packages/` 读取设备绑定一致的 BIN。整机包只将经过校验的应用段写入 OTA1。应用按运行分区、管理器身份及标准交接记录判定集成环境。返回前先完成适用的保存和回执，再选择 OTA0 并重启。

13 MiB 指应用镜像本身的容量。带引导和分区表的整机 BIN 还含封装前缀。应用和口袋的字体及图像均各自随 BIN 内置。

集成时应用不得覆盖引导、分区表、OTA0、OTA 选择和 PHY 区。OTA1 全段留给应用镜像，没有额外的通用私有 Flash 分区。应用若使用芯片 NVS，应使用自己的命名空间，保留其他命名空间，并按 `CHECKPOINT` 将需要交接的数据提交到自己的 TF 应用目录。公共 Wi-Fi 的标准读写入口和私有资料路径以指南为准。

应用的 `version` 按 ABI 语法原样读取。文件名用于发现 `.bin`，扩展名大小写均可，应用身份来自镜像里的 `app_id`。列表一次最多显示 128 个包。

Plus 的 S31 BIN 和旧 3.97 的 11 MiB 布局 BIN 均需为此绑定重新构建。设备无前光，显示和电源操作通过 3.97 的硬件驱动实现。

[固件口袋接入规范与开发指南](https://github.com/Changkai9888/CloudZao-Projects/blob/main/protocols/固件口袋接入规范与开发指南.md)
