# 固件口袋 1.0.7-s3.20

Metalio E-INK4 3.97 英寸 ESP32-S3 版。管理器 OTA0 在 `0x10000`，13 MiB 应用 OTA1 在 `0x300000`。完整接入参数见 [设备绑定](DEVICE_BINDING.md)。

本版按公开指南 1.1 修订 ABI 1.0 的应用准入、交接恢复和可选公共 Wi-Fi 处理。应用按目标、设备绑定、镜像和 ABI 校验。

## 构建

1. 按 [ESP-IDF 安装指南](https://docs.espressif.com/projects/esp-idf/en/v5.5.4/esp32s3/get-started/) 安装 ESP32-S3 工具链，并启用 [ESP-IDF v5.5.4](https://github.com/espressif/esp-idf/tree/735507283d5b2f9fb363a1901172dbd9e847945d)。
2. 在已启用该 SDK 的 Linux 或 WSL 终端进入本目录，运行 `bash scripts/build.sh`。首次构建可按 `dependencies.lock` 从 Espressif 组件注册表取得依赖。也可执行 `idf.py -DPOCKET_INTERNAL_DIAGNOSTICS=OFF build`，再执行 `python scripts/package.py`。
3. 合并 BIN 与摘要写入 `dist/`。ESP-IDF 会记录编译时间，因此重建 BIN 的摘要可能不同。

当前发布 BIN 的版本和 SHA-256 见 [发布清单](release-manifest.json)。字库、拼音表、锁屏与深休图已随包提供可直接构建的资源。输入来源及再生成方式见 [资源说明](sources/README.md)。

## 许可和发布

见 [第三方说明](THIRD_PARTY_NOTICES.md) 与 [发布核对](RELEASE_NOTICES.md)。源码包可作为同版本 GitHub Release 的附件，并与 BIN 及许可说明一同分发。
