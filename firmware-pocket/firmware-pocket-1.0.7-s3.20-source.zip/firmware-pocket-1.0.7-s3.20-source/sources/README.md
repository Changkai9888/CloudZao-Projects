# 输入字体与拼音数据来源

本目录保留构建时使用的数据及来源。日常构建直接使用已生成资源，不下载字体、不加载大型输入法引擎。以下第三方内容按各自许可提供，不由项目 MIT 重新许可。

## 主字体

`main/assets/pocket_ui.fontpack` 是 Pocket 3.97 Native Sans，包含 17/20/23/28 px 四个原生 1bpp 字号，字重 500，覆盖率阈值 112。20/23 px 各有 6008 个可见字符，17 px 用于电量数字，28 px 用于标题。字形保留 Noto 的偏移、前进宽度和基线。

复现：`python scripts/build_font.py --font /path/NotoSansSC-wght.ttf --fallback-font /path/NotoSans-wdth-wght.ttf`。脚本只依赖本工程的 `scripts/font_support/font_format.py` 与 `scripts/font_characters.json`，不依赖旧工程或原MiSans字框。

固定源链接/SHA、原生大小、字符覆盖、两种字源的归属、生成工具版本见 `main/assets/pocket_ui.fontpack.provenance.json`。主字源Noto Sans SC提交2894aab31764f10f29c421bdfd2340d3b382d384，98个SC不覆盖的扩展字沿用原固定Noto Sans回退，同字号原生栅格化。生成器使用Pillow13.0.0、fontTools4.61.1、FreeType2.14.3；正常构建直接嵌入已有资源，无需安装字体工具。

完整字体许可在 `licenses/NotoSansSC-OFL.txt`、`NotoSans-OFL.txt`；组件源码MIT在 `licenses/Plus-Noto-Font-MIT.txt`。不把字形许可改成MIT。

## 候选权重：Rime / Android Pinyin IME

`rime-pinyin-simp/pinyin_simp.dict.yaml` 来源：
https://github.com/rime/rime-pinyin-simp/tree/0c6861ef7420ee780270ca6d993d18d4101049d0

该版本 `AUTHORS` 明确将词典文件列为 Derived from Android Pinyin IME、Apache License version 2.0。本目录保留原始数据、AUTHORS 和完整 LICENSE；许可副本亦放在 `licenses/`。该数据是输入法候选权重，不宣称是某一当代汉语语料的实测字频。

本项目的修改：仅筛选单字，将权重生成现有 C++ 候选表；不使用词组或整句预测。词典覆盖现有 4262 个汉字，保持 402 个拼音键及 4415 个字音对。优先使用该字该拼音的权重；12 个保留读音缺少精确字音权重，使用同一来源中该字的最高权重，详见 `pinyin-generation.json`。所有并列项按 Unicode 码点排序，不使用旧候选次序破同分，不携带旧字频数据。

## 保持读音集合

`pinyin_readings.json` 只保存已验收的字音对应关系。每个拼音下按 Unicode 码点排序，明确不保存旧排序权重。其原生成方式是 pypinyin 0.55.0 的单字默认读音加项目明确的常用多音字修正，避免此次授权更换顺带改变输入法可输入的字音集合。未声称全部生僻异读均经人工校勘。

- pypinyin 0.55.0：https://github.com/mozillazg/python-pinyin/tree/v0.55.0 ，保留 `licenses/pypinyin-MIT.txt`。
- 单字读音上游 pinyin-data：https://github.com/mozillazg/pinyin-data ，保留 `licenses/pinyin-data-MIT.txt`。
- pinyin-data 的 Unihan 数据来源声明对应 Unicode 数据许可，附 `licenses/Unicode.txt`（来自 https://www.unicode.org/license.txt）。不因为上游仓库存在别的词组文件而宣称那些文件也被采用。

重建：`python scripts/generate_pinyin.py`；只核对：`python scripts/generate_pinyin.py --check`。两条命令不联网，检查固定输入摘要、汉字和字音覆盖。输出仍为原格式 `notepad_ime::data::kEntries`，不改键盘行为、口袋应用协议或分区容量。

## 锁屏和深休图

`artwork-provenance.json` 记录本版两张 480×800 单色资源的编码和摘要。已处理位图随包提供，原始 PNG 只在重做图像时需要。
