#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Native Noto 1bpp glyphs, losslessly compacted; never fit into old boxes.

Reproduction uses two pinned TTFs. No runtime TTF or rasterizer is needed.
PNF1 stores four zlib-compressed, independently validated NTF1 fonts.
"""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import sys
import zlib

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent / 'font_support'))
from font_format import SOURCE_SHA, SOURCE_URL, encode, decode
# The catalog keys retain the Plus16 coverage groups. The values are the
# native pixel sizes used on the 3.97-inch screen.
NATIVE_SIZES = {18: 17, 25: 20, 32: 23, 38: 28}
FALLBACK_SHA = 'bfb7bb691513f12e734dc346c03a03f784912432d7e3fa8e56efcf906fe86b3d'
FALLBACK_URL = ('https://raw.githubusercontent.com/google/fonts/'
                '8b0a1d0f5983c89bc2b93f1b5fb55f9e252744b5/ofl/notosans/'
                'NotoSans%5Bwdth%2Cwght%5D.ttf')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def generate(args):
    from PIL import Image, ImageFont, features
    import fontTools
    from fontTools.ttLib import TTFont
    if sha(args.font.read_bytes()) != SOURCE_SHA:
        raise ValueError('Wrong SC source; expected ' + SOURCE_URL)
    if sha(args.fallback_font.read_bytes()) != FALLBACK_SHA:
        raise ValueError('Wrong fallback source; expected ' + FALLBACK_URL)
    sources = (args.font, args.fallback_font)
    tables = [TTFont(path) for path in sources]
    cmaps = [table.getBestCmap() for table in tables]
    charsets = json.loads(args.charset.read_text('utf-8'))['fonts']
    if sorted(map(int, charsets)) != list(NATIVE_SIZES):
        raise ValueError('Expected Plus16 coverage sets 18/25/32/38')
    records, payload, details = bytearray(), bytearray(), []
    next_offset = 16 + 4 * 24
    for original_size, size in NATIVE_SIZES.items():
        cps = sorted(set(charsets[str(original_size)]))
        if any(cp not in cmaps[0] and cp not in cmaps[1] for cp in cps):
            raise ValueError('Unsupported codepoint in requested coverage')
        faces = []
        for path, table in zip(sources, tables):
            face = ImageFont.truetype(str(path), size=size)
            face.set_variation_by_axes([500 if a.axisTag == 'wght' else a.defaultValue
                                       for a in table['fvar'].axes])
            faces.append(face)
        ascent, descent = faces[0].getmetrics()
        glyphs, fallback = [], []
        min_top, max_bottom = 0, 0
        for cp in cps:
            source = 0 if cp in cmaps[0] else 1
            if source:
                fallback.append(cp)
            face = faces[source]
            mask, (left, top) = face.getmask2(chr(cp), mode='L', anchor='ls')
            width, height = mask.size
            advance = int(face.getlength(chr(cp)) + 0.5)
            bits = bytearray((width * height + 7) // 8)
            for i, value in enumerate(mask):
                if value >= 112:
                    bits[i // 8] |= 0x80 >> (i & 7)
            if any(bool(bits[i // 8] & (0x80 >> (i & 7))) != (v >= 112)
                   for i, v in enumerate(mask)):
                raise ValueError('Pixel encoding differs from source mask')
            glyphs.append((cp, width, height, left, top, advance, bytes(bits)))
            min_top, max_bottom = min(min_top, top), max(max_bottom, top + height)
        ascent, descent = max(ascent, -min_top), max(descent, max_bottom)
        spec = size, 500, 112, ascent, descent, ascent + descent + 2
        raw = encode(spec, glyphs)
        spec2, glyphs2 = decode(raw)
        assert spec2 == spec and glyphs2 == glyphs
        packed = zlib.compress(raw, 9)
        assert zlib.decompress(packed) == raw
        records.extend(struct.pack('<HHIIIII', size, 500, next_offset, len(packed),
                                   len(raw), zlib.crc32(raw), 0))
        payload.extend(packed)
        next_offset += len(packed)
        if args.check_dir:
            args.check_dir.mkdir(parents=True, exist_ok=True)
            (args.check_dir / ('native-%d.ntf' % size)).write_bytes(raw)
        details.append(dict(pixels=size, weight=500, threshold=112,
                            glyphs=len(glyphs), raw_bytes=len(raw), packed_bytes=len(packed),
                            sha256=sha(raw), packed_sha256=sha(packed),
                            ascent=ascent, descent=descent, line_height=spec[-1],
                            glyph_min_top=min_top, glyph_max_bottom=max_bottom,
                            fallback_codepoints=fallback,
                            glyph_source_rule='Fallback codepoints use Noto Sans; all others use Noto Sans SC.'))
        print('%dpx: %d glyphs, raw=%d packed=%d metrics=%s ink=[%d,%d]' %
              (size, len(glyphs), len(raw), len(packed), spec[3:], min_top, max_bottom), flush=True)
    output = struct.pack('<4sHHII', b'PNF1', 1, 4, next_offset, 0) + records + payload
    assert len(output) == next_offset
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_bytes(output)
    report = dict(name='Pocket 3.97 Native Sans', license='OFL-1.1',
                  source_sha256=SOURCE_SHA, source_url=SOURCE_URL,
                  fallback_sha256=FALLBACK_SHA, fallback_url=FALLBACK_URL,
                  weight=500, threshold=112, bpp=1, format='PNF1: zlib-wrapped one-spec NTF1',
                  generation='Native ls baseline, original bearings/advance; coverage>=112; no resizing.',
                  tools=dict(pillow=Image.__version__, fonttools=fontTools.version,
                             freetype=features.version('freetype2'), python=sys.version.split()[0]),
                  charset_sha256=sha(args.charset.read_bytes()),
                  fontpack_bytes=len(output), fontpack_sha256=sha(output),
                  fonts=details, hardware_verification='pending user test on Pocket 3.97')
    args.output.with_name(args.output.name + '.provenance.json').write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print('PNF1 total=%d bytes; raw font memory=%d bytes' %
          (len(output), sum(d['raw_bytes'] for d in details)))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--font', type=Path, required=True)
    p.add_argument('--fallback-font', type=Path, required=True)
    p.add_argument('--charset', type=Path, default=ROOT / 'scripts/font_characters.json')
    p.add_argument('--output', type=Path, default=ROOT / 'main/assets/pocket_ui.fontpack')
    p.add_argument('--check-dir', type=Path, help='Optional explicit folder for uncompressed verification NTFs')
    args = p.parse_args()
    try:
        generate(args)
    except (ValueError, OSError, ImportError) as exc:
        p.exit(1, 'Font generation failed: %s\n' % exc)


if __name__ == '__main__':
    main()
