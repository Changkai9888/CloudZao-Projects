"""Merge a rebuild at address zero, without an artificial 16-MiB padding tail."""
import argparse
import hashlib
import json
from pathlib import Path
import struct

ROOT = Path(__file__).resolve().parents[1]


def inspect_esp(image):
    assert len(image) >= 64 and image[0] == 0xe9
    assert 1 <= image[1] <= 16 and image[2:4] == b'\x02\x4f'
    assert struct.unpack_from('<H', image, 12)[0] == 9 and image[23] == 1
    position = 24
    checksum = 0xef
    for _ in range(image[1]):
        assert position + 8 < len(image) - 32
        length = struct.unpack_from('<I', image, position + 4)[0]
        position += 8
        assert length % 4 == 0 and position + length <= len(image) - 32
        for byte in memoryview(image)[position:position + length]:
            checksum ^= byte
        position += length
    digest_at = (position + 16) & ~15
    assert digest_at + 32 == len(image) and image[digest_at - 1] == checksum
    assert hashlib.sha256(image[:digest_at]).digest() == image[digest_at:]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build', type=Path, default=ROOT / 'build')
    parser.add_argument('--out', type=Path, default=ROOT / 'dist')
    args = parser.parse_args()
    build = args.build
    app = (build / 'pocket_manager.bin').read_bytes()
    inspect_esp(app)
    assert app[32:36] == b'\x32\x54\xcd\xab'
    assert app[288:304] == b'FPOCKET-ABI-0001'
    assert struct.unpack_from('<HHII', app, 304) == (1, 0, 512, 1)
    assert app[324:356].split(b'\0')[0] == b'metalio-eink4'
    assert app[356:388].split(b'\0')[0] == b'metalio16m-s3-pocket13'
    assert len(app) <= 0x2f0000, 'Manager must fit without shrinking the application slot'
    version = app[48:80].split(b'\0')[0].decode()
    assert app[80:112].split(b'\0')[0] == b'pocket_manager'
    assert app[388:420].split(b'\0')[0] == b'pocket_manager'
    assert app[420:452].split(b'\0')[0] == version.encode()
    table = (build / 'partition_table/partition-table.bin').read_bytes()
    entries = []
    for at in range(0, len(table), 32):
        if table[at:at+2] != b'\xaa\x50': break
        _, kind, sub, offset, size, label, _ = struct.unpack_from('<HBBII16sI', table, at)
        entries.append((kind, sub, offset, size, label.split(b'\0')[0]))
    assert entries == [
        (1, 2, 0x9000, 0x4000, b'nvs'),
        (1, 0, 0xd000, 0x2000, b'otadata'),
        (1, 1, 0xf000, 0x1000, b'phy_init'),
        (0, 0x10, 0x10000, 0x2f0000, b'ota_0'),
        (0, 0x11, 0x300000, 0xd00000, b'ota_1'),
    ]
    assert table[at:at + 16] == b'\xeb\xeb' + b'\xff' * 14
    assert table[at + 16:at + 32] == hashlib.md5(table[:at]).digest()
    assert all(byte == 0xff for byte in table[at + 32:])
    image = bytearray(b'\xff' * (0x10000 + len(app)))
    parts = [(0x0, 'bootloader/bootloader.bin', 0x8000),
             (0x8000, 'partition_table/partition-table.bin', 0x1000),
             (0xd000, 'ota_data_initial.bin', 0x2000),
             (0x10000, 'pocket_manager.bin', 0x2f0000)]
    for address, name, limit in parts:
        data = (build / name).read_bytes()
        assert len(data) <= limit, name
        if address == 0:
            inspect_esp(data)
        if address == 0xd000:
            assert data == b'\xff' * limit, 'OTA selection must boot the manager'
        image[address:address+len(data)] = data
    out = args.out
    out.mkdir(parents=True, exist_ok=True)
    dest = out / ('firmware-pocket-' + version + '-empty.bin')
    dest.write_bytes(image)
    sha = hashlib.sha256(image).hexdigest()
    (out / 'SHA256.txt').write_text(sha + '  ' + dest.name + '\n', encoding='utf-8')
    print(json.dumps(dict(bin=dest.name, bytes=len(image), sha256=sha, version=version,
                          target='metalio-eink4', layout='metalio16m-s3-pocket13',
                          manager_bytes=len(app), application_capacity=0xd00000)))


if __name__ == '__main__':
    main()
