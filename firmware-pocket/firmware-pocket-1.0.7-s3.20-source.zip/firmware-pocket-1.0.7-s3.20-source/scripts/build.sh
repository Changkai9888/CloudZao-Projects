#!/usr/bin/env bash
set -euo pipefail

project="$(cd "$(dirname "$0")/.." && pwd)"
: "${IDF_PATH:?Activate ESP-IDF v5.5.4 before running this script}"
export IDF_TARGET=esp32s3
export IDF_COMPONENT_CHECK_NEW_VERSION=0

sdk_commit="$(git -C "$IDF_PATH" rev-parse HEAD)"
if [[ "$sdk_commit" != "735507283d5b2f9fb363a1901172dbd9e847945d" ]]; then
    printf 'Unexpected ESP-IDF revision: %s\n' "$sdk_commit" >&2
    exit 2
fi
cd "$project"
idf.py -DPOCKET_INTERNAL_DIAGNOSTICS=OFF reconfigure
cmake --build build --parallel "${POCKET_BUILD_JOBS:-1}"
python scripts/package.py --build build --out dist
