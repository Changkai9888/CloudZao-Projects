"""Pack the selected Plus artwork for the S3 portrait framebuffer."""

import argparse
import hashlib
import json
from pathlib import Path

from PIL import Image

PORTRAIT = (480, 800)
THRESHOLD = 160
INVERT_BITS = bytes.maketrans(bytes(range(256)), bytes(range(255, -1, -1)))
ASSETS = Path(__file__).resolve().parents[1] / "main/assets"


def pack(source, destination):
    with Image.open(source) as original:
        gray = original.convert("L").resize(PORTRAIT, Image.Resampling.LANCZOS)
    mono = gray.point(lambda value: 255 if value >= THRESHOLD else 0, mode="1")
    packed = mono.tobytes().translate(INVERT_BITS)
    assert len(packed) == 48_000
    assert 0 in mono.getextrema() and 255 in mono.getextrema()
    restored = Image.frombytes("1", PORTRAIT, packed.translate(INVERT_BITS))
    assert restored.tobytes() == mono.tobytes()
    destination.write_bytes(packed)
    return {
        "file": destination.name,
        "bytes": len(packed),
        "sha256": hashlib.sha256(packed).hexdigest(),
        "source_name": source.name,
        "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lockscreen", type=Path, required=True)
    parser.add_argument("--deepsleep", type=Path, required=True)
    args = parser.parse_args()
    report = {
        "portrait": PORTRAIT,
        "encoding": "row-major, MSB first, 1 = black",
        "threshold": THRESHOLD,
        "assets": [
            pack(args.lockscreen, ASSETS / "pocket_lockscreen.bin"),
            pack(args.deepsleep, ASSETS / "pocket_deepsleep.bin"),
        ],
    }
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    main()
