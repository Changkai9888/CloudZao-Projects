# 第三方代码、字体与数据许可

本说明对应3.97 英寸固件口袋的本次源码与资源。项目自行编写部分的 MIT 许可，不替代以下第三方许可。完整原文位于 `licenses/`；`licenses-list.json` 指定设备离线查看的正文和各文件 SHA-256。设备可将相同正文只存一份，但必须保留各来源的版权和适用关系。

## 设备参考与显示

本次为 Metalio E-INK4 3.97 英寸 ESP32-S3。使用基于 CloudZao 原 3.97 工程的板级接口，以及源码文件头标记 Apache-2.0 的 SSD1677 驱动。原 Plus 工程的 EPDiy 不进入本版构建。

## 字体

- `main/assets/pocket_ui.fontpack` 为 **Pocket 3.97 Native Sans**，基于 OFL 1.1 的 Noto Sans SC。以 17、20、23、28 px 原生生成纯黑白字形，字重 500，稍实笔画阈值 112，保留字形度量和统一基线。20 和 23 px 保留原有 6008 个可见字符，其中 98 个扩展字符使用同为 OFL 1.1 的 Noto Sans。制表符由运行时显示为空格。参数、来源和摘要见资源旁的 `.provenance.json`。
- `components/plus_font/` 与 `scripts/font_support/` 复用 Plus Noto Font 组件，原创代码MIT，版权及完整原文见 `licenses/Plus-Noto-Font-MIT.txt`。本许可不覆盖本项目的其他第三方代码及字库。
- Noto Sans SC：Google Fonts 提交 `2894aab31764f10f29c421bdfd2340d3b382d384`；版权 `Copyright 2014-2021 Adobe`，保留字体名 `Source`。Noto Sans：提交 `8b0a1d0f5983c89bc2b93f1b5fb55f9e252744b5`；版权 `Copyright 2022 The Noto Project Authors`。完整原文分别见 `NotoSansSC-OFL.txt`、`NotoSans-OFL.txt`。
- LVGL 9.4.0 自带的 `lv_font_montserrat_14.c` 来自 Montserrat-Medium.ttf 和 FontAwesome5-Solid+Brands+Regular.woff。Montserrat 版权 `Copyright 2011 The Montserrat Project Authors`；Font Awesome 字体版权 `Copyright (c) 2022 Fonticons, Inc.`，保留字体名 `Font Awesome`。字体均按 OFL-1.1 使用，原文见 `Montserrat-OFL.txt`、`FontAwesome5-LICENSE.txt`。
- Font Awesome 原许可文件还描述 SVG/JS 图标和代码的其他许可。本工程使用的是字体字形，不据此声明使用未引入的 SVG/JS 资源。离线界面合并显示字体版权及完整 OFL 正文。

## 拼音输入数据

- 仅含 4262 个单字、402 个拼音键和 4415 个字音对应；没有 Rime 运行时、词组预测或联网输入。
- 候选权重来源 `rime/rime-pinyin-simp`，固定提交 `0c6861ef7420ee780270ca6d993d18d4101049d0`，Apache-2.0。只提取原词典的单字权重，并按权重降序排列，等权按 Unicode 排序；不延续 Jun Da 候选排序。原词典和 AUTHORS 保留于 `sources/rime-pinyin-simp/`，完整许可见 `Rime-pinyin-simp-Apache-2.0.txt` 与 `Rime-pinyin-simp-AUTHORS.txt`。
- 为兼容已有输入行为，保留原单字读音成员关系；其来自 pypinyin 0.55.0 / pinyin-data（MIT）及原工程显式读音调整。新的 `sources/pinyin_readings.json` 使用 Unicode 顺序，不存旧频率排序。pypinyin、pinyin-data 版权和许可、相关 Unicode 数据许可分别在 `pypinyin-MIT.txt`、`pinyin-data-MIT.txt`、`Unicode.txt`。
- 12 个字音在 Rime 中无精确单字权重，以同一 Rime 词典中该字其他读音的最大权重排序；完整明细在 `sources/pinyin-generation.json`。这不是所有稀有读音均已经语言学审定的声明。生成脚本拒绝未匹配固定 SHA 的输入，见 `scripts/generate_pinyin.py`。
- 原完整词典作为可再现构建输入保存在源码，不编译进固件。

## SDK 和实际组件

使用 ESP-IDF 5.5.4 ESP32-S3，提交 `735507283d5b2f9fb363a1901172dbd9e847945d`。构建锁定 LVGL 9.4.0、esp_tinyusb 2.4.0、TinyUSB 0.21.0~3。SDK 内置组件包含 cJSON、FreeRTOS、lwIP、FatFs R0.15 patch2、Mbed TLS 和 Xtensa Newlib。实际 SDK 与工具链许可，以及 Open X4 灰阶波形和 FreeInk/CrossPoint 的署名，见 `licenses/actual-s3.20/` 和设备离线许可。离线资源由 ESP32-S3 ROM tinfl 无损解码。

## 图像与发布

锁屏和深休图由项目维护者提供。本版将图像按 480×800 屏幕转为单色原生资源。发布前确认图像和标识可再分发。项目 MIT 适用于原创代码。

字体和字典依照相应许可保留署名和许可原文。BIN-only 下载平台可在说明中给出对应版本源码和许可的稳定链接；设备离线许可也保留完整正文。尚未真正上传的材料不得表述为已经发布。
