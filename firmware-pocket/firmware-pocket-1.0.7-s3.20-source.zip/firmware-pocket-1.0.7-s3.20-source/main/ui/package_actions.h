#pragma once
#include "pocket/pocket_runtime.h"
#include <string>

namespace pocket::ui_policy {
inline bool Ready(const View& view) {
    return view.ready&&!view.busy&&!view.switching&&!view.auth_required;
}
inline bool CanRefresh(const View& view) {return Ready(view)&&!view.usb_active;}
inline bool CanInspectPackage(const View& view,int index) {
    return Ready(view)&&view.manager&&index>=0&&static_cast<std::size_t>(index)<view.packages.size();
}
inline bool CanInstall(const View& view,int index,const std::string& id,const std::string& version) {
    // Normal unfinished applications are isolated on their own package row.
    // A remaining global block means real control/storage state is uncertain.
    if(!CanInspectPackage(view,index)||!view.storage_ok||view.state_blocked||view.handoff_blocked||
       view.usb_active||view.tf_space_blocked)return false;
    const auto& package=view.packages[static_cast<std::size_t>(index)];
    return package.compatible&&package.id==id&&package.version==version;
}
inline bool CanRestartPackage(const View& view,int index,const std::string& id,const std::string& version) {
    if(!CanInspectPackage(view,index)||!view.storage_ok||view.state_blocked||view.handoff_blocked||
       view.usb_active||view.tf_space_blocked)return false;
    const auto& package=view.packages[static_cast<std::size_t>(index)];
    return !package.compatible&&package.restart_allowed&&package.restart_run_id.size()==32&&
           package.restart_run_id.find_first_not_of("0123456789abcdef")==std::string::npos&&
           package.restart_image_sha256.size()==64&&
           package.restart_image_sha256.find_first_not_of("0123456789abcdef")==std::string::npos&&
           !id.empty()&&!version.empty()&&package.id==id&&package.version==version;
}
inline bool SamePackage(const PackageView& a,const PackageView& b) {
    return a.name==b.name&&a.version==b.version&&a.id==b.id&&a.detail==b.detail&&
           a.description==b.description&&a.last_used==b.last_used&&
           a.storage_mode==b.storage_mode&&a.exit_method==b.exit_method&&a.exit_hint==b.exit_hint&&
           a.compatible==b.compatible&&a.restart_allowed==b.restart_allowed&&
           a.restart_run_id==b.restart_run_id&&a.restart_image_sha256==b.restart_image_sha256;
}
inline std::string PackageSummary(const PackageView& package) {
    if(package.compatible)return package.description.empty()?"暂无描述":package.description;
    return "不可用："+(package.detail.empty()?std::string("请点右侧查看原因"):package.detail);
}
inline std::string UnfinishedSwitchWarning(const View& view,bool resuming) {
    return (view.resume_available || view.unfinished_checkpoint)&&!resuming?
        "\n\n切换其他应用将结束上次未完成的运行；已保存的TF文件保留，未保存进度可能丢失。":"";
}
} // namespace pocket::ui_policy
