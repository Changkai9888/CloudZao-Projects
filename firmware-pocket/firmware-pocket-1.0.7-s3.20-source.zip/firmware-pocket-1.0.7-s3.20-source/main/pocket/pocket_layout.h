#pragma once
#include <cstdint>
#define POCKET_TARGET_ID "metalio-eink4"
#define POCKET_LAYOUT_ID "metalio16m-s3-pocket13"

namespace pocket {
// Metalio E-INK4 ESP32-S3 binding. Source-file offsets and Flash destinations are
// deliberately separate. The ABI record layout remains FPOCKET ABI 1.0.
inline constexpr char kTargetId[] = POCKET_TARGET_ID;
inline constexpr std::uint16_t kImageChipId = 0x0009;
inline constexpr std::uint8_t kImageFlashMode = 2; // DIO
inline constexpr std::uint8_t kImageFlashSizeSpeed = 0x4f; // 16 MiB / 80 MHz
inline constexpr std::uint32_t kBootloaderOffset = 0x0;
inline constexpr std::uint32_t kPartitionTableOffset = 0x8000;
inline constexpr std::uint32_t kNvsAddress = 0x9000;
inline constexpr std::uint32_t kNvsSize = 0x4000;
inline constexpr std::uint32_t kOtaDataAddress = 0xd000;
inline constexpr std::uint32_t kOtaDataSize = 0x2000;
inline constexpr std::uint32_t kPhyAddress = 0xf000;
inline constexpr std::uint32_t kPhySize = 0x1000;
inline constexpr std::uint32_t kCompactStandaloneOffset = 0x10000;
// Fixed manager layout v2. Application fonts/resources belong to each BIN.
inline constexpr std::uint32_t kManagerAddress = 0x10000;
inline constexpr std::uint32_t kManagerSize = 0x2f0000;
inline constexpr std::uint32_t kAppAddress = 0x300000;
inline constexpr std::uint32_t kAppSize = 0xd00000;
inline constexpr char kLayoutId[] = POCKET_LAYOUT_ID;
static_assert(kManagerAddress + kManagerSize == kAppAddress);
static_assert(kAppAddress + kAppSize == 16U * 1024U * 1024U);
}
