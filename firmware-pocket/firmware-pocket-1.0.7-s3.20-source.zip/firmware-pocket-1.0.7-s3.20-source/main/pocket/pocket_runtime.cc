#include "pocket_runtime.h"
#include "pocket_core.h"
#include "pocket_build.h"
#include "pocket_image.h"
#include "pocket_layout.h"
#include "pocket_wifi.h"
#include "pocket_space.h"
#include "pocket_handoff.h"
#include "pocket_standard.h"
#include "pocket_recovery.h"
#include "ff.h"
#include "hal/pocket_hal.h"
#include "ime/pocket_keyboard.h"
#include "font/pocket_font.h"
#include "pocket_hash.h"
#include "pocket_pin.h"
#include <driver/usb_serial_jtag.h>
#include <cJSON.h>
#include <esp_app_desc.h>
#include <esp_ota_ops.h>
#include <esp_partition.h>
#include <esp_log.h>
#include <esp_system.h>
#include <esp_random.h>
#include <esp_heap_caps.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/queue.h>
#include <algorithm>
#include <array>
#include <cerrno>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <dirent.h>
#include <map>
#include <mutex>
#include <sys/stat.h>
#include <unistd.h>

namespace pocket {
namespace {
constexpr char TAG[] = "Pocket";
constexpr char ROOT[] = "/sdcard/firmware-pocket";
constexpr uint32_t MANAGER_ADDRESS = kManagerAddress, APP_ADDRESS = kAppAddress;
struct Request {
    Command command; int argument;
    char ssid[33]{}; char password[65]{};
    char pin[9]{}, next_pin[9]{}, confirm_pin[9]{};
    char restart_app[32]{}, restart_version[32]{}, restart_run[33]{}, restart_sha[65]{};
};
void ClearRequestSecrets(Request& request) {
    // Erase only credential arrays, not a C++ aggregate with default members.
    // Volatile writes also prevent dead-store elimination of the local cleanup.
    const auto clear=[](char* data,size_t size) {
        volatile char* bytes=data;
        while(size--) *bytes++=0;
    };
    clear(request.password,sizeof(request.password));
    clear(request.pin,sizeof(request.pin));
    clear(request.next_pin,sizeof(request.next_pin));
    clear(request.confirm_pin,sizeof(request.confirm_pin));
}
struct Package { Manifest manifest; std::string image_path; uint32_t image_offset = 0; bool valid = false; };
std::mutex view_mutex;
View cached;
QueueHandle_t queue = nullptr;
std::vector<Package> packages;
View state;
bool layout_ok = false, resources_ok = false;
std::string user_id, state_dir;
int public_preference = 1;
bool state_loaded = false, state_persisted = false, shutting_down = false;
bool last_used_attempted = false;
std::string console_line;
bool test_fail_save = false, test_reset_install = false;
bool usb_seen_host = false;
WakePinStore wake_pin(std::string(ROOT)+"/private/pocket");
bool wake_session_unlocked = false;
unsigned failed_pin_attempts = 0;
TickType_t pin_retry_after = 0;
int wifi_test_revision = 0;
WifiOffer active_offer;
uint32_t candidate_token = 0;
std::string fallback_ssid;
std::string StatusDirectory() { return std::string(ROOT)+"/status"; }
std::string RecoveryDirectory() { return std::string(ROOT)+"/recovery/"+user_id; }
void CancelCandidate(bool disconnect = true);
void CheckManagerHandoff(bool offer_wifi = false);
void PollCandidate();
constexpr char kWifiTestSsid[] = "__pocket_shared_test__";

// Keep long checks responsive without adding a 10 ms sleep for every 2 KB.
void YieldChunk(uint32_t total) { if ((total & 0xffff) == 0) vTaskDelay(1); }
void ConsoleEnable() {
    if (usb_serial_jtag_is_driver_installed()) return;
    usb_serial_jtag_driver_config_t config{256, 512};
    const auto err = usb_serial_jtag_driver_install(&config);
    if (err != ESP_OK) ESP_LOGW(TAG,"Diagnostic console unavailable: %s",esp_err_to_name(err));
}
void ConsoleDisable() {
    if (usb_serial_jtag_is_driver_installed()) usb_serial_jtag_driver_uninstall();
    console_line.clear();
}

void Publish() {
    state.wifi_connection = WifiConnectionSnapshot();
    std::lock_guard<std::mutex> lock(view_mutex);
    state.revision = cached.revision + 1;
    cached = state;
}
// Only the internal-RAM worker accesses the gauge. LVGL consumes View's cache.
// Poll slowly and publish only changed values to avoid needless e-paper updates.
void PollBattery(bool force = false) {
    static bool sampled = false;
    static TickType_t last_sample = 0;
    const TickType_t now = xTaskGetTickCount();
    if (!force && sampled && now - last_sample < pdMS_TO_TICKS(5000)) return;
    sampled = true;
    last_sample = now;
    int level = pocket_hal::BatteryLevel();
    if (level < 0 || level > 100) level = -1;
    if (state.battery_level != level) {
        state.battery_level = level;
        Publish();
    }
}

void Error(const std::string& message) {
    state.error = message;
    state.status = "操作未完成，原有记录保留";
    state.busy = false;
    state.switching = false;
    if(state.scan_running) { state.scan_running=false; state.scan_complete=false; }
    ESP_LOGE(TAG, "%s", message.c_str());
    Publish();
}
bool IsSwitchCommand(Command command) {
    return command==Command::InstallAndLaunch || command==Command::ReturnToManager ||
           command==Command::ResumeApplication || command==Command::RestartAndLaunch;
}
const char* SwitchStatus(Command command) {
    return command==Command::ReturnToManager?"正在保存并返回固件口袋":"正在切换应用，请稍候";
}
bool Directory(const std::string& path) {
    if (mkdir(path.c_str(), 0775) != 0 && errno != EEXIST) return false;
    struct stat st{};
    return stat(path.c_str(), &st) == 0 && S_ISDIR(st.st_mode);
}
bool StorageAvailable() {
    return !pocket_hal::UsbBusy() && !pocket_hal::UsbActive() && !pocket_hal::UsbExported() &&
           pocket_hal::TfMounted();
}

bool LoadWakePin() {
    if(!state.manager) return true;
    std::string error;
    const bool ready=StorageAvailable() && Directory(std::string(ROOT)+"/private") &&
        Directory(std::string(ROOT)+"/private/pocket") && wake_pin.Load(&error);
    state.pin_ready=ready;
    if(!ready) {
        // Do not silently unlock or replace a missing/corrupt security record.
        state.auth_required=true;
        state.pin_message="密码配置不可用，请检查 TF 卡后重新检查";
        if(!error.empty()) ESP_LOGE(TAG,"Wake PIN storage unavailable: %s",error.c_str());
    } else {
        state.pin_is_default=wake_pin.IsDefault();
        state.auth_required=wake_pin.NeedsUnlock() ||
            (pocket_hal::WokeFromDeepSleep() && !wake_session_unlocked);
        if(state.auth_required && !wake_pin.NeedsUnlock() && !wake_pin.SetNeedsUnlock(true,&error)) {
            state.pin_ready=false;
            state.pin_message="唤醒锁定状态无法保存，请检查 TF 卡";
        } else state.pin_message=state.auth_required?"请输入数字密码解锁":"";
    }
    ++state.pin_revision;
    return state.pin_ready;
}

void HandlePin(const Request& request) {
    ++state.pin_revision;
    if(!state.manager || !state.pin_ready || !StorageAvailable()) {
        state.pin_message="密码配置不可用，请检查 TF 卡"; return;
    }
    if(request.command==Command::ChangePin && state.auth_required) {
        state.pin_message="请先解锁"; return;
    }
    if(static_cast<int32_t>(xTaskGetTickCount()-pin_retry_after)<0) {
        state.pin_message="请稍候再试"; return;
    }
    if(!WakePinStore::ValidPin(request.pin) || !wake_pin.Verify(request.pin)) {
        if(++failed_pin_attempts>=5) {
            pin_retry_after=xTaskGetTickCount()+pdMS_TO_TICKS(10000);
            failed_pin_attempts=0;
        }
        state.pin_message="密码错误，请重试"; return;
    }
    std::string error;
    if(request.command==Command::UnlockPin) {
        if(!wake_pin.SetNeedsUnlock(false,&error)) {
            state.pin_ready=false; state.pin_message="解锁状态保存失败，请重新检查 TF 卡";
        } else {
            state.auth_required=false; state.pin_message="已解锁";
            wake_session_unlocked=true;
            failed_pin_attempts=0;
        }
    } else {
        if(!WakePinStore::ValidPin(request.next_pin)) { state.pin_message="请设置 4～8 位数字密码"; return; }
        if(strcmp(request.next_pin,request.confirm_pin)!=0) { state.pin_message="两次新密码不一致"; return; }
        if(!wake_pin.Change(request.pin,request.next_pin,&error)) {
            state.pin_ready=false; state.pin_message="密码保存失败，请重新检查 TF 卡";
        } else {
            state.pin_is_default=wake_pin.IsDefault(); state.pin_message="密码已更新";
            failed_pin_attempts=0;
        }
    }
}
bool UpdateSpace() {
    state.tf_space_known=false; state.tf_free_bytes=0;
    state.tf_space_low=false; state.tf_space_blocked=true;
    if(!StorageAvailable()) return false;
    FATFS* fs=nullptr; DWORD free_clusters=0;
    if(f_getfree("0:",&free_clusters,&fs)!=FR_OK || !fs) return false;
#if FF_MAX_SS == FF_MIN_SS
    constexpr uint64_t sector_bytes=FF_MAX_SS;
#else
    const uint64_t sector_bytes=fs->ssize;
#endif
    state.tf_free_bytes=static_cast<uint64_t>(free_clusters)*fs->csize*sector_bytes;
    state.tf_space_known=true;
    state.tf_space_low=SpaceWarning(state.tf_free_bytes);
    state.tf_space_blocked=SpaceBlocked(state.tf_free_bytes);
    return true;
}
bool CheckStartSpace() {
    if(!UpdateSpace()) { Error("无法读取 TF 剩余空间，请重新检查；维护入口仍可用"); return false; }
    if(state.tf_space_blocked) {
        Error("TF 剩余空间不足 150 MB，已暂停应用启动；请通过模拟 U 盘手动删除多余文件，再刷新");
        return false;
    }
    return true;
}
bool LoadWifiView() {
    std::vector<WifiNetwork> networks; std::string error;
    state.wifi_ready=ReadSharedWifi(&networks,&error);
    state.wifi_names.clear(); wifi_test_revision=0;
    if(!state.wifi_ready) { Error("公共网络配置读取失败: "+error); return false; }
    for(const auto& network:networks) {
        state.wifi_names.push_back(network.ssid);
        if(network.ssid==kWifiTestSsid)
            wifi_test_revision=network.password=="pocket-test-one"?1:network.password=="pocket-test-two"?2:-1;
    }
    return true;
}
void PollWifiConnection() {
    if (WifiConnectionSnapshot().revision != state.wifi_connection.revision) Publish();
}
struct Sha {
    Sha256 context;
    bool valid = true;
    void Add(const void* data, size_t size) { if(valid) valid=context.Add(data,size); }
    std::array<unsigned char, 32> Finish() { std::array<unsigned char,32> out{}; valid=valid && context.Finish(out.data()); return out; }
};
std::string Hex(const std::array<unsigned char,32>& bytes) {
    constexpr char digits[] = "0123456789abcdef";
    std::string s;
    for (auto b: bytes) { s += digits[b >> 4]; s += digits[b & 15]; }
    return s;
}
bool PartitionHash(const esp_partition_t* p, uint32_t size, std::string* result) {
    if (!p || size > p->size) return false;
    Sha hash;
    std::array<unsigned char, 2048> block{};
    for (uint32_t pos = 0; pos < size;) {
        size_t n = std::min<uint32_t>(block.size(), size - pos);
        if (esp_partition_read(p, pos, block.data(), n) != ESP_OK) return false;
        hash.Add(block.data(), n); pos += n;
        YieldChunk(pos);
    }
    *result = Hex(hash.Finish());
    return hash.valid;
}
const esp_partition_t* Slot(esp_partition_subtype_t subtype, uint32_t address) {
    const auto* p = esp_partition_find_first(ESP_PARTITION_TYPE_APP, subtype, nullptr);
    const auto size = subtype == ESP_PARTITION_SUBTYPE_APP_OTA_0 ? kManagerSize : kAppSize;
    return p && p->address == address && p->size == size ? p : nullptr;
}
bool CheckLayout() {
    const auto* nvs = esp_partition_find_first(ESP_PARTITION_TYPE_DATA, ESP_PARTITION_SUBTYPE_DATA_NVS, "nvs");
    const auto* ota = esp_partition_find_first(ESP_PARTITION_TYPE_DATA, ESP_PARTITION_SUBTYPE_DATA_OTA, "otadata");
    return Slot(ESP_PARTITION_SUBTYPE_APP_OTA_0, MANAGER_ADDRESS) && Slot(ESP_PARTITION_SUBTYPE_APP_OTA_1, APP_ADDRESS) &&
           nvs && nvs->address == kNvsAddress && nvs->size == kNvsSize &&
           ota && ota->address == kOtaDataAddress && ota->size == kOtaDataSize;
}
bool ManagerPresent() {
    const auto* p = Slot(ESP_PARTITION_SUBTYPE_APP_OTA_0, MANAGER_ADDRESS);
    esp_app_desc_t desc{};
    CompactMetadata metadata{};
    return p && esp_ota_get_partition_description(p, &desc) == ESP_OK &&
           strcmp(desc.project_name, "pocket_manager") == 0 &&
           esp_partition_read(p, kCompactMetadataOffset, &metadata, sizeof(metadata)) == ESP_OK &&
           memcmp(metadata.magic, "FPOCKET-ABI-0001", 16) == 0 && metadata.abi_major == 1 && metadata.abi_minor == 0 &&
           metadata.header_bytes == sizeof(metadata) && metadata.flags == 1 &&
           strncmp(metadata.layout_profile, kLayoutId, sizeof(metadata.layout_profile)) == 0 &&
           strncmp(metadata.target, kTargetId, sizeof(metadata.target)) == 0 &&
           strncmp(metadata.app_id, "pocket_manager", sizeof(metadata.app_id)) == 0;
}
bool MarkStarted() {
    const auto* running = esp_ota_get_running_partition();
    esp_ota_img_states_t status;
    if (esp_ota_get_state_partition(running, &status) == ESP_OK && status == ESP_OTA_IMG_PENDING_VERIFY) {
        if (!pocket_hal::BeginFlashWrite(0, 10000)) {
            Error("启动确认等待硬件空闲超时，请重启重试"); return false;
        }
        esp_err_t err = esp_ota_mark_app_valid_cancel_rollback();
        pocket_hal::EndFlashWrite();
        if (err != ESP_OK) { Error(std::string("启动确认失败: ") + esp_err_to_name(err)); return false; }
    }
    ESP_LOGI(TAG, "START_CONFIRMED id=%s version=%s partition=%s address=0x%lx",
             POCKET_APP_ID, POCKET_VERSION, running->label, static_cast<unsigned long>(running->address));
    return true;
}

bool LoadIdentity() {
    state.storage_ok = false;
    if (!StorageAvailable()) { Error("TF 卡不可用，请插卡或先停用模拟 U 盘"); return false; }
    if (!Directory(ROOT) || !Directory(std::string(ROOT)+"/shared") || !Directory(std::string(ROOT)+"/status") ||
        !Directory(std::string(ROOT)+"/packages") || !Directory(std::string(ROOT)+"/users")) {
        Error("不能创建口袋专用目录，未更改其他目录"); return false;
    }
    RecordStore store(std::string(ROOT)+"/shared");
    auto r = store.Load("identity", 1);
    if (r.status == RecordStatus::Missing) {
        if (!user_id.empty()) { Error("用户身份文件缺失，请恢复原卡后重新检查"); return false; }
        uint8_t random[12]; esp_fill_random(random, sizeof(random));
        char buf[26] = "u";
        for (size_t i=0;i<12;++i) snprintf(buf+1+i*2, 3, "%02x", random[i]);
        r = store.Save("identity", 1, std::string(buf)+"\n");
        if (!r.ok()) { Error("创建用户身份失败: "+r.error); return false; }
    } else if (!r.ok()) { Error("用户身份记录异常，停止创建新身份: "+r.error); return false; }
    size_t split = r.payload.find('\n');
    if (split == std::string::npos) { Error("用户身份格式错误"); return false; }
    const std::string candidate = r.payload.substr(0, split);
    if (!IsSafeIdentifier(candidate) || (r.payload.substr(split) != "\n" && r.payload.substr(split) != "\n0\n" && r.payload.substr(split) != "\n1\n")) {
        Error("用户身份或公共配置格式错误"); return false;
    }
    if (!user_id.empty() && candidate != user_id) {
        Error("用户身份与本次运行不符，请换回原卡；未保存内容保留"); return false;
    }
    const std::string user_root = std::string(ROOT)+"/users/"+candidate;
    if (!Directory(user_root) || !Directory(user_root+"/apps")) { Error("用户存储目录不可写"); return false; }
    const std::string candidate_dir = user_root+"/apps/"+POCKET_APP_ID;
    if (!Directory(candidate_dir)) { Error("应用存储目录不可写"); return false; }
    user_id = candidate; state_dir = candidate_dir;
    public_preference = 1; // Legacy identity suffix is accepted, never a font setting.
    state.user_id = user_id; state.public_preference = public_preference;
    state.storage_ok = true;
    return true;
}
bool ValidUsedCalendar(int year, int month, int day, int hour, int minute, int second = 0) {
    // Reject the RTC's initial/unset calendar range, without inventing a date
    // from uptime or compilation time. RTC validity alone cannot prove clock accuracy.
    if(year < 2024 || year > 2099 || month < 1 || month > 12 || hour < 0 || hour > 23 ||
       minute < 0 || minute > 59 || second < 0 || second > 59) return false;
    constexpr int days[] = {31,28,31,30,31,30,31,31,30,31,30,31};
    int maximum=days[month-1];
    if(month==2 && year%4==0 && (year%100!=0 || year%400==0)) ++maximum;
    return day >= 1 && day <= maximum;
}
std::string CurrentUsedPayload() {
    struct tm calendar{}; bool valid=false;
    // ApplyRtcToSystem() also applies VL-invalid clocks, so time() alone is not
    // a sufficient trust test. Read the existing RTC including its validity bit.
    if(!pocket_hal::RtcTime(&calendar,&valid) || !valid ||
       !ValidUsedCalendar(calendar.tm_year+1900,calendar.tm_mon+1,calendar.tm_mday,
                         calendar.tm_hour,calendar.tm_min,calendar.tm_sec)) return "unsynced\n";
    char text[80];
    snprintf(text,sizeof(text),"rtc|%04d-%02d-%02d %02d:%02d\n",calendar.tm_year+1900,
             calendar.tm_mon+1,calendar.tm_mday,calendar.tm_hour,calendar.tm_min);
    return text;
}
void RecordLastUsedOnce() {
    if(state.manager || last_used_attempted || state_dir.empty() || !state.storage_ok || !StorageAvailable()) return;
    last_used_attempted=true;
    const auto saved=RecordStore(state_dir).Save("last_used",1,CurrentUsedPayload());
    if(!saved.ok())
        ESP_LOGW(TAG,"LAST_USED_WRITE_SKIPPED id=%s reason=%s",POCKET_APP_ID,RecordStatusName(saved.status));
}
std::string LastUsedLabel(const std::string& app_id) {
    if(user_id.empty() || !IsSafeIdentifier(app_id)) return "暂无记录";
    const std::string directory=std::string(ROOT)+"/users/"+user_id+"/apps/"+app_id;
    struct stat info{};
    if(stat(directory.c_str(),&info)!=0) return errno==ENOENT?"暂无记录":"记录不可读";
    if(!S_ISDIR(info.st_mode)) return "记录异常";
    const auto record=RecordStore(directory).Load("last_used",1);
    if(record.status==RecordStatus::Missing) return "暂无记录";
    if(!record.ok()) {
        ESP_LOGW(TAG,"LAST_USED_READ_SKIPPED id=%s reason=%s",app_id.c_str(),RecordStatusName(record.status));
        return "记录异常";
    }
    if(record.payload=="unsynced\n") return "时间未同步";
    int year=0,month=0,day=0,hour=0,minute=0,consumed=0;
    if(record.payload.size()!=21 ||
       sscanf(record.payload.c_str(),"rtc|%d-%d-%d %d:%d\n%n",&year,&month,&day,&hour,&minute,&consumed)!=5 ||
       consumed!=21 || !ValidUsedCalendar(year,month,day,hour,minute)) return "记录异常";
    char canonical[80];
    snprintf(canonical,sizeof(canonical),"rtc|%04d-%02d-%02d %02d:%02d\n",year,month,day,hour,minute);
    if(record.payload!=canonical) return "记录异常";
    return record.payload.substr(9,11);  // MM-DD HH:mm; full local RTC year remains in the record.
}
bool DecodeState(const RecordResult& r) {
    int a,b,c,d,theme=0,consumed=0;
    int fields = r.schema == 1 ? sscanf(r.payload.c_str(), "%d %d %d %d\n%n", &a,&b,&c,&d,&consumed) :
        sscanf(r.payload.c_str(), "v2|%d|%d|%d|%d|%d\n%n", &a,&b,&c,&d,&theme,&consumed);
    if (fields != (r.schema == 1 ? 4 : 5) || consumed != static_cast<int>(r.payload.size()) ||
        a<0 || a>999999 || b<1 || b>9999 || c<0 || c>3 || d<0 || d>1 || theme<0 || theme>1) return false;
    state.counter=a; state.bookmark=b; state.note=c; state.preference=d;
    return true;
}
std::string EncodeState() {
    char text[128];
    if (POCKET_STATE_SCHEMA == 1) snprintf(text,sizeof(text),"%d %d %d %d\n",state.counter,state.bookmark,state.note,state.preference);
    else snprintf(text,sizeof(text),"v2|%d|%d|%d|%d|1\n",state.counter,state.bookmark,state.note,state.preference);
    return text;
}
bool LoadState() {
    RecordStore store(state_dir);
    auto r=store.Load("state", POCKET_STATE_SCHEMA);
    if (r.status == RecordStatus::Missing) {
        if (state_persisted) { state.state_blocked=true; Error("原存档已缺失，请恢复记录后重试"); return false; }
        state.counter=0; state.bookmark=1; state.note=0; state.preference=0;
        state.status="尚无存档，可开始操作"; state_loaded=true; return true;
    }
    if (!r.ok() || !DecodeState(r)) { state.state_blocked=true; Error("存档异常或版本较新，保护原记录: "+r.error); return false; }
    state.status = r.degraded ? "已从有效副本恢复；另一副本异常" : "已恢复上次记录";
#if POCKET_STATE_SCHEMA > 0
    if (r.schema < POCKET_STATE_SCHEMA) {
        // The old valid record remains in the other slot during migration.
        auto saved=store.Save("state",POCKET_STATE_SCHEMA,EncodeState());
        if (!saved.ok()) { state.state_blocked=true; Error("存档迁移失败，旧记录已保留: "+saved.error); return false; }
        state.status="旧记录已迁移到新版，内容保留";
    }
#endif
    state_loaded=true; state_persisted=true;
    return true;
}
bool SaveState() {
    if (state.manager) return true;
    if (test_fail_save) { Error("测试注入：保存失败，尚未退出"); return false; }
    if (!state_loaded || state.state_blocked || !LoadIdentity()) { Error("当前不能保存；请恢复 TF 卡后重试，尚未退出"); return false; }
    auto result=RecordStore(state_dir).Save("state", POCKET_STATE_SCHEMA, EncodeState());
    if (!result.ok()) { Error("保存失败，尚未退出: "+result.error); return false; }
    state.dirty=false; state_persisted=true; state.error.clear(); state.status="已保存并读回校验";
    const auto generation=std::to_string(result.generation);
    ESP_LOGI(TAG,"SAVE_OK id=%s generation=%s schema=%u",POCKET_APP_ID,generation.c_str(),result.schema);
    UpdateSpace();
    return true;
}

bool Validate(Package* package, std::string* error, bool full = true) {
    CompactImageInfo info;
    const bool ok = full ? ValidateCompactImage(package->image_path, &info, error) :
                           ProbeCompactImage(package->image_path, &info, error);
    if (!ok) return false;
    if (info.manager || info.manifest.id == "pocket_manager") {
        *error = "管理器不能作为普通部件切换"; return false;
    }
    package->image_offset = info.image_offset;
    package->manifest = std::move(info.manifest);
    return true;
}
void InvalidateScan() {
    state.scan_running=false; state.scan_complete=false;
    state.scan_total=0; state.scan_done=0;
    state.packages.clear(); packages.clear();
}
void Scan() {
    InvalidateScan(); state.error.clear();
    state.scan_running=true; state.status="正在扫描应用包，请稍候"; Publish();
    if(!StorageAvailable()) { state.storage_ok=false; Error("TF 卡不可读取或正由电脑占用"); return; }
    const std::string path=std::string(ROOT)+"/packages";
    DIR* d=opendir(path.c_str());
    if(!d) { Error("无法打开应用包目录"); return; }
    std::vector<std::pair<std::string,std::string>> names;
    bool enumeration_failed=false;
    for(;;) {
        errno=0;
        auto* item=readdir(d);
        if(!item) { enumeration_failed=errno!=0; break; }
        const std::string name=item->d_name;
        if(name.empty() || name=="." || name=="..") continue;
        const std::string entry=path+"/"+name;
        struct stat st{};
        if(stat(entry.c_str(),&st)!=0) { enumeration_failed=true; break; }
        const auto end=name.size();
        const bool bin=end>=4 && name[end-4]=='.' &&
            (name[end-3]=='b' || name[end-3]=='B') &&
            (name[end-2]=='i' || name[end-2]=='I') &&
            (name[end-1]=='n' || name[end-1]=='N');
        if(S_ISREG(st.st_mode) && bin) {
            names.emplace_back(name,entry);
        } else if(S_ISDIR(st.st_mode) && name[0]!='.') {
            const std::string image=entry+"/app.bin";
            if(stat(image.c_str(),&st)==0 && S_ISREG(st.st_mode)) names.emplace_back(name,image);
        }
    }
    if(closedir(d)!=0) enumeration_failed=true;
    if(enumeration_failed) { Error("应用包目录读取中断，请重新检查"); return; }
    std::sort(names.begin(),names.end());
    constexpr size_t kMaxPackages = 128;
    if(names.size()>kMaxPackages) names.resize(kMaxPackages);
    state.scan_total=static_cast<uint32_t>(names.size()); Publish();
    std::map<std::string,std::string> used_labels;
    for(const auto& entry:names) {
        if(!StorageAvailable()) { state.storage_ok=false; Error("应用包扫描中断，TF 卡不可用"); return; }
        Package p{}; p.image_path=entry.second;
        PackageView row; std::string error;
        p.valid=Validate(&p,&error,false);
        row.name=p.manifest.name.empty()?entry.first:p.manifest.name;
        row.version=p.manifest.version; row.id=p.manifest.id;
        row.description=p.manifest.description;
        row.storage_mode=p.manifest.storage_mode;
        row.exit_method=p.manifest.exit_method;
        row.exit_hint=p.manifest.exit_hint;
        if(p.valid) {
            auto used=used_labels.find(row.id);
            if(used==used_labels.end()) used=used_labels.emplace(row.id,LastUsedLabel(row.id)).first;
            row.last_used=used->second;
        }
        row.compatible=p.valid && layout_ok && resources_ok;
        row.detail=p.valid ? "兼容格式；切换前完成镜像校验" : "拒绝: "+error;
        if(!layout_ok) row.detail="当前分区不符，禁止切换";
        packages.push_back(p); state.packages.push_back(row);
        ++state.scan_done;
        Publish();
    }
    if(!StorageAvailable()) { state.storage_ok=false; Error("应用包扫描中断，TF 卡不可用"); return; }
    state.storage_ok=true;
    state.scan_running=false; state.scan_complete=true;
    state.status=names.empty()?"尚无应用包；通过模拟 U 盘复制到专用目录":"应用包扫描完成（最多显示 128 个）";
    Publish();
}

bool LoadWifiStorage() {
    std::string error;
    if (!StorageAvailable() || !InitializeSharedWifi(std::string(ROOT)+"/shared", &error)) {
        state.wifi_ready=false;
        state.status="公共网络暂不可用，应用切换仍按存档交接处理";
        return false;
    }
    return LoadWifiView();
}
void WifiNotice(const char* text) {
    state.status=text; Publish();
}
void WifiShareWarning(const char* text) {
    if(state.error.empty()) state.error=text;
    else state.error+="；"+std::string(text);
    Publish();
}
bool ConfirmWifiResult(const WifiOffer& offer, const char* value) {
    const std::string dir=StatusDirectory();
    std::string error, actual;
    if(ReadWifiResult(dir,offer,&actual,&error) &&
       (actual==value || WriteWifiResult(dir,offer,value,&error) ||
        (ReadWifiResult(dir,offer,&actual,&error) && actual==value))) return true;
    WifiShareWarning("应用网络共享结果未确认，请检查 TF 卡");
    return false;
}
void CancelCandidate(bool disconnect) {
    if (!candidate_token) return;
    if(state.storage_ok && StorageAvailable()) ConfirmWifiResult(active_offer,"cancelled");
    else WifiShareWarning("TF 卡不可用，本次应用网络未共享");
    candidate_token=0;
    active_offer.password.clear();
    if(disconnect) RequestWifiDisconnect();
}
void StartReturnedWifi(const RunContext& run, HandoffProtocol protocol) {
    if(protocol==HandoffProtocol::Unknown) return;
    if(candidate_token) return;
    const std::string dir=std::string(ROOT)+"/users/"+user_id+"/apps/"+run.app_id+"/_pocket";
    struct stat st{};
    if(stat(dir.c_str(),&st)!=0) { if(errno!=ENOENT) WifiNotice("应用已返回，本次网络配置未共享"); return; }
    const auto record=RecordStore(dir).Load(protocol==HandoffProtocol::Standard10?"wifi_offer":"wifi_offer107",1);
    if(record.status==RecordStatus::Missing) return;
    WifiOffer offer;
    const bool decoded=protocol==HandoffProtocol::Standard10 ? standard::DecodeOffer(record,&offer) : DecodeWifiOffer(record,&offer);
    if(!decoded) { WifiNotice("应用已返回，网络候选不可确认，未更改公共配置"); return; }
    if(offer.run_id!=run.run_id) return;
    std::string previous,error;
    if(!ReadWifiResult(StatusDirectory(),offer,&previous,&error)) { WifiNotice("应用已返回，本次网络配置未共享"); return; }
    if(!previous.empty() && previous!="processing") return;
    std::vector<WifiNetwork> saved;
    if(!ReadSharedWifi(&saved,&error)) { WifiNotice("应用已返回，公共网络暂不可用"); return; }
    const bool duplicate=!saved.empty() && saved.back().ssid==offer.ssid && saved.back().password==offer.password;
    if(previous=="processing" || duplicate) {
        const char* result=duplicate?(previous=="processing"?"accepted":"duplicate"):"failed";
        ConfirmWifiResult(offer,result);
        const auto current=WifiConnectionSnapshot();
        if(!saved.empty() && current.ready &&
           !((current.connected || current.connecting) && current.ssid==saved.back().ssid))
            RequestWifiConnect(saved.back().ssid);
        return;
    }
    if(!ConfirmWifiResult(offer,"processing")) return;
    // Defer startup auto-connect until the handoff is known. A new offer
    // takes the first radio attempt; ordinary boots keep the saved list order.
    StartWifiConnection(false);
    fallback_ssid=saved.empty()?"":saved.back().ssid;
    active_offer=std::move(offer);
    candidate_token=RequestWifiCandidate(active_offer.ssid,active_offer.password);
    if(!candidate_token) {
        ConfirmWifiResult(active_offer,"failed");
        active_offer.password.clear();
        if(!fallback_ssid.empty()) RequestWifiConnect(fallback_ssid);
        WifiNotice("新网络暂不可用，继续使用原网络");
    } else WifiNotice("正在验证应用推荐的网络，可继续使用口袋");
}
void PollCandidate() {
    if(!candidate_token) return;
    if(!state.storage_ok || !StorageAvailable()) { CancelCandidate(); return; }
    const auto radio=WifiConnectionSnapshot();
    if(radio.candidate_token!=candidate_token || !radio.candidate_done) return;
    std::string error;
    bool accepted=false, persistence_known=true;
    std::vector<WifiNetwork> previous;
    if(radio.candidate_connected && radio.connected && !radio.ip.empty()) {
        persistence_known=ReadSharedWifi(&previous,&error);
        if(persistence_known) {
            fallback_ssid=previous.empty()?"":previous.back().ssid;
            accepted=SaveSharedWifi(active_offer.ssid,active_offer.password,&error);
        }
        if(persistence_known && !accepted) {
            // A failed readback can follow a successful physical commit. Base
            // adoption on the reloaded authoritative record, not the error alone.
            std::string reload_error;
            std::vector<WifiNetwork> reloaded;
            persistence_known=InitializeSharedWifi(std::string(ROOT)+"/shared",&reload_error) &&
                              ReadSharedWifi(&reloaded,&reload_error);
            if(persistence_known) {
                accepted=!reloaded.empty() && reloaded.back().ssid==active_offer.ssid &&
                         reloaded.back().password==active_offer.password;
                if(!accepted) fallback_ssid=reloaded.empty()?"":reloaded.back().ssid;
            }
        }
    }
    if(persistence_known && !ConfirmWifiResult(active_offer,accepted?"accepted":"failed") && accepted) {
        // The public configuration is written before the final result. If the
        // result definitely did not commit, restore the whole previous list.
        // When readback itself fails, let the processing record be reconciled
        // against the authoritative configuration on the next healthy read.
        std::string observed;
        persistence_known=ReadWifiResult(StatusDirectory(),active_offer,&observed,&error) &&
            (observed=="accepted" ||
             (observed=="processing" &&
              RestoreSharedWifi(previous,{active_offer.ssid,active_offer.password},&error)));
        if(persistence_known && observed=="processing") {
            accepted=false;
            ConfirmWifiResult(active_offer,"failed");
        }
    }
    if(persistence_known && accepted && !AcceptWifiCandidate(candidate_token))
        RequestWifiConnect(active_offer.ssid);
    // If uncertain, leave processing on TF for deterministic re-check after
    // refresh/reboot; do not report a successful rollback or overwrite again.
    candidate_token=0; active_offer.password.clear();
    LoadWifiView();
    if(!persistence_known) {
        RequestWifiDisconnect();
        WifiNotice("网络配置保存结果未确认，请刷新后重新连接");
    } else if(accepted) WifiNotice("应用推荐的网络已连接并保存");
    else {
        if(!fallback_ssid.empty()) RequestWifiConnect(fallback_ssid); else RequestWifiDisconnect();
        WifiNotice("新网络未采用，已尝试原网络；仍未连接时请手动配网");
    }
}
bool ReadResumePackage(const RunContext& run, PackageView* output) {
    const auto* target=Slot(ESP_PARTITION_SUBTYPE_APP_OTA_1,APP_ADDRESS);
    std::string sha;
    // The digest binds these display strings to the image already validated
    // before installation. Never render unchecked bytes from damaged Flash.
    if(!PartitionHash(target,run.image_bytes,&sha) || sha!=run.image_sha256) return false;
    CompactMetadata meta{};
    if(esp_partition_read(target,kCompactMetadataOffset,&meta,sizeof(meta))!=ESP_OK ||
       memcmp(meta.magic,kPocketAbiMagic,sizeof(meta.magic)) || meta.flags!=kPocketApplicationFlag ||
       meta.abi_major!=1 || meta.abi_minor!=0 || meta.header_bytes!=sizeof(meta) ||
       strncmp(meta.target,kTargetId,sizeof(meta.target)) ||
       strncmp(meta.layout_profile,kLayoutId,sizeof(meta.layout_profile)) ||
       meta.exit_method<1 || meta.exit_method>6 || meta.storage_mode!=run.storage_mode ||
       meta.state_schema!=run.state_schema) return false;
    const auto text=[](const char* bytes,size_t size,std::string* value) {
        const auto* end=static_cast<const char*>(memchr(bytes,0,size));
        if(!end || end==bytes) return false;
        value->assign(bytes,static_cast<size_t>(end-bytes)); return true;
    };
    PackageView result;
    if(!text(meta.app_id,sizeof(meta.app_id),&result.id) || result.id!=run.app_id ||
       !text(meta.version,sizeof(meta.version),&result.version) || result.version!=run.version ||
       !text(meta.name,sizeof(meta.name),&result.name) ||
       !text(meta.exit_hint,sizeof(meta.exit_hint),&result.exit_hint)) return false;
    result.exit_method=meta.exit_method; result.storage_mode=meta.storage_mode; result.compatible=true;
    *output=std::move(result); return true;
}
// Recovery records belong to the manager, never to the application's TXT,
// checkpoint or private files. Only an exact failed image is quarantined.
void ApplyRecoveryRows(const RunContext* pending = nullptr) {
    for(size_t i=0;i<packages.size() && i<state.packages.size();++i) {
        auto& package=packages[i]; auto& row=state.packages[i];
        row.restart_allowed=false; row.restart_run_id.clear(); row.restart_image_sha256.clear();
        if(!package.valid || !layout_ok || !resources_ok) continue;
        row.compatible=true; row.detail="兼容格式；切换前完成镜像校验";
        RunContext isolated; std::string error;
        const auto result=LoadIsolated(RecoveryDirectory(),row.id,row.version,&isolated,&error);
        if(result!=RecordStatus::Missing && result!=RecordStatus::Ok) {
            row.compatible=false; row.detail="本应用隔离记录不可读取，请检查 TF 卡；其他应用可继续使用";
            continue;
        }
        const RunContext* failed=result==RecordStatus::Ok ? &isolated : nullptr;
        if(pending && pending->app_id==row.id && pending->version==row.version) failed=pending;
        if(!failed) continue;
        // Ordinary list entries still use the cheap header probe. Hash only
        // entries with a matching fault ID/version before deciding isolation.
        if(!Validate(&package,&error)) {
            row.compatible=false; row.detail="镜像校验未通过："+error; continue;
        }
        if(failed->user_id!=user_id) {
            row.compatible=false; row.detail="本应用隔离记录身份不符，请检查 TF 卡"; continue;
        }
        if(failed->image_sha256!=package.manifest.sha256 || failed->image_bytes!=package.manifest.size)
            continue;  // Replaced image of the same version may be repaired.
        row.compatible=false;
        row.restart_allowed=true; row.restart_run_id=failed->run_id;
        row.restart_image_sha256=failed->image_sha256;
        row.detail=pending && failed==pending ?
            "上次运行未完成。可恢复应用并保存返回，也可在此解除限制并重新启动。已保存的 TF 文件保留。" :
            "上次运行未完成，这份应用已单独限制。可在此确认解除限制并重新启动；未保存进度可能丢失，已保存的 TF 文件保留。";
    }
}
void CheckManagerHandoff(bool offer_wifi) {
    state.unfinished_checkpoint=false;
    if(!state.manager || !state.storage_ok || !StorageAvailable()) return;
    if(!Directory(std::string(ROOT)+"/recovery") || !Directory(RecoveryDirectory())) {
        state.handoff_blocked=true; state.resume_available=false;
        state.error="无法建立应用隔离记录目录，请检查 TF 卡";
        Publish(); return;
    }
    auto h=InspectHandoff(StatusDirectory(),user_id);
    state.unfinished_checkpoint=!h.saved && h.run.storage_mode==1 &&
        (h.state==HandoffState::Unfinished || h.state==HandoffState::Closed);
    if(h.state==HandoffState::Closed && !h.saved) {
        // closed may originate in recovery. Its archive, not the word closed,
        // must prove that explicit recovery disposition protected the old run.
        std::string error;
        if(!IsolateUnfinished(StatusDirectory(),RecoveryDirectory(),user_id,&error)) {
            state.handoff_blocked=true; state.resume_available=false;
            state.error="异常结束的交接证据未确认，保留应用区域："+error;
            Publish(); return;
        }
    }
    state.handoff_blocked=!h.may_replace();
    state.resume_available=false; state.resume_run_id.clear(); state.resume_package=PackageView{};
    if(h.state==HandoffState::Unfinished && ReadResumePackage(h.run,&state.resume_package)) {
        state.resume_available=true; state.resume_run_id=h.run.run_id;
        // A recoverable previous application is not a global installation lock.
        // It remains intact until the user confirms switching to another app.
        state.handoff_blocked=false;
    } else if(h.state==HandoffState::Unfinished) {
        std::string error;
        if(IsolateUnfinished(StatusDirectory(),RecoveryDirectory(),user_id,&error)) {
            state.handoff_blocked=false; state.error.clear();
            state.status="上次异常应用已单独隔离，其他应用可正常切换";
            ESP_LOGW(TAG,"HANDOFF_ISOLATED app=%s version=%s",h.run.app_id.c_str(),h.run.version.c_str());
        } else {
            state.error="交接故障记录无法保存，请检查 TF 卡："+error;
            Publish(); return;
        }
    }
    if(h.state==HandoffState::Returned) {
        std::string error;
        h.run.phase="closed";
        if(!SaveRun(StatusDirectory(),h.run,&error)) {
            state.handoff_blocked=true; state.resume_available=false;
            state.error="返回登记未完成，保留应用区域，请重新检查"; Publish(); return;
        }
        state.status="上次应用已完成保存交接";
    }
    ApplyRecoveryRows(state.resume_available ? &h.run : nullptr);
    if(state.handoff_blocked) { state.error=h.error; state.status="交接控制记录不可读取，请检查 TF 卡"; }
    else if(state.resume_available) {
        state.error.clear(); state.status="上次应用未完成返回，可恢复该应用或切换其他应用";
    }
    else if(offer_wifi && h.saved &&
            (h.state==HandoffState::Returned || h.state==HandoffState::Closed)) StartReturnedWifi(h.run,h.protocol);
    Publish();
}
struct FlashDisplayScope {
    bool acquired = false;
    ~FlashDisplayScope() { if(acquired) pocket_hal::EndFlashWrite(); }
};
void ResumeApplication() {
    if(!LoadIdentity() || !layout_ok || !ManagerPresent()) { Error("当前不能恢复应用"); return; }
    const auto h=InspectHandoff(StatusDirectory(),user_id);
    if(h.state!=HandoffState::Unfinished) { Error("没有需要恢复的未完成应用"); return; }
    PackageView resume;
    if(h.run.run_id!=state.resume_run_id || !ReadResumePackage(h.run,&resume) ||
       resume.id!=state.resume_package.id || resume.version!=state.resume_package.version ||
       resume.exit_hint!=state.resume_package.exit_hint || resume.exit_method!=state.resume_package.exit_method) {
        Error("原应用镜像无法校验，已保留区域和资料，请恢复对应 BIN"); return;
    }
    const auto* target=Slot(ESP_PARTITION_SUBTYPE_APP_OTA_1,APP_ADDRESS);
    CancelCandidate();
    FlashDisplayScope display_scope;
    const uint32_t presentation = pocket_hal::RequestSwitchPresentation();
    state.status="正在恢复上次应用"; Publish();
    display_scope.acquired = pocket_hal::BeginFlashWrite(presentation,10000);
    if(!display_scope.acquired) {
        Error("恢复提示页未完成刷新，未修改启动目标，请重试"); return;
    }
    // Repair a partially published close before handing control to an app.
    // Both old and standard clients must observe the same active transaction.
    std::string resume_error;
    if(!SaveRun(StatusDirectory(),h.run,&resume_error)) {
        Error("恢复交接记录未能确认，未修改启动目标，请重试"); return;
    }
    if(esp_ota_set_boot_partition(target)!=ESP_OK) { Error("无法恢复启动，资料保持不变"); return; }
    state.status="正在恢复上次应用"; Publish(); vTaskDelay(pdMS_TO_TICKS(300)); esp_restart();
}
void Install(int index, const Request* restart = nullptr) {
    if(!CheckStartSpace()) return;
    const auto* running=esp_ota_get_running_partition();
    if(!state.manager || !layout_ok || !resources_ok || !running || running->address!=MANAGER_ADDRESS ||
       index<0 || static_cast<size_t>(index)>=packages.size() || !LoadIdentity()) { Error("当前环境不允许切换"); return; }
    if(state.state_blocked || !state.storage_ok || !StorageAvailable()) {
        Error("当前 TF 状态不能确认，未解除限制或写入应用"); return;
    }
    Package p=packages[index]; std::string error;
    state.status="正在校验应用，请稍候"; Publish();
    if(!Validate(&p,&error)) { Error(error); return; }
    CheckManagerHandoff();
    if(state.handoff_blocked) { Error("上次保存交接尚未确认，未覆盖应用区域"); return; }
    if(static_cast<size_t>(index)>=state.packages.size() ||
       (!restart && !state.packages[index].compatible)) {
        Error(static_cast<size_t>(index)<state.packages.size() ? state.packages[index].detail : "应用列表已变化，请刷新后重试");
        return;
    }
    RunContext retry_run;
    if(restart) {
        const auto& row=state.packages[index];
        if(!row.restart_allowed || row.compatible || row.id!=restart->restart_app ||
           row.version!=restart->restart_version || row.restart_run_id!=restart->restart_run ||
           row.restart_image_sha256!=restart->restart_sha ||
           p.manifest.id!=restart->restart_app || p.manifest.version!=restart->restart_version ||
           p.manifest.sha256!=restart->restart_sha) {
            Error("应用或运行记录已变化，请重新查看原因后确认"); return;
        }
        const auto pending=InspectHandoff(StatusDirectory(),user_id);
        if(pending.state==HandoffState::Unfinished && pending.run.run_id==restart->restart_run)
            retry_run=pending.run;
        else if(LoadIsolated(RecoveryDirectory(),row.id,row.version,&retry_run,&error)!=RecordStatus::Ok) {
            Error("原限制记录不能确认，请重新检查 TF 卡"); return;
        }
        if(retry_run.user_id!=user_id || retry_run.run_id!=restart->restart_run ||
           retry_run.app_id!=p.manifest.id || retry_run.version!=p.manifest.version ||
           retry_run.image_sha256!=p.manifest.sha256 || retry_run.image_bytes!=p.manifest.size ||
           retry_run.storage_mode!=p.manifest.storage_mode || retry_run.state_schema!=p.manifest.state_version) {
            Error("限制记录与所选应用不一致，未解除限制"); return;
        }
    }
    if(p.manifest.id!=packages[index].manifest.id || p.manifest.version!=packages[index].manifest.version ||
       p.manifest.storage_mode!=packages[index].manifest.storage_mode ||
       p.manifest.exit_method!=packages[index].manifest.exit_method || p.manifest.exit_hint!=packages[index].manifest.exit_hint) {
        Error("应用信息已变化，请刷新列表后重新确认"); return;
    }
    CancelCandidate();
    const auto* target=Slot(ESP_PARTITION_SUBTYPE_APP_OTA_1,APP_ADDRESS);
    if(!target || target==running || !ManagerPresent()) { Error("管理器或目标应用槽不匹配，拒绝写入"); return; }
    FILE* f=fopen(p.image_path.c_str(),"rb");
    if(!f) { Error("应用文件无法重新打开"); return; }
    if (fseek(f, static_cast<long>(p.image_offset), SEEK_SET) != 0) {
        fclose(f); Error("无法定位 BIN 中的应用区域，未写入 Flash"); return;
    }
    uint8_t random[16]; esp_fill_random(random,sizeof(random)); char run_id[33]{};
    for(size_t i=0;i<sizeof(random);++i) snprintf(run_id+i*2,3,"%02x",random[i]);
    RunContext run;
    run.run_id=run_id; run.user_id=user_id; run.app_id=p.manifest.id; run.version=p.manifest.version;
    run.image_sha256=p.manifest.sha256; run.image_bytes=p.manifest.size;
    run.storage_mode=p.manifest.storage_mode; run.state_schema=p.manifest.state_version; run.phase="prepared";
    FlashDisplayScope display_scope;
    // The UI owns LVGL. Ask it to present the opaque switch page, wait for
    // that physical frame, then retain the panel gate until failure or reboot.
    const uint32_t presentation = pocket_hal::RequestSwitchPresentation();
    state.status="正在切换应用，请保持供电"; Publish();
    display_scope.acquired = pocket_hal::BeginFlashWrite(presentation,10000);
    if(!display_scope.acquired) {
        fclose(f); Error("切换提示页未完成刷新，未写入 Flash，请重试"); return;
    }
    // Archive the abandoned control records before closing the old run. An
    // explicit retry releases only the failure the user actually confirmed.
    const auto prior=InspectHandoff(StatusDirectory(),user_id);
    if(prior.state==HandoffState::Unfinished &&
       !IsolateUnfinished(StatusDirectory(),RecoveryDirectory(),user_id,&error)) {
        fclose(f); Error("无法归档上次运行，未覆盖应用区域："+error); return;
    }
    if(restart && !ReleaseIsolated(RecoveryDirectory(),retry_run,&error)) {
        fclose(f); CheckManagerHandoff();
        Error("解除限制未完成，未重新启动："+error); return;
    }
    if(!SaveRun(StatusDirectory(),run,&error)) { fclose(f); Error("不能确认切换事务，未写入 Flash"); return; }
    ESP_LOGI(TAG,"INSTALL_BEGIN id=%s version=%s target=0x%lx size=%lu",p.manifest.id.c_str(),p.manifest.version.c_str(),
             static_cast<unsigned long>(target->address),static_cast<unsigned long>(p.manifest.size));
    esp_ota_handle_t handle=0;
    esp_err_t err=esp_ota_begin(target,p.manifest.size,&handle);
    if(err!=ESP_OK) { fclose(f); Error(std::string("开始切换失败: ")+esp_err_to_name(err)); return; }
    Sha digest; std::array<unsigned char,2048> block{}; uint32_t total=0;
    while(total<p.manifest.size && err==ESP_OK) {
        size_t n=std::min<uint32_t>(block.size(),p.manifest.size-total);
        if(fread(block.data(),1,n,f)!=n) { err=ESP_FAIL; break; }
        digest.Add(block.data(),n); err=esp_ota_write(handle,block.data(),n); total+=n;
        YieldChunk(total);
        if(test_reset_install && total>=262144) {
            ESP_LOGW(TAG,"TEST_RESET_DURING_INSTALL bytes=%lu",static_cast<unsigned long>(total));
            vTaskDelay(pdMS_TO_TICKS(100)); esp_restart();
        }
    }
    if(ferror(f) || fgetc(f)!=EOF) err=ESP_FAIL;
    if(fclose(f)!=0) err=ESP_FAIL;
    if(Hex(digest.Finish())!=p.manifest.sha256 || !digest.valid) err=ESP_FAIL;
    if(err!=ESP_OK) { esp_ota_abort(handle); Error("写入或二次校验失败，保持管理器启动"); return; }
    err=esp_ota_end(handle);
    if(err!=ESP_OK) { Error(std::string("应用镜像验证失败: ")+esp_err_to_name(err)); return; }
    std::string readback;
    if(!PartitionHash(target,p.manifest.size,&readback) || readback!=p.manifest.sha256) { Error("Flash 读回校验失败，未切换启动目标"); return; }
    run.phase="active";
    if(!SaveRun(StatusDirectory(),run,&error)) { Error("切换登记未完成，未切换启动目标"); return; }
    err=esp_ota_set_boot_partition(target);
    if(err!=ESP_OK) { Error(std::string("选择启动应用失败: ")+esp_err_to_name(err)); return; }
    ESP_LOGI(TAG,"INSTALL_VERIFIED id=%s sha256=%s",p.manifest.id.c_str(),p.manifest.sha256.c_str());
    state.status="切换已验证，即将启动应用"; Publish(); vTaskDelay(pdMS_TO_TICKS(300)); esp_restart();
}
void Return() {
    if(!SaveState()) return;
    if(state.manager) { state.status="当前已在固件口袋"; return; }
    if(!state.integrated) { state.status="已保存；独立运行，当前即应用入口"; return; }
    if(!layout_ok || !resources_ok || !ManagerPresent()) { Error("找不到匹配管理器，已保存并留在应用"); return; }
    const auto* p=Slot(ESP_PARTITION_SUBTYPE_APP_OTA_0,MANAGER_ADDRESS);
    const auto err=esp_ota_set_boot_partition(p);
    if(err!=ESP_OK) { Error(std::string("无法返回管理器: ")+esp_err_to_name(err)); return; }
    ESP_LOGI(TAG,"RETURN_SAVED id=%s target=0x%lx",POCKET_APP_ID,static_cast<unsigned long>(MANAGER_ADDRESS));
    state.status="已保存，即将返回固件口袋"; Publish(); vTaskDelay(pdMS_TO_TICKS(300)); esp_restart();
}
void ConfirmStartup() {
    if(!layout_ok || !resources_ok || (!state.manager && (!state_loaded || state.state_blocked || !state.storage_ok))) return;
    if(!MarkStarted() || state.manager) return;
    if(state.integrated) {
        auto installed=RecordStore(std::string(ROOT)+"/status").Load("installed",1);
        const std::string prefix=state.app_id+"|"+state.version+"|";
        if(installed.ok() && installed.payload.compare(0,prefix.size(),prefix)==0) {
            auto receipt=RecordStore(std::string(ROOT)+"/status").Save("booted",1,installed.payload);
            if(!receipt.ok()) { Error("启动成功，但记录启动确认失败: "+receipt.error); return; }
        }
    }
    RecordLastUsedOnce();
}
void Handle(Request request) {
    state.error.clear();
    if(request.command==Command::UnlockPin || request.command==Command::ChangePin) {
        HandlePin(request); return;
    }
    // The worker, not merely a visual overlay, enforces the manager's PIN gate.
    if(state.auth_required && request.command!=Command::Refresh && request.command!=Command::PowerOff) {
        state.pin_message="请先输入数字密码解锁"; ++state.pin_revision; return;
    }
    if(request.command==Command::PowerOff) {
        // Automatic requests may wait in the worker queue. A new physical touch
        // cancels them; manual long-press requests keep their existing meaning.
        if(request.argument==1 && !pocket_hal::IdleSleepDue()) return;
        if(pocket_hal::UsbBusy() || pocket_hal::UsbActive() || pocket_hal::UsbExported()) {
            Error("请先安全弹出并停用模拟 U 盘，再休眠"); return;
        }
        if(state.manager && !state.pin_ready) { Error("密码配置未就绪，无法进入深度休眠"); return; }
        CancelCandidate();
        if(SaveState()) {
            std::string error;
            const bool already_locked=state.auth_required;
            if(state.manager && !wake_pin.SetNeedsUnlock(true,&error)) {
                state.pin_ready=false; state.pin_message="休眠锁定保存失败，请重新检查 TF 卡";
                ++state.pin_revision; Error("锁定状态未保存，未进入休眠"); return;
            }
            shutting_down=true;
            if(!pocket_hal::PowerOff(request.argument==1)) {
                shutting_down=false;
                if(state.manager && !already_locked && !wake_pin.SetNeedsUnlock(false,&error)) {
                    state.auth_required=true; state.pin_ready=false;
                    state.pin_message="休眠未完成，请重新检查 TF 卡"; ++state.pin_revision;
                }
                Error("休眠未完成，请稍后重试");
            }
        }
        return;
    }
    if(request.command==Command::ToggleUsb) {
        if(!state.manager) { Error("仅管理器提供模拟 U 盘"); return; }
        CancelCandidate();
        DisableSharedWifiStorage();
        ConsoleDisable();
        pocket_hal::ToggleUsb();
        vTaskDelay(pdMS_TO_TICKS(200));
        for(int i=0;i<100 && pocket_hal::UsbBusy();++i) vTaskDelay(pdMS_TO_TICKS(100));
        state.usb_active=pocket_hal::UsbActive(); state.storage_ok=StorageAvailable();
        usb_seen_host=state.usb_active && pocket_hal::UsbExported();
        if(state.usb_active || pocket_hal::UsbExported() || pocket_hal::UsbBusy()) InvalidateScan();
        state.status=pocket_hal::UsbHint();
        if(!state.usb_active && state.storage_ok && !pocket_hal::UsbBusy()) {
            if(LoadIdentity()) { LoadWakePin(); LoadWifiStorage(); Scan(); CheckManagerHandoff(true); }
        }
        UpdateSpace();
        if(!state.usb_active && !pocket_hal::UsbBusy()) ConsoleEnable();
        return;
    }
    if(request.command==Command::Refresh) {
        if(pocket_hal::UsbBusy() || pocket_hal::UsbActive() || pocket_hal::UsbExported()) {
            Error("请先停用模拟 U 盘后重新检查"); return;
        }
        // The radio uses RAM only. Pause TF access during remount and retain a
        // live candidate if the same identity and shared storage re-open.
        DisableSharedWifiStorage();
        pocket_hal::UnmountTf();
        pocket_hal::MountTf();
        if(LoadIdentity()) {
            if(state.manager) LoadWakePin();
            if(state.manager) {
                if(!LoadWifiStorage()) CancelCandidate();
                Scan(); CheckManagerHandoff(true);
            }
            else if(!state.dirty) { state.state_blocked=false; LoadState(); }
            else state.status="已重新检查原卡，未保存内容保留";
            ConfirmStartup();
        } else CancelCandidate();
        UpdateSpace(); LoadWifiView();
        return;
    }
    if(request.command==Command::ResumeApplication) { ResumeApplication(); return; }
    if(request.command==Command::RestartAndLaunch) { Install(request.argument,&request); return; }
    if(request.command==Command::WifiScan) {
        CancelCandidate();
        if(!LoadWifiView()) return;
        if(!RequestWifiScan()) { Error("Wi-Fi 搜索暂未提交，请稍后重试"); return; }
        state.status="正在搜索附近的 Wi-Fi";
        return;
    }
    if(request.command==Command::WifiConnectSaved) {
        CancelCandidate();
        if(!RequestWifiConnect(request.ssid)) { Error("连接暂未提交，已保存的网络保持不变"); return; }
        state.status="正在使用已保存的密码连接 Wi-Fi";
        return;
    }
    if(request.command==Command::WifiSave || request.command==Command::WifiForget || request.command==Command::WifiRefresh) {
        CancelCandidate();
        std::string error;
        bool ok=request.command==Command::WifiRefresh ||
            (request.command==Command::WifiSave ? SaveSharedWifi(request.ssid,request.password,&error) :
                                                 ForgetSharedWifi(request.ssid,&error));
        if(!ok) { Error("公共网络配置未保存: "+error); return; }
        if(!LoadWifiView()) return;
        if(request.command==Command::WifiSave) {
            if(!RequestWifiConnect(request.ssid)) { Error("密码已保存，连接暂未提交，请稍后重试"); return; }
            state.status="密码已保存，正在连接；连接失败也会保留配置";
        } else if(request.command==Command::WifiForget) {
            const auto connection=WifiConnectionSnapshot();
            if(connection.ssid==request.ssid && !RequestWifiDisconnect()) {
                Error("网络已忘记，当前连接暂未断开，请稍后重试"); return;
            }
            state.status="已忘记此 Wi-Fi，其他应用下次读取同步更新";
        } else state.status="已更新保存的 Wi-Fi 配置";
        return;
    }
    if(!StorageAvailable()) { state.storage_ok=false; Error("TF 卡不可用或由电脑占用，请先停用模拟 U 盘"); return; }
    UpdateSpace();
    if(request.command==Command::InstallAndLaunch) Install(request.argument);
    else if(request.command==Command::ReturnToManager) Return();
    else if(request.command==Command::Save) SaveState();
    else if(request.command==Command::PreferenceNext && state.manager) {
        state.status="本版使用固定字号";
    } else if(!state.manager && state_loaded && state.storage_ok && !state.state_blocked) {
        if(!CheckStartSpace()) return;
        if(request.command==Command::Increment) state.counter=std::min(999999,state.counter+1);
        if(request.command==Command::BookmarkNext) state.bookmark=state.bookmark%9999+1;
        if(request.command==Command::NoteNext) state.note=(state.note+1)%4;
        if(request.command==Command::PreferenceNext) state.preference=1-state.preference;
        state.dirty=true; state.status="有未保存内容";
    }
}
void PrintStatus() {
    // A locked/standby screen must not leak network identity or usage history
    // through the otherwise read-only USB diagnostic channel.
    if(state.auth_required || pocket_hal::IsStandby()) {
        ESP_LOGI(TAG,"POCKET_STATUS {\"version\":\"%s\",\"auth_required\":%s,\"standby\":%s,\"ready\":%s,\"storage\":%s,\"panel_error\":%d,\"app_capacity\":%lu}",
            POCKET_VERSION,state.auth_required?"true":"false",pocket_hal::IsStandby()?"true":"false",
            state.ready?"true":"false",state.storage_ok?"true":"false",
            static_cast<int>(pocket_hal::LastRefreshError()),static_cast<unsigned long>(kAppSize));
        return;
    }
    pocket_hal::PrintInputDiagnostics();
    pocket_ime::PrintDiagnostics();
    const auto font = pocket_font::GetCacheStats();
    ESP_LOGI(TAG,"FONT_CACHE requests=%lu hits=%lu expanded=%lu uncached=%lu allocation_failures=%lu cache_bytes=%lu expand_us_total=%lu expand_us_max=%lu",
        (unsigned long)font.requests,(unsigned long)font.hits,(unsigned long)font.expanded,
        (unsigned long)font.uncached,(unsigned long)font.allocation_failures,(unsigned long)font.cache_bytes,
        (unsigned long)font.expand_us_total,(unsigned long)font.expand_us_max);
    cJSON* j=cJSON_CreateObject();
    if(!j) return;
    cJSON_AddStringToObject(j,"id",POCKET_APP_ID);
    cJSON_AddStringToObject(j,"version",POCKET_VERSION);
    cJSON_AddStringToObject(j,"user",user_id.c_str());
    cJSON_AddBoolToObject(j,"manager",state.manager);
    cJSON_AddBoolToObject(j,"integrated",state.integrated);
    cJSON_AddBoolToObject(j,"ready",state.ready);
    cJSON_AddBoolToObject(j,"auth_required",state.auth_required);
    cJSON_AddBoolToObject(j,"pin_ready",state.pin_ready);
    cJSON_AddBoolToObject(j,"pin_is_default",state.pin_is_default);
    const auto visible=Snapshot();
    cJSON_AddBoolToObject(j,"busy",state.busy || visible.busy);
    cJSON_AddBoolToObject(j,"standby",pocket_hal::IsStandby());
    cJSON_AddNumberToObject(j,"frontlight_duty",pocket_hal::FrontlightDuty());
    cJSON_AddBoolToObject(j,"switching",state.switching || visible.switching);
    cJSON_AddBoolToObject(j,"scan_running",state.scan_running);
    cJSON_AddBoolToObject(j,"scan_complete",state.scan_complete);
    cJSON_AddNumberToObject(j,"scan_total",state.scan_total);
    cJSON_AddNumberToObject(j,"scan_done",state.scan_done);
    cJSON_AddBoolToObject(j,"storage",state.storage_ok);
    cJSON_AddBoolToObject(j,"blocked",state.state_blocked);
    cJSON_AddBoolToObject(j,"handoff_blocked",state.handoff_blocked);
    cJSON_AddBoolToObject(j,"resume_available",state.resume_available);
    cJSON_AddBoolToObject(j,"dirty",state.dirty);
    cJSON_AddBoolToObject(j,"layout",layout_ok);
    cJSON_AddBoolToObject(j,"resources",resources_ok);
    cJSON_AddNumberToObject(j,"app_capacity",kAppSize);
    cJSON_AddStringToObject(j,"target",kTargetId);
    cJSON_AddBoolToObject(j,"panel_busy",pocket_hal::PanelBusy());
    cJSON_AddNumberToObject(j,"panel_refreshes",pocket_hal::RefreshCount());
    cJSON_AddNumberToObject(j,"panel_error",pocket_hal::LastRefreshError());
    cJSON_AddStringToObject(j,"package_format","FPOCKET-ABI-0001");
    cJSON_AddNumberToObject(j,"counter",state.counter);
    cJSON_AddNumberToObject(j,"bookmark",state.bookmark);
    cJSON_AddNumberToObject(j,"note",state.note);
    cJSON_AddNumberToObject(j,"preference",state.preference);
    cJSON_AddNumberToObject(j,"public_preference",state.public_preference);
    cJSON_AddNumberToObject(j,"schema",POCKET_STATE_SCHEMA);
    cJSON_AddNumberToObject(j,"tf_free_bytes",static_cast<double>(state.tf_free_bytes));
    cJSON_AddBoolToObject(j,"tf_space_known",state.tf_space_known);
    cJSON_AddBoolToObject(j,"tf_space_low",state.tf_space_low);
    cJSON_AddBoolToObject(j,"tf_space_blocked",state.tf_space_blocked);
    cJSON_AddNumberToObject(j,"battery_level",state.battery_level);
    cJSON_AddBoolToObject(j,"wifi_ready",state.wifi_ready);
    const auto connection=WifiConnectionSnapshot();
    cJSON_AddBoolToObject(j,"wifi_connected",connection.connected);
    cJSON_AddBoolToObject(j,"wifi_connecting",connection.connecting);
    cJSON_AddBoolToObject(j,"wifi_scanning",connection.scanning);
    cJSON_AddNumberToObject(j,"wifi_signal_bars",connection.signal_bars);
    cJSON_AddStringToObject(j,"wifi_ssid",connection.ssid.c_str());
    cJSON_AddStringToObject(j,"wifi_ip",connection.ip.c_str());
    cJSON_AddStringToObject(j,"wifi_message",connection.message.c_str());
    cJSON_AddNumberToObject(j,"wifi_count",state.wifi_names.size());
    cJSON_AddNumberToObject(j,"wifi_test_revision",wifi_test_revision);
    cJSON_AddStringToObject(j,"error",state.error.c_str());
    cJSON_AddStringToObject(j,"status",state.status.c_str());
    cJSON* rows=cJSON_AddArrayToObject(j,"packages");
    for(size_t i=0;i<state.packages.size();++i) {
        const auto& p=state.packages[i]; cJSON* r=cJSON_CreateObject();
        cJSON_AddNumberToObject(r,"index",i); cJSON_AddStringToObject(r,"id",p.id.c_str());
        cJSON_AddStringToObject(r,"name",p.name.c_str()); cJSON_AddStringToObject(r,"version",p.version.c_str());
        cJSON_AddStringToObject(r,"description",p.description.c_str()); cJSON_AddStringToObject(r,"last_used",p.last_used.c_str());
        cJSON_AddNumberToObject(r,"storage_mode",p.storage_mode);
        cJSON_AddNumberToObject(r,"exit_method",p.exit_method);
        cJSON_AddStringToObject(r,"exit_hint",p.exit_hint.c_str());
        cJSON_AddBoolToObject(r,"compatible",p.compatible); cJSON_AddStringToObject(r,"detail",p.detail.c_str());
        cJSON_AddItemToArray(rows,r);
    }
    char* text=cJSON_PrintUnformatted(j);
    if(text) { ESP_LOGI(TAG,"POCKET_STATUS %s",text); cJSON_free(text); }
    cJSON_Delete(j);
}
void PollConsole() {
    if(!usb_serial_jtag_is_driver_installed()) return;
    char bytes[64]; const int count=usb_serial_jtag_read_bytes(bytes,sizeof(bytes),0);
    for(int i=0;i<count;++i) {
        const char c=bytes[i];
        if(c=='\r') continue;
        if(c!='\n') { if(console_line.size()<120) console_line+=c; else console_line.clear(); continue; }
        std::string line=console_line; console_line.clear();
        if(line.compare(0,7,"pocket ")!=0) continue;
        line.erase(0,7);
        if(line=="status" || line=="list") { PrintStatus(); continue; }
#if POCKET_INTERNAL_DIAGNOSTICS
        if(state.auth_required) { ESP_LOGW(TAG,"Manager locked; diagnostic mutations disabled"); continue; }
        // Fixed, non-secret fixture only. No generic credential console command.
        if(line=="wifi-test-add") { PostWifiSave(kWifiTestSsid,"pocket-test-one"); continue; }
        if(line=="wifi-test-update") { PostWifiSave(kWifiTestSsid,"pocket-test-two"); continue; }
        if(line=="wifi-test-remove") { PostWifiForget(kWifiTestSsid); continue; }
        if(line=="test-save-fail-on") { test_fail_save=true; PrintStatus(); continue; }
        if(line=="test-save-fail-off") { test_fail_save=false; PrintStatus(); continue; }
        if(line=="test-reset-install") { test_reset_install=true; PrintStatus(); continue; }
        if(line=="test-next-boot-fail" && state.manager && LoadIdentity()) {
            auto saved=RecordStore(std::string(ROOT)+"/status").Save("testboot",1,"fail-once");
            if(!saved.ok()) Error("无法准备启动失败测试: "+saved.error);
            PrintStatus(); continue;
        }
        if(line=="test-crash") { ESP_LOGW(TAG,"TEST_CRASH_AFTER_CONFIRM"); vTaskDelay(pdMS_TO_TICKS(100)); abort(); }
        Request r{Command::Refresh,0}; bool valid=true;
        if(line=="refresh") r.command=Command::Refresh;
        else if(line=="scan") r.command=Command::WifiScan;
        else if(line=="inc") r.command=Command::Increment;
        else if(line=="bookmark") r.command=Command::BookmarkNext;
        else if(line=="note") r.command=Command::NoteNext;
        else if(line=="pref") r.command=Command::PreferenceNext;
        else if(line=="save") r.command=Command::Save;
        else if(line=="return") r.command=Command::ReturnToManager;
        else if(line=="usb") r.command=Command::ToggleUsb;
        else if(line=="resume") r.command=Command::ResumeApplication;
        else if(line.compare(0,8,"install ")==0) {
            int consumed=0;
            valid=sscanf(line.c_str(),"install %d%n",&r.argument,&consumed)==1 && consumed==static_cast<int>(line.size());
            r.command=Command::InstallAndLaunch;
        } else valid=false;
        if(valid) {
            if(!Post(r.command,r.argument)) ESP_LOGW(TAG,"POCKET_BUSY command was not queued");
        } else ESP_LOGW(TAG,"Unknown internal diagnostic command");
#else
        ESP_LOGW(TAG,"Release console is read-only; use the device screen");
#endif
    }
}
void Worker(void*) {
    state.manager=POCKET_ROLE_MANAGER;
    state.app_id=POCKET_APP_ID; state.version=POCKET_VERSION;
    state.title=state.manager?"固件口袋":state.app_id=="pocket_counter"?"计数器":"随手书签";
    state.status="检查布局和用户记录"; Publish();
    PollBattery(true);
    ConsoleEnable();
    layout_ok=CheckLayout(); resources_ok=true; // Every BIN owns its fonts and resources.
    const auto* running=esp_ota_get_running_partition();
    state.integrated=!state.manager && running && running->address==APP_ADDRESS && ManagerPresent() && layout_ok && resources_ok;
    bool initialized=LoadIdentity();
    if(state.manager) LoadWakePin();
    UpdateSpace(); if(initialized) LoadWifiStorage();
    if(initialized && !state.manager) initialized=LoadState();
#if POCKET_INTERNAL_DIAGNOSTICS
    if(initialized && state.integrated) {
        RecordStore teststore(std::string(ROOT)+"/status");
        auto test=teststore.Load("testboot",1);
        if(test.ok() && test.payload=="fail-once" && teststore.Save("testboot",1,"consumed").ok()) {
            ESP_LOGW(TAG,"TEST_CRASH_BEFORE_CONFIRM"); vTaskDelay(pdMS_TO_TICKS(100)); abort();
        }
    }
#endif
    if(!layout_ok || !resources_ok) { Error("分区不匹配，切换/集成返回已禁用"); initialized=false; }
    if(state.manager) {
        // A usable maintenance UI is sufficient to confirm the fixed manager;
        // a missing card must not cause the only manager to be rolled back.
        ConfirmStartup();
        if(initialized) { Scan(); CheckManagerHandoff(true); }
    } else if(initialized) ConfirmStartup();
    StartWifiConnection();
    state.ready=true; state.busy=false; Publish();
    ESP_LOGI(TAG,"READY role=%s id=%s mode=%s storage=%d",state.manager?"manager":"application",POCKET_APP_ID,state.integrated?"integrated":"standalone",state.storage_ok);
    PrintStatus();
    Request request{};
    for(;;) {
        if(xQueueReceive(queue,&request,pdMS_TO_TICKS(200))==pdTRUE) {
            const int completed_command=static_cast<int>(request.command);
            state.busy=true; state.switching=IsSwitchCommand(request.command); state.error.clear();
            if(state.switching) state.status=SwitchStatus(request.command);
            Publish(); Handle(request);
            if(request.command==Command::RestartAndLaunch && StorageAvailable()) {
                // A release can succeed even when a later write fails. Reflect
                // the real control state immediately, without a manual refresh.
                const std::string failure=state.error;
                CheckManagerHandoff();
                if(!failure.empty()) {
                    if(state.error.empty() || state.error==failure) state.error=failure;
                    else state.error=failure+"；"+state.error;
                }
            }
            // Requests contain transient credentials; never retain them in the queue loop.
            ClearRequestSecrets(request);
            // Successful install/return restarts and never reaches this line.
            // Every failure or harmless no-op restores the ordinary screen.
            state.switching=false; state.busy=shutting_down; Publish();
            if(!state.usb_active) { ESP_LOGI(TAG,"POCKET_DONE command=%d",completed_command); PrintStatus(); }
        }
        if(!shutting_down) { PollCandidate(); PollWifiConnection(); PollBattery(); PollConsole(); }
        // Once Windows has safely ejected the card and TinyUSB has handed the
        // filesystem back, restore USB serial without asking for a screen tap.
        if(state.usb_active && !pocket_hal::UsbBusy()) {
            if(pocket_hal::UsbExported()) usb_seen_host=true;
            else if(usb_seen_host && Post(Command::ToggleUsb)) usb_seen_host=false;
        }
    }
}
}
View Snapshot() { std::lock_guard<std::mutex> lock(view_mutex); return cached; }
bool Submit(Request request) {
    if(!queue) return false;
    std::string previous_status;
    { std::lock_guard<std::mutex> lock(view_mutex); if(cached.busy) return false;
      if(cached.auth_required && request.command!=Command::UnlockPin &&
         request.command!=Command::Refresh && request.command!=Command::PowerOff) return false;
      previous_status=cached.status; cached.busy=true; cached.switching=IsSwitchCommand(request.command);
      if(cached.switching) { cached.status=SwitchStatus(request.command); cached.error.clear(); }
      ++cached.revision; }
    if(xQueueSend(queue,&request,0)==pdTRUE) { ClearRequestSecrets(request); return true; }
    ClearRequestSecrets(request);
    { std::lock_guard<std::mutex> lock(view_mutex); cached.busy=false; cached.switching=false;
      cached.status=previous_status; ++cached.revision; }
    return false;
}
bool Post(Command command,int argument) { return Submit(Request{command,argument}); }
bool PostRestartPackage(int index,const PackageView& expected) {
    if(index<0 || !expected.restart_allowed || expected.compatible ||
       !IsSafeIdentifier(expected.id) || expected.id.size()>=32 ||
       expected.version.empty() || expected.version.size()>=32 ||
       !ValidRunId(expected.restart_run_id) || expected.restart_image_sha256.size()!=64 ||
       expected.restart_image_sha256.find_first_not_of("0123456789abcdef")!=std::string::npos) return false;
    Request request{Command::RestartAndLaunch,index};
    memcpy(request.restart_app,expected.id.c_str(),expected.id.size()+1);
    memcpy(request.restart_version,expected.version.c_str(),expected.version.size()+1);
    memcpy(request.restart_run,expected.restart_run_id.c_str(),expected.restart_run_id.size()+1);
    memcpy(request.restart_sha,expected.restart_image_sha256.c_str(),expected.restart_image_sha256.size()+1);
    return Submit(request);
}
bool PostWifiSave(const std::string& ssid,const std::string& password) {
    if(ssid.empty() || ssid.size()>32 || password.size()>64 ||
       ssid.find('\0')!=std::string::npos || password.find('\0')!=std::string::npos) return false;
    Request request{Command::WifiSave,0};
    memcpy(request.ssid,ssid.c_str(),ssid.size()+1); memcpy(request.password,password.c_str(),password.size()+1);
    const bool accepted=Submit(request); memset(request.password,0,sizeof(request.password)); return accepted;
}
bool PostWifiForget(const std::string& ssid) {
    if(ssid.empty() || ssid.size()>32 || ssid.find('\0')!=std::string::npos) return false;
    Request request{Command::WifiForget,0}; memcpy(request.ssid,ssid.c_str(),ssid.size()+1); return Submit(request);
}
bool PostWifiConnectSaved(const std::string& ssid) {
    if(ssid.empty() || ssid.size()>32 || ssid.find('\0')!=std::string::npos) return false;
    Request request{Command::WifiConnectSaved,0};
    memcpy(request.ssid,ssid.c_str(),ssid.size()+1); return Submit(request);
}
bool PostUnlockPin(const std::string& pin) {
    if(!WakePinStore::ValidPin(pin)) return false;
    Request request{Command::UnlockPin,0};
    memcpy(request.pin,pin.c_str(),pin.size()+1);
    const bool accepted=Submit(request); ClearRequestSecrets(request); return accepted;
}
bool PostChangePin(const std::string& current,const std::string& next,const std::string& confirm) {
    if(!WakePinStore::ValidPin(current) || !WakePinStore::ValidPin(next) || !WakePinStore::ValidPin(confirm)) return false;
    Request request{Command::ChangePin,0};
    memcpy(request.pin,current.c_str(),current.size()+1);
    memcpy(request.next_pin,next.c_str(),next.size()+1);
    memcpy(request.confirm_pin,confirm.c_str(),confirm.size()+1);
    const bool accepted=Submit(request); ClearRequestSecrets(request); return accepted;
}
void Start() {
    queue=xQueueCreate(1,sizeof(Request));
    if(!queue || xTaskCreatePinnedToCoreWithCaps(Worker,"pocket_worker",24576,nullptr,3,nullptr,0,MALLOC_CAP_INTERNAL|MALLOC_CAP_8BIT)!=pdPASS) {
        state.title="固件口袋"; state.error="内部内存不足，无法启动存储任务"; state.ready=true; state.busy=false; Publish();
    }
}
}
