#include "pocket_handoff.h"
#include "pocket_standard.h"
#include <algorithm>
#include <limits>
#include <vector>

namespace pocket {
namespace {
bool Fail(std::string* error, const std::string& message) {
    if (error) *error = message;
    return false;
}
bool Hex(const std::string& s, size_t n) {
    return s.size() == n && std::all_of(s.begin(), s.end(), [](char c) {
        return (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f');
    });
}
bool Lines(const std::string& text, size_t count, std::vector<std::string>* out) {
    if (text.empty() || text.back() != '\n' || text.find('\0') != std::string::npos) return false;
    std::vector<std::string> lines;
    size_t begin = 0;
    while (begin < text.size()) {
        const auto end = text.find('\n', begin);
        if (end == std::string::npos || end == begin) return false;
        lines.push_back(text.substr(begin, end - begin)); begin = end + 1;
    }
    if (lines.size() != count) return false;
    *out = std::move(lines); return true;
}
bool Number(const std::string& s, std::uint32_t* value) {
    if (s.empty() || (s.size() > 1 && s[0] == '0')) return false;
    std::uint64_t n = 0;
    for (char c : s) {
        if (c < '0' || c > '9') return false;
        n = n * 10 + c - '0';
        if (n > std::numeric_limits<std::uint32_t>::max()) return false;
    }
    *value = static_cast<std::uint32_t>(n); return true;
}
bool Valid(const RunContext& r) {
    const bool version_ok = !r.version.empty() && r.version.size() <= 31 &&
        std::all_of(r.version.begin(), r.version.end(), [](char c) {
            return (c>='a' && c<='z') || (c>='A' && c<='Z') || (c>='0' && c<='9') ||
                   c=='.' || c=='_' || c=='+' || c=='-';
        });
    return ValidRunId(r.run_id) && IsSafeIdentifier(r.user_id) && IsSafeIdentifier(r.app_id) &&
        r.app_id != "pocket_manager" && version_ok && Hex(r.image_sha256, 64) &&
        r.image_bytes > 800 && r.image_bytes <= kAppSize && r.storage_mode <= 2 &&
        (r.storage_mode == 0 ? r.state_schema == 0 : r.state_schema > 0 && r.state_schema <= 0x7fffffffU) &&
        (r.phase == "prepared" || r.phase == "active" || r.phase == "closed");
}
std::string Receipt(const RunContext& r, bool saved) {
    return "FPRECEIPT1\n" + r.run_id + "\n" + r.user_id + "\n" + r.app_id + "\n" +
           (saved ? "saved\n" : "started\n");
}
bool WifiValid(const WifiOffer& o) {
    return ValidRunId(o.run_id) && !o.ssid.empty() && o.ssid.size() <= 32 && o.password.size() <= 64 &&
           o.ssid.find('\0') == std::string::npos && o.password.find('\0') == std::string::npos;
}
bool ResultValid(const std::string& r) {
    return r == "processing" || r == "accepted" || r == "failed" || r == "duplicate" || r == "cancelled";
}
bool LegacyReceipt(const std::string& payload, standard::Receipt* output) {
    std::vector<std::string> f;
    if (!output || !Lines(payload, 5, &f) || f[0] != "FPRECEIPT1" ||
        !ValidRunId(f[1]) || !IsSafeIdentifier(f[2]) || !IsSafeIdentifier(f[3]) ||
        f[3] == "pocket_manager" || (f[4] != "started" && f[4] != "saved")) return false;
    *output = {f[1], f[2], f[3], f[4]};
    return true;
}
void InspectReceipts(const std::string& dir, HandoffView* view) {
    const RecordStore store(dir);
    standard::Receipt legacy, modern;
    const auto old = store.LoadConfirmed("receipt107", 1);
    const auto current = store.Load("receipt", 1);
    const bool old_matches = old.ok() && old.schema == 1 && LegacyReceipt(old.payload, &legacy) &&
                             standard::Matches(legacy, view->run);
    const bool new_receipt_matches = current.ok() && current.schema == 1 &&
        standard::DecodeReceipt(current.payload, &modern) && standard::Matches(modern, view->run);
    // A standard receipt belongs to the public transaction actually offered to
    // that application. A historic receipt in either channel cannot authorize
    // a different image/run. Internal image length/schema stay in run107.
    RecordResult previous_public;
    const auto public_record = store.Load("run", 1, &previous_public);
    standard::Run public_run;
    const bool public_decoded = public_record.ok() && public_record.schema == 1 &&
        standard::DecodeRun(public_record.payload, &public_run);
    bool public_matches = public_decoded && standard::Matches(public_run, view->run);
    bool prepared_overlaid_close = false;
    // Closing publishes the public view first. If power fails before run107
    // commits, a real saved receipt still proves this exact run was saved;
    // let the manager finish closing rather than resume an already saved app.
    if (!public_matches && public_decoded && new_receipt_matches && modern.phase == "saved" &&
        view->run.phase == "active" && public_run.phase == "closed") {
        auto closed = view->run;
        closed.phase = "closed";
        public_matches = standard::Matches(public_run, closed);
    }
    // Publishing a new prepared run precedes its private copies and any Flash
    // write. If it was interrupted there, the previous confirmed private close
    // may still be proved by the immediately preceding public close and receipt.
    if (!public_matches && public_decoded && new_receipt_matches && modern.phase == "saved" &&
        view->run.phase == "closed" && public_run.phase == "prepared" &&
        public_run.user_id == view->run.user_id && public_run.run_id != view->run.run_id &&
        previous_public.ok() && previous_public.schema == 1 &&
        public_record.generation - previous_public.generation == 1) {
        standard::Run previous;
        prepared_overlaid_close = standard::DecodeRun(previous_public.payload, &previous) &&
                                 standard::Matches(previous, view->run);
        public_matches = prepared_overlaid_close;
    }
    const bool new_matches = new_receipt_matches && public_matches;
    if (old_matches && new_receipt_matches && legacy.phase != modern.phase) {
        view->state = HandoffState::Invalid;
        view->error = "新旧交接回执冲突，保留原记录，请恢复应用后重试";
        return;
    }
    if (new_matches) {
        view->protocol = HandoffProtocol::Standard10;
        view->saved = modern.phase == "saved";
        if (prepared_overlaid_close) view->state = HandoffState::Returned;
    } else if (old_matches) {
        view->protocol = HandoffProtocol::Legacy107;
        view->saved = legacy.phase == "saved";
    }
}
bool InspectInterruptedRun(const std::string& dir, const std::string& user, HandoffView* view) {
    const RecordStore store(dir);
    RecordResult alternate;
    const auto newest = store.Load("run107", 1, &alternate);
    RunContext current, prior;
    if (!newest.ok() || newest.schema != 1 || !DecodeRun(newest.payload, &current) ||
        current.user_id != user)
        return false;
    if (alternate.ok() && (alternate.schema != 1 || newest.generation - alternate.generation != 1 ||
                           !DecodeRun(alternate.payload, &prior) || prior.user_id != user))
        return false;
    const auto published = store.Load("run", 1);
    standard::Run public_run;
    if (!published.ok() || published.schema != 1 || !standard::DecodeRun(published.payload, &public_run))
        return false;
    HandoffView recovered;
    if (public_run.phase == "closed" && (current.phase == "active" || current.phase == "closed")) {
        current.phase = "closed";
        if (!standard::Matches(public_run, current)) return false;
        if (alternate.ok()) {
            if (prior.phase != "active") return false;
            prior.phase = "closed";
            if (EncodeRun(prior) != EncodeRun(current)) return false;
        }
        // Close only when the exact transaction has a genuine saved receipt.
        recovered.run = std::move(current);
        InspectReceipts(dir, &recovered);
        if (!recovered.saved) return false;
        recovered.state = HandoffState::Returned;
    } else {
        if (!standard::Matches(public_run, current)) return false;
        // The manager completes both prepared copies before writing Flash.
        // It completes both active copies before selecting the application.
        if (current.phase == "prepared") {
            if (alternate.ok() ? (prior.phase != "closed" && prior.phase != "prepared")
                               : newest.generation != 1) return false;
        } else {
            if (current.phase != "active" || prior.phase != "prepared") return false;
            recovered.run = current;
            InspectReceipts(dir, &recovered);
            if (recovered.protocol != HandoffProtocol::Unknown || !recovered.error.empty()) return false;
            current.phase = "prepared";
            if (EncodeRun(prior) != EncodeRun(current)) return false;
        }
        recovered.run = std::move(current);
        recovered.state = HandoffState::Prepared;
    }
    *view = std::move(recovered);
    return true;
}
}
bool ValidRunId(const std::string& text) { return Hex(text, 32); }
std::string EncodeRun(const RunContext& r) {
    if (!Valid(r)) return {};
    return "FPRUN1\n" + r.run_id + "\n" + r.user_id + "\n" + r.app_id + "\n" + r.version + "\n" +
        r.image_sha256 + "\n" + std::to_string(r.image_bytes) + "\n" +
        std::to_string(r.storage_mode) + "\n" + std::to_string(r.state_schema) + "\n" + r.phase + "\n";
}
bool DecodeRun(const std::string& payload, RunContext* output) {
    if (!output) return false;
    std::vector<std::string> f;
    if (!Lines(payload, 10, &f) || f[0] != "FPRUN1") return false;
    RunContext r; r.run_id=f[1]; r.user_id=f[2]; r.app_id=f[3]; r.version=f[4]; r.image_sha256=f[5];
    std::uint32_t mode=0;
    if (!Number(f[6], &r.image_bytes) || !Number(f[7], &mode) || mode > 2 || !Number(f[8], &r.state_schema)) return false;
    r.storage_mode=static_cast<std::uint8_t>(mode); r.phase=f[9];
    if (!Valid(r)) return false;
    *output=std::move(r); return true;
}
bool SaveRun(const std::string& dir, const RunContext& r, std::string* error) {
    const auto payload=EncodeRun(r);
    if (payload.empty()) return Fail(error, "invalid handoff context");
    const auto public_payload = standard::EncodeRun(r);
    if (public_payload.empty()) return Fail(error, "invalid standard handoff context");
    // Publish both views before selecting a boot target. No application runs
    // concurrently with the manager; a partial commit never starts a new app.
    const auto published = RecordStore(dir).Save("run", 1, public_payload);
    if (!published.ok()) return Fail(error, published.error);
    const auto saved=RecordStore(dir).SaveConfirmed("run107", 1, payload);
    if (!saved.ok()) return Fail(error, saved.error);
    if(error) error->clear();
    return true;
}
HandoffView InspectHandoff(const std::string& dir, const std::string& user) {
    HandoffView v;
    const auto record=RecordStore(dir).LoadConfirmed("run107", 1);
    if(record.status==RecordStatus::Missing) {
        // Public records alone lack the image length/storage metadata needed
        // for safe Flash reuse. Preserve them instead of assuming a fresh card.
        if(RecordStore(dir).Load("run",1).status!=RecordStatus::Missing) {
            v.error="公开交接仍有记录，但宿主记录缺失，保留应用区域，请检查 TF 卡";
            return v;
        }
        v.state=HandoffState::Empty; return v;
    }
    if (record.status == RecordStatus::Corrupt && InspectInterruptedRun(dir, user, &v)) return v;
    if(!record.ok() || !DecodeRun(record.payload,&v.run) || v.run.user_id!=user) {
        v.error="交接记录不可确认，保留应用区域"; return v;
    }
    if(v.run.phase=="prepared") { v.state=HandoffState::Prepared; return v; }
    InspectReceipts(dir, &v);
    if((v.state==HandoffState::Invalid && !v.error.empty()) || v.state==HandoffState::Returned) return v;
    if(v.run.phase=="closed") { v.state=HandoffState::Closed; return v; }
    if(v.saved) { v.state=HandoffState::Returned; return v; }
    v.state=HandoffState::Unfinished;
    v.error="上次应用尚未确认保存，请先恢复该应用并正常返回";
    return v;
}
bool WriteHandoffReceipt(const std::string& dir, const RunContext& r, bool saved, std::string* error) {
    if(!Valid(r) || r.phase!="active") return Fail(error,"application context is not active");
    const auto actual=RecordStore(dir).LoadConfirmed("run107",1);
    if(!actual.ok() || actual.payload!=EncodeRun(r)) return Fail(error,"run identity changed or cannot be confirmed");
    const auto result=RecordStore(dir).SaveConfirmed("receipt107",1,Receipt(r,saved));
    if(!result.ok()) return Fail(error,result.error);
    if(error) error->clear();
    return true;
}
bool MayResumeOwnFlash(const RunContext& r, const std::string& run, const std::string& user, const std::string& app) {
    return Valid(r) && r.phase=="active" && r.run_id==run && r.user_id==user && r.app_id==app;
}
std::string EncodeWifiOffer(const WifiOffer& o) {
    if(!WifiValid(o)) return {};
    // ASCII run id is deliberately not an absolute path or a command.
    std::string out=o.run_id;
    out.push_back(static_cast<char>(o.ssid.size())); out.push_back(static_cast<char>(o.password.size()));
    return out+o.ssid+o.password;
}
bool DecodeWifiOffer(const RecordResult& r, WifiOffer* out) {
    if(!out || !r.ok() || r.schema!=1 || r.payload.size()<35) return false;
    const auto sn=static_cast<unsigned char>(r.payload[32]);
    const auto pn=static_cast<unsigned char>(r.payload[33]);
    if(r.payload.size()!=34U+sn+pn) return false;
    WifiOffer o; o.run_id=r.payload.substr(0,32); o.ssid=r.payload.substr(34,sn);
    o.password=r.payload.substr(34+sn,pn); o.generation=r.generation;
    if(!WifiValid(o)) return false;
    *out=std::move(o); return true;
}
bool WriteWifiOffer(const std::string& dir, const WifiOffer& o, std::string* error) {
    const auto payload=EncodeWifiOffer(o);
    if(payload.empty()) return Fail(error,"invalid Wi-Fi candidate");
    const auto r=RecordStore(dir).Save("wifi_offer107",1,payload);
    if(!r.ok()) return Fail(error,r.error);
    if(error) error->clear();
    return true;
}
std::string WifiResultPayload(const WifiOffer& o, const std::string& result) {
    if(!WifiValid(o) || !o.generation || !ResultValid(result)) return {};
    if(o.protocol==HandoffProtocol::Standard10) return standard::EncodeWifiResult(o,result);
    return o.run_id+"\n"+std::to_string(o.generation)+"\n"+result+"\n";
}
bool ReadWifiResult(const std::string& dir, const WifiOffer& o, std::string* result, std::string* error) {
    if(!result) return Fail(error,"missing result output");
    if(o.protocol==HandoffProtocol::Standard10) {
        const auto record=RecordStore(dir).Load("wifi_result",1);
        if(record.status==RecordStatus::Missing) {result->clear();if(error)error->clear();return true;}
        standard::WifiResult value;
        if(!record.ok() || record.schema!=1 || !standard::DecodeWifiResult(record.payload,&value))
            return Fail(error,"standard Wi-Fi result cannot be read");
        *result=(value.run_id==o.run_id && value.offer_generation==o.generation)?value.result:"";
        if(error)error->clear();
        return true;
    }
    const auto r=RecordStore(dir).LoadConfirmed("wifi_result107",1);
    if(r.status==RecordStatus::Missing) { result->clear(); if(error) error->clear();
    return true; }
    if(!r.ok()) return Fail(error,r.error);
    std::vector<std::string> f;
    if(!Lines(r.payload,3,&f) || !ValidRunId(f[0]) || !ResultValid(f[2])) return Fail(error,"invalid candidate result");
    *result=(f[0]==o.run_id && f[1]==std::to_string(o.generation))?f[2]:"";
    if(error) error->clear();
    return true;
}
bool WriteWifiResult(const std::string& dir, const WifiOffer& o, const std::string& value, std::string* error) {
    const auto payload=WifiResultPayload(o,value);
    if(payload.empty()) return Fail(error,"invalid candidate result");
    const auto r=o.protocol==HandoffProtocol::Standard10 ? RecordStore(dir).Save("wifi_result",1,payload) :
        RecordStore(dir).SaveConfirmed("wifi_result107",1,payload);
    if(!r.ok()) return Fail(error,r.error);
    if(error) error->clear();
    return true;
}
}
