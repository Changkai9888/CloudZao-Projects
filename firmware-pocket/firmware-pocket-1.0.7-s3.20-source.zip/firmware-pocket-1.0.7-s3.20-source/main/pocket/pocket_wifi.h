#pragma once
#include <cstddef>
#include <string>
#include <vector>
namespace pocket {
constexpr std::size_t kMaximumSharedWifiNetworks = 10;
constexpr std::size_t kMaximumWifiSsidBytes = 32;
constexpr std::size_t kMaximumWifiPasswordBytes = 64;
struct WifiNetwork { std::string ssid; std::string password; };

// The storage worker calls Initialize only while the same user's TF is mounted.
// TF shared/wifi_networks retains the legacy multi-network format. The host
// publishes its preferred network as standard shared/wifi_current, with a
// private transaction for interruption/conflict handling. An empty list removes
// both standard current slots, rather than publishing an invalid empty SSID.
// On first use only, import the old
// NVS list (or official wifi keys), then persist it, including an empty list.
// Existing TF corruption/unsupported format is never treated as first use.
// Readers use a mutex-protected RAM snapshot: the radio task never accesses TF.
bool InitializeSharedWifi(const std::string& shared_directory, std::string* error);
// Call BEFORE exporting/unmounting TF. Cached credentials become unavailable;
// this does not disconnect an already established radio link.
void DisableSharedWifiStorage();
bool ReadSharedWifi(std::vector<WifiNetwork>* networks, std::string* error);

// Storage-worker-only mutations: write, sync and exact readback before success.
// Add/update moves this network to the last (preferred) position; others remain.
// Candidate trials must not call Save until the trial has obtained a valid IP.
// SSID 1..32 raw bytes; password 0..64, no embedded NUL. Empty means open Wi-Fi.
// No API logs credentials, erases NVS, or changes radio state. Read leaves output
// untouched on error. A failed write invalidates the cache until reinitialized.
bool SaveSharedWifi(const std::string& ssid, const std::string& password, std::string* error);
// Restore the complete previous list only if the current list is still the
// exact result of promoting this candidate.
bool RestoreSharedWifi(const std::vector<WifiNetwork>& previous, const WifiNetwork& candidate, std::string* error);
bool ForgetSharedWifi(const std::string& ssid, std::string* error);
}  // namespace pocket
