#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include "pocket_wifi_connection.h"

namespace pocket {
enum class Command { Refresh, InstallAndLaunch, Increment, BookmarkNext,
    NoteNext, PreferenceNext, Save, ReturnToManager, ToggleUsb, PowerOff,
    WifiSave, WifiForget, WifiRefresh, WifiScan, WifiConnectSaved, ResumeApplication,
    UnlockPin, ChangePin, RestartAndLaunch };
struct PackageView {
    std::string name, version, id, detail;
    std::string description, last_used;
    std::string exit_hint;
    uint8_t storage_mode = 0, exit_method = 0;
    bool compatible = false;
    // Manager-only: an explicit retry of this exact failed run/image.
    bool restart_allowed = false;
    std::string restart_run_id, restart_image_sha256;
};
struct View {
    uint32_t revision = 0;
    bool ready = false, busy = true, manager = false, integrated = false;
    bool switching = false;
    bool scan_running = false, scan_complete = false;
    uint32_t scan_total = 0, scan_done = 0;
    bool storage_ok = false, dirty = false, usb_active = false;
    bool state_blocked = false;
    bool handoff_blocked = false, resume_available = false;
    bool unfinished_checkpoint = false;
    // Foreground manager only; this gate is not part of the application ABI.
    bool auth_required = false, pin_ready = false, pin_is_default = true;
    uint32_t pin_revision = 0;
    std::string pin_message;
    PackageView resume_package;
    std::string resume_run_id;
    uint64_t tf_free_bytes = 0;
    bool tf_space_known = false, tf_space_low = false, tf_space_blocked = false;
    // Worker-sampled device gauge estimate; -1 means unavailable.
    int battery_level = -1;
    bool wifi_ready = false;
    std::vector<std::string> wifi_names;
    WifiConnectionView wifi_connection;
    int counter = 0, bookmark = 1, note = 0, preference = 0, public_preference = 1;
    std::string app_id, title, version, user_id, status, error;
    std::vector<PackageView> packages;
};
// UI calls only these nonblocking cache/queue operations; all disk and flash I/O
// runs on the internal-RAM worker. No NVS or filesystem access in LVGL callbacks.
View Snapshot();
bool Post(Command command, int argument = 0);
bool PostRestartPackage(int index, const PackageView& expected);
bool PostWifiSave(const std::string& ssid, const std::string& password);
bool PostWifiForget(const std::string& ssid);
bool PostWifiConnectSaved(const std::string& ssid);
bool PostUnlockPin(const std::string& pin);
bool PostChangePin(const std::string& current, const std::string& next,
                   const std::string& confirm);
void Start();
}
