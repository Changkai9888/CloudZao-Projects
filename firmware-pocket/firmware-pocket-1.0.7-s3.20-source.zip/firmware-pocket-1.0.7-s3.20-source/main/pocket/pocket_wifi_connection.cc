#include "pocket_wifi_connection.h"
#include "pocket_wifi_connection_model.h"
#include "pocket_wifi.h"

#include <algorithm>
#include <array>
#include <atomic>
#include <cstring>
#include <mutex>
#include <utility>
#include <esp_event.h>
#include <esp_heap_caps.h>
#include <esp_log.h>
#include <esp_netif.h>
#include <esp_timer.h>
#include <esp_wifi.h>
#include <freertos/FreeRTOS.h>
#include <freertos/queue.h>
#include <freertos/task.h>

namespace pocket {
namespace {
constexpr char kTag[] = "PocketWifi";
constexpr int64_t kConnectTimeoutUs = 12000000;
constexpr int64_t kScanTimeoutUs = 10000000;
enum class Kind { Scan, Connect, Disconnect, Candidate, AcceptCandidate };
struct Request { Kind kind; uint32_t generation; char ssid[33]{}; char password[65]{}; };

std::mutex view_mutex;
std::mutex request_mutex;
WifiConnectionView view;
std::atomic<QueueHandle_t> queue{nullptr};
std::atomic<bool> starting{false};
std::atomic<bool> scan_pending{false};
std::atomic<uint32_t> generation{0};
std::atomic<bool> associated{false};
std::atomic<bool> fresh_ip{false};
std::atomic<bool> scan_done{false};
std::atomic<int> disconnect_reason{0};
esp_netif_t* netif = nullptr;  // Created once; never destroyed while callbacks exist.
esp_event_handler_instance_t wifi_handler = nullptr;
esp_event_handler_instance_t ip_handler = nullptr;

bool Equal(const WifiConnectionView& a, const WifiConnectionView& b) {
    return a.candidate_token == b.candidate_token && a.candidate_done == b.candidate_done &&
        a.candidate_connected == b.candidate_connected && a.ready == b.ready && a.scanning == b.scanning && a.connecting == b.connecting &&
        a.connected == b.connected && a.signal_bars == b.signal_bars && a.ssid == b.ssid &&
        a.ip == b.ip && a.message == b.message && a.access_points.size() == b.access_points.size() &&
        std::equal(a.access_points.begin(), a.access_points.end(), b.access_points.begin(),
            [](const WifiAccessPoint& x, const WifiAccessPoint& y) {
                return x.ssid == y.ssid && x.rssi == y.rssi && x.secured == y.secured;
            });
}

template<class Update> void Publish(Update update) {
    std::lock_guard<std::mutex> lock(view_mutex);
    const auto previous = view;
    update(view);
    if (!Equal(previous, view)) ++view.revision;
}

void ClearLink() {
    associated.store(false);
    fresh_ip.store(false);
    Publish([](auto& v) {
        const bool was_connected = v.connected;
        v.connected = false; v.signal_bars = 0; v.ip.clear();
        if (was_connected && !v.connecting && !v.scanning)
            v.message = "Wi-Fi 已断开，正在等待重新连接";
    });
}

void OnEvent(void*, esp_event_base_t base, int32_t event_id, void* data) {
    // The ESP event-loop task never reads NVS and never calls LVGL. Disconnect
    // clears the cached icon immediately instead of waiting for a scan/query.
    if (base == WIFI_EVENT) {
        if (event_id == WIFI_EVENT_SCAN_DONE) scan_done.store(true);
        else if (event_id == WIFI_EVENT_STA_CONNECTED) {
            associated.store(true); fresh_ip.store(false);
        } else if (event_id == WIFI_EVENT_STA_DISCONNECTED) {
            if (data) disconnect_reason.store(static_cast<wifi_event_sta_disconnected_t*>(data)->reason);
            ClearLink();
        } else if (event_id == WIFI_EVENT_STA_STOP) ClearLink();
    } else if (base == IP_EVENT) {
        if (event_id == IP_EVENT_STA_GOT_IP && data) {
            const auto* event = static_cast<ip_event_got_ip_t*>(data);
            if (event->esp_netif == netif && associated.load() && event->ip_info.ip.addr != 0)
                fresh_ip.store(true);
        } else if (event_id == IP_EVENT_STA_LOST_IP) {
            fresh_ip.store(false);
            Publish([](auto& v) { v.connected = false; v.signal_bars = 0; v.ip.clear();
                if (!v.connecting) v.message = "Wi-Fi 地址已失效，请重新连接"; });
        }
    }
}

bool PrepareRadio() {
    // This minimal firmware has one Wi-Fi owner, with no legacy station or
    // automatic radio-sleep service competing for scans and connection state.
    wifi_mode_t mode = WIFI_MODE_NULL;
    const bool initialized = esp_wifi_get_mode(&mode) == ESP_OK;
    esp_err_t err = esp_netif_init();
    if (err != ESP_OK && err != ESP_ERR_INVALID_STATE) return false;
    err = esp_event_loop_create_default();
    if (err != ESP_OK && err != ESP_ERR_INVALID_STATE) return false;
    netif = esp_netif_get_handle_from_ifkey("WIFI_STA_DEF");
    if (!netif) netif = esp_netif_create_default_wifi_sta();
    if (!netif) return false;
    if (!initialized) {
        wifi_init_config_t config = WIFI_INIT_CONFIG_DEFAULT();
        config.nvs_enable = false;
        if (esp_wifi_init(&config) != ESP_OK) return false;
    }
    if (!wifi_handler && esp_event_handler_instance_register(WIFI_EVENT, ESP_EVENT_ANY_ID,
            OnEvent, nullptr, &wifi_handler) != ESP_OK) return false;
    if (!ip_handler && esp_event_handler_instance_register(IP_EVENT, ESP_EVENT_ANY_ID,
            OnEvent, nullptr, &ip_handler) != ESP_OK) return false;
    if (esp_wifi_set_storage(WIFI_STORAGE_RAM) != ESP_OK ||
        esp_wifi_set_mode(WIFI_MODE_STA) != ESP_OK || esp_wifi_start() != ESP_OK) return false;
    (void)esp_wifi_set_ps(WIFI_PS_MIN_MODEM);
    return true;
}

bool RefreshLink(const std::string& expected) {
    wifi_ap_record_t ap{};
    esp_netif_ip_info_t ip{};
    const bool ap_ok = esp_wifi_sta_get_ap_info(&ap) == ESP_OK;
    const std::string actual = ap_ok ? std::string(reinterpret_cast<const char*>(ap.ssid),
                                                 strnlen(reinterpret_cast<const char*>(ap.ssid), sizeof(ap.ssid))) : "";
    const bool up = netif && esp_netif_is_netif_up(netif);
    const bool ip_ok = netif && esp_netif_get_ip_info(netif, &ip) == ESP_OK && ip.ip.addr != 0;
    const bool connected = wifi_detail::LinkReady(ap_ok && associated.load(), fresh_ip.load(),
                                                 up, ip_ok, expected, actual);
    char address[16]{};
    if (connected) esp_ip4addr_ntoa(&ip.ip, address, sizeof(address));
    Publish([&](auto& v) {
        // A disconnect/IP-loss callback may have run while the driver was
        // queried. Never overwrite its cleared state with this older sample.
        const bool current = connected && associated.load() && fresh_ip.load();
        const bool changed = v.connected != current || (current && v.ip != address);
        v.connected = current;
        v.signal_bars = current ? wifi_detail::SignalBars(ap.rssi) : 0;
        v.ip = current ? address : "";
        if (current) {
            v.ssid = actual;
            if (changed && !v.scanning) v.message = "Wi-Fi 已连接，已取得 IP 地址";
        } else if (changed && !v.scanning && !v.connecting) v.message = "Wi-Fi 已断开";
    });
    return connected && associated.load() && fresh_ip.load();
}

bool ConnectNetwork(const WifiNetwork& network, uint32_t request_generation, int64_t deadline, bool candidate) {
    const auto& ssid = network.ssid;
    if (request_generation != generation.load()) return false;
    Publish([&](auto& v) {
        v.connecting = true; v.connected = false; v.signal_bars = 0; v.ip.clear();
        v.ssid = ssid; v.message = candidate ? "正在验证应用提供的网络" : "配置已保存，正在连接 Wi-Fi";
    });
    (void)esp_wifi_disconnect();
    // Let the previous association's events drain before allowing a fresh IP.
    vTaskDelay(pdMS_TO_TICKS(150));
    associated.store(false); fresh_ip.store(false); disconnect_reason.store(0);
    if (request_generation != generation.load()) return false;
    wifi_config_t config{};
    memcpy(config.sta.ssid, network.ssid.data(), network.ssid.size());
    memcpy(config.sta.password, network.password.data(), network.password.size());
    config.sta.scan_method = WIFI_ALL_CHANNEL_SCAN;
    config.sta.threshold.authmode = WIFI_AUTH_OPEN;
    config.sta.pmf_cfg.capable = true;
    config.sta.pmf_cfg.required = false;
    const auto configured = esp_wifi_set_config(WIFI_IF_STA, &config);
    memset(&config, 0, sizeof(config));
    if (configured != ESP_OK || esp_wifi_connect() != ESP_OK) {
        Publish([&](auto& v) { v.connecting = false; v.message = candidate ? "候选网络无法连接，原配置保留" : "配置已保存，但无法开始连接，请检查密码格式后重试"; });
        return false;
    }
    while (esp_timer_get_time() < deadline) {
        if (request_generation != generation.load()) return false;
        if (RefreshLink(ssid)) {
            Publish([](auto& v) { v.connecting = false; v.message = "Wi-Fi 已连接，已取得 IP 地址"; });
            ESP_LOGI(kTag, "CONNECTED ip_valid=1");
            return true;
        }
        if (disconnect_reason.load() != 0) break;
        vTaskDelay(pdMS_TO_TICKS(150));
    }
    if (request_generation != generation.load()) return false;
    (void)esp_wifi_disconnect();
    ClearLink();
    Publish([&](auto& v) { v.connecting = false;
        v.message = candidate ? "候选网络验证失败，原配置保留" : "配置已保存，连接未成功；请检查密码、信号或路由器后重试"; });
    ESP_LOGI(kTag, "CONNECT_FAILED reason=%d", disconnect_reason.load());
    return false;
}

bool ConnectSaved(const std::string& ssid, uint32_t request_generation, int64_t deadline) {
    if (request_generation != generation.load()) return false;
    std::vector<WifiNetwork> networks;
    std::string error;
    if (!ReadSharedWifi(&networks, &error)) {
        Publish([](auto& v) { v.connecting = false; v.message = "无法读取已保存的网络，请重新保存后重试"; });
        return false;
    }
    const auto found = std::find_if(networks.begin(), networks.end(), [&](const auto& n) { return n.ssid == ssid; });
    if (found == networks.end()) {
        Publish([](auto& v) { v.connecting = false; v.message = "网络尚未保存或已被忘记，请填写密码后连接"; });
        return false;
    }
    return ConnectNetwork(*found, request_generation, deadline, false);
}

void Scan(uint32_t request_generation) {
    if (request_generation != generation.load()) { scan_pending.store(false); return; }
    Publish([](auto& v) { v.scanning = true; v.connecting = false; v.message = "正在搜索附近的 2.4 GHz Wi-Fi"; });
    scan_done.store(false);
    wifi_scan_config_t config{};
    config.show_hidden = false;
    config.scan_type = WIFI_SCAN_TYPE_ACTIVE;
    config.scan_time.active.min = 80;
    config.scan_time.active.max = 160;
    bool ok = esp_wifi_scan_start(&config, false) == ESP_OK;
    const int64_t deadline = esp_timer_get_time() + kScanTimeoutUs;
    while (ok && !scan_done.load() && esp_timer_get_time() < deadline && request_generation == generation.load())
        vTaskDelay(pdMS_TO_TICKS(100));
    ok = ok && scan_done.load() && request_generation == generation.load();
    std::vector<WifiAccessPoint> points;
    if (ok) {
        // IDF returns scan records ordered by RSSI. Cap allocation; a user list
        // keeps at most 24 unique displayable SSIDs, including strongest BSSID.
        std::array<wifi_ap_record_t, 64> records{};
        static_assert(sizeof(records) <= 8192, "Wi-Fi records must leave at least half the worker stack free");
        uint16_t count = static_cast<uint16_t>(records.size());
        ok = esp_wifi_scan_get_ap_records(&count, records.data()) == ESP_OK;
        if (ok) for (uint16_t i = 0; i < count; ++i) {
            const auto& record = records[i];
            if (record.primary > 14) continue;
            points.push_back({std::string(reinterpret_cast<const char*>(record.ssid),
                                         strnlen(reinterpret_cast<const char*>(record.ssid), sizeof(record.ssid))),
                              record.rssi, record.authmode != WIFI_AUTH_OPEN});
        }
    } else (void)esp_wifi_scan_stop();
    // This also releases a completed scan's table on failure/cancellation.
    (void)esp_wifi_clear_ap_list();
    Publish([&](auto& v) {
        v.scanning = false;
        if (ok) {
            v.access_points = wifi_detail::VisibleAccessPoints(std::move(points));
            v.message = v.access_points.empty() ? "未发现可显示的网络，可重新搜索或手动输入名称" : "搜索完成，请选择网络后连接";
        } else if (request_generation == generation.load()) v.message = "搜索未完成，请稍后重试";
    });
    scan_pending.store(false);
}

void Worker(void* startup_option) {
    bool radio_ready = PrepareRadio();
    Publish([&](auto& v) { v.ready = radio_ready;
        v.message = radio_ready ? "Wi-Fi 已就绪" : "Wi-Fi 启动失败，请重新搜索后重试"; });
    std::string target;
    unsigned reconnect_attempts = 0;
    int64_t retry_at = 0;
    if (radio_ready && startup_option == nullptr) {
        std::vector<std::string> saved;
        {
            std::vector<WifiNetwork> entries; std::string error;
            if (ReadSharedWifi(&entries, &error)) {
                for (auto i = entries.rbegin(); i != entries.rend(); ++i)
                    if (wifi_detail::RawSsidValid(i->ssid)) saved.push_back(i->ssid);
            } else Publish([](auto& v) { v.message = "无法读取已保存网络，请检查 Wi-Fi 配置"; });
        }
        const auto boot_generation = generation.load();
        const int64_t total_deadline = esp_timer_get_time() + 30000000;
        for (const auto& ssid : saved) {
            // A user request submitted during radio initialization wins over
            // startup attempts, even if it arrived before this snapshot.
            if (boot_generation != generation.load() || uxQueueMessagesWaiting(queue.load()) != 0 ||
                esp_timer_get_time() >= total_deadline) break;
            if (ConnectSaved(ssid, boot_generation, std::min(total_deadline, esp_timer_get_time() + kConnectTimeoutUs))) {
                target = ssid; break;
            }
        }
        if (saved.empty()) Publish([](auto& v) { v.message = "尚无已保存网络，请搜索并连接"; });
    }
    Request request{};
    WifiNetwork pending_candidate;
    uint32_t pending_token = 0;
    for (;;) {
        if (xQueueReceive(queue.load(), &request, pdMS_TO_TICKS(300)) == pdTRUE) {
            if (request.generation != generation.load()) {
                if (request.kind == Kind::Scan) scan_pending.store(false);
                memset(request.password, 0, sizeof(request.password));
                continue;
            }
            if (request.kind == Kind::AcceptCandidate) {
                std::vector<WifiNetwork> saved; std::string error;
                const bool persisted = pending_token == request.generation &&
                    ReadSharedWifi(&saved, &error) &&
                    std::any_of(saved.begin(), saved.end(), [&](const auto& n) {
                        return n.ssid == pending_candidate.ssid && n.password == pending_candidate.password;
                    });
                if (persisted && RefreshLink(pending_candidate.ssid)) {
                    target = pending_candidate.ssid;
                    retry_at = 0; reconnect_attempts = 0;
                }
                pending_candidate = {}; pending_token = 0;
                continue;
            }
            pending_candidate = {}; pending_token = 0;
            if (request.kind != Kind::Candidate) Publish([](auto& v) {
                v.candidate_token = 0; v.candidate_done = false; v.candidate_connected = false;
            });
            if (request.kind == Kind::Disconnect) {
                target.clear(); retry_at = 0; reconnect_attempts = 0;
                (void)esp_wifi_disconnect(); ClearLink();
                Publish([](auto& v) { v.connecting = false; v.message = "Wi-Fi 已断开"; });
                continue;
            }
            if (!radio_ready) {
                radio_ready = PrepareRadio();
                Publish([&](auto& v) { v.ready = radio_ready; });
            }
            if (!radio_ready) {
                scan_pending.store(false);
                Publish([&](auto& v) { v.scanning = false; v.connecting = false;
                    v.message = "Wi-Fi 启动失败，请重启设备后重试";
                    if (request.kind == Kind::Candidate) {
                        v.candidate_token = request.generation; v.candidate_done = true; v.candidate_connected = false;
                    }
                });
                memset(request.password, 0, sizeof(request.password));
                continue;
            }
            if (request.kind == Kind::Scan) Scan(request.generation);
            else if (request.kind == Kind::Candidate) {
                target.clear(); retry_at = 0; reconnect_attempts = 0;
                pending_candidate = {request.ssid, request.password};
                memset(request.password, 0, sizeof(request.password));
                pending_token = request.generation;
                Publish([&](auto& v) { v.candidate_token = request.generation;
                    v.candidate_done = false; v.candidate_connected = false; });
                const bool success = ConnectNetwork(pending_candidate, request.generation,
                    esp_timer_get_time() + kConnectTimeoutUs, true);
                if (request.generation == generation.load()) Publish([&](auto& v) {
                    v.candidate_done = true; v.candidate_connected = success;
                });
                else { pending_candidate = {}; pending_token = 0; }
            }
            else {
                target.clear(); retry_at = 0; reconnect_attempts = 0;
                if (ConnectSaved(request.ssid, request.generation, esp_timer_get_time() + kConnectTimeoutUs)) target = request.ssid;
            }
        }
        if (radio_ready && pending_token && pending_token == generation.load())
            (void)RefreshLink(pending_candidate.ssid);
        if (radio_ready && !target.empty()) {
            if (RefreshLink(target)) { retry_at = 0; reconnect_attempts = 0; }
            else if (reconnect_attempts < 3) {
                if (!retry_at) retry_at = esp_timer_get_time() + 10000000;
                else if (esp_timer_get_time() >= retry_at && uxQueueMessagesWaiting(queue.load()) == 0) {
                    ++reconnect_attempts;
                    const auto current_generation = generation.load();
                    (void)ConnectSaved(target, current_generation, esp_timer_get_time() + kConnectTimeoutUs);
                    retry_at = esp_timer_get_time() + 30000000;
                }
            }
        }
    }
}

uint32_t Submit(Kind kind, const std::string& ssid = {}, const std::string& password = {}, uint32_t accepted_token = 0) {
    std::lock_guard<std::mutex> lock(request_mutex);
    const auto q = queue.load();
    if (!q) return 0;
    if (kind == Kind::Scan && scan_pending.load()) return 1;
    if (uxQueueSpacesAvailable(q) == 0) return 0;
    if (kind == Kind::AcceptCandidate && (!accepted_token || accepted_token != generation.load())) return 0;
    Request request{};
    request.kind = kind;
    request.generation = kind == Kind::AcceptCandidate ?
        generation.load() : generation.fetch_add(1) + 1;
    if (kind == Kind::Connect || kind == Kind::Candidate) memcpy(request.ssid, ssid.data(), ssid.size());
    if (kind == Kind::Candidate) memcpy(request.password, password.data(), password.size());
    if (kind == Kind::Scan) scan_pending.store(true);
    const bool submitted = xQueueSend(q, &request, 0) == pdTRUE;
    memset(request.password, 0, sizeof(request.password));
    if (submitted) return kind == Kind::Candidate ? request.generation : 1;
    if (kind == Kind::Scan) scan_pending.store(false);
    return 0;
}

}  // namespace

void StartWifiConnection(bool connect_saved_on_start) {
    std::lock_guard<std::mutex> lock(request_mutex);
    if (starting.exchange(true)) return;
    const auto q = xQueueCreate(4, sizeof(Request));
    if (q) queue.store(q);
    // A returned application can supply the initial candidate before any
    // saved-network attempt. This tag is inspected only for nullness.
    static int candidate_first;
    void* startup_option = connect_saved_on_start ? nullptr : &candidate_first;
    if (!q || xTaskCreatePinnedToCoreWithCaps(Worker, "pocket_wifi", 16384, startup_option, 3,
            nullptr, 0, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT) != pdPASS) {
        queue.store(nullptr);
        if (q) vQueueDelete(q);
        Publish([](auto& v) { v.message = "内部内存不足，Wi-Fi 任务未启动"; });
        starting.store(false);
    }
}

WifiConnectionView WifiConnectionSnapshot() {
    std::lock_guard<std::mutex> lock(view_mutex);
    auto result = view;
    if (result.candidate_token != generation.load()) {
        result.candidate_token = 0;
        result.candidate_done = false;
        result.candidate_connected = false;
    }
    return result;
}
bool RequestWifiScan() { return Submit(Kind::Scan); }
bool RequestWifiConnect(const std::string& ssid) {
    return wifi_detail::RawSsidValid(ssid) && Submit(Kind::Connect, ssid);
}
bool RequestWifiDisconnect() { return Submit(Kind::Disconnect); }
uint32_t RequestWifiCandidate(const std::string& ssid, const std::string& password) {
    if (!wifi_detail::RawSsidValid(ssid) || password.size() > 64 || password.find('\0') != std::string::npos) return 0;
    return Submit(Kind::Candidate, ssid, password);
}
bool AcceptWifiCandidate(uint32_t token) {
    const auto current = WifiConnectionSnapshot();
    return current.candidate_token == token && current.candidate_done && current.candidate_connected &&
        current.connected && Submit(Kind::AcceptCandidate, {}, {}, token) != 0;
}
}  // namespace pocket
