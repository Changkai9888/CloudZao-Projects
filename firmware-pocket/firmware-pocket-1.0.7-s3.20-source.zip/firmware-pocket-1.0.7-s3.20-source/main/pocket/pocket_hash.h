#pragma once
#include <cstddef>
#include <cstdint>

// The ESP32-S3 / ESP-IDF 5.5.4 binding uses mbedTLS, as does its retained image
// parser. Host tests can supply the existing OpenSSL-backed mbedTLS adapters.
#include <mbedtls/sha256.h>
#include <mbedtls/md5.h>

namespace pocket {
class Sha256 {
public:
    Sha256() {
        mbedtls_sha256_init(&operation_);
        valid_ = mbedtls_sha256_starts(&operation_, 0) == 0;
    }
    ~Sha256() {
        mbedtls_sha256_free(&operation_);
    }
    Sha256(const Sha256&) = delete;
    Sha256& operator=(const Sha256&) = delete;
    bool Add(const void* bytes, std::size_t length) {
        if (!valid_) return false;
        valid_ = mbedtls_sha256_update(&operation_, static_cast<const unsigned char*>(bytes), length) == 0;
        return valid_;
    }
    bool Finish(unsigned char* output) {
        if (!valid_) return false;
        const bool ok = mbedtls_sha256_finish(&operation_, output) == 0;
        valid_ = false;
        return ok;
    }
private:
    mbedtls_sha256_context operation_{};
    bool valid_ = false;
};
inline bool PartitionMd5(const unsigned char* bytes, std::size_t length, unsigned char* output) {
    return mbedtls_md5(bytes, length, output) == 0;
}
} // namespace pocket
