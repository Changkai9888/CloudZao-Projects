#include "s3_board.h"
#include "config.h"
#include "esp_lcd_panel_ssd1677.h"

#include <algorithm>
#include <array>
#include <atomic>
#include <cstring>
#include <driver/spi_master.h>
#include <esp_heap_caps.h>
#include <esp_lcd_panel_ops.h>
#include <esp_log.h>
#include <esp_rom_sys.h>
#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>
#include <freertos/task.h>

namespace pocket_s3 {
namespace {
constexpr char kTag[] = "PocketS3Board";
constexpr uint8_t kExpanderAddress = 0x20, kTouchAddress = 0x15;
constexpr gpio_num_t kBusy = GPIO_NUM_9;
constexpr uint16_t kOutputs = (1u<<0)|(1u<<1)|(1u<<4)|(1u<<5)|(1u<<6)|(1u<<9)|(1u<<11);
constexpr uint16_t kInputs = (1u<<7)|(1u<<8)|(1u<<12);
i2c_master_bus_handle_t bus = nullptr;
std::array<i2c_master_dev_handle_t,128> devices{};
SemaphoreHandle_t bus_lock = nullptr, refresh_done = nullptr;
esp_lcd_panel_handle_t panel = nullptr;
esp_lcd_panel_io_handle_t panel_io = nullptr;
uint8_t* transfer = nullptr;
uint16_t output_latch = 0xffff;
Sample sample_cb = nullptr;
std::atomic<bool> touch_paused{false};
std::atomic<unsigned> samples{0}, read_errors{0};
std::atomic<int> last_error{ESP_OK};
bool known = false;

bool Check(esp_err_t code, const char* what, std::string* error) {
    if (code == ESP_OK) return true;
    if (error) *error = std::string(what) + ": " + esp_err_to_name(code);
    ESP_LOGE(kTag, "%s: %s", what, esp_err_to_name(code));
    return false;
}
esp_err_t Device(i2c_port_t port, uint8_t address, i2c_master_dev_handle_t* out) {
    if (!bus || port != I2C_NUM_0 || address >= devices.size() || !out) return ESP_ERR_INVALID_ARG;
    auto& device = devices[address];
    if (!device) {
        i2c_device_config_t config{};
        config.dev_addr_length = I2C_ADDR_BIT_LEN_7;
        config.device_address = address;
        config.scl_speed_hz = 400000;
        const auto result = i2c_master_bus_add_device(bus, &config, &device);
        if (result != ESP_OK) return result;
    }
    *out = device;
    return ESP_OK;
}
esp_err_t Read(i2c_master_dev_handle_t device, uint8_t reg, uint8_t* data, size_t size, int ms = 100) {
    return i2c_master_transmit_receive(device, &reg, 1, data, size, ms);
}
esp_err_t Write16(uint8_t reg, uint16_t value) {
    const uint8_t data[]{reg, uint8_t(value), uint8_t(value >> 8)};
    const auto result = i2c_master_transmit(devices[kExpanderAddress], data, sizeof(data), 100);
    if (result == ESP_OK && reg == 2) output_latch = value;
    return result;
}
void RecoverBus() {
    gpio_config_t config{};
    config.pin_bit_mask = (1ULL << I2C_SDA_PIN) | (1ULL << I2C_SCL_PIN);
    config.mode = GPIO_MODE_INPUT_OUTPUT_OD;
    config.pull_up_en = GPIO_PULLUP_ENABLE;
    gpio_config(&config);
    gpio_set_level(I2C_SDA_PIN, 1);
    gpio_set_level(I2C_SCL_PIN, 1);
    esp_rom_delay_us(10);
    for (unsigned i = 0; i < 9 && !gpio_get_level(I2C_SDA_PIN); ++i) {
        gpio_set_level(I2C_SCL_PIN, 0); esp_rom_delay_us(5);
        gpio_set_level(I2C_SCL_PIN, 1); esp_rom_delay_us(5);
    }
    gpio_set_level(I2C_SDA_PIN, 0); esp_rom_delay_us(5);
    gpio_set_level(I2C_SCL_PIN, 1); esp_rom_delay_us(5);
    gpio_set_level(I2C_SDA_PIN, 1); esp_rom_delay_us(5);
}
bool InitIo(std::string* error) {
    RecoverBus();
    i2c_master_bus_config_t config{};
    config.i2c_port = I2C_NUM_0;
    config.sda_io_num = I2C_SDA_PIN;
    config.scl_io_num = I2C_SCL_PIN;
    config.clk_source = I2C_CLK_SRC_DEFAULT;
    config.glitch_ignore_cnt = 7;
    config.flags.enable_internal_pullup = 1;
    if (!Check(i2c_new_master_bus(&config, &bus), "I2C bus", error)) return false;
    bus_lock = xSemaphoreCreateMutex();
    if (!bus_lock) return Check(ESP_ERR_NO_MEM, "I2C lock", error);
    esp_err_t found = ESP_FAIL;
    for (unsigned attempt = 0; attempt < 6; ++attempt) {
        vTaskDelay(pdMS_TO_TICKS(20 + 20 * attempt));
        found = i2c_master_probe(bus, kExpanderAddress, 100);
        if (found == ESP_OK) break;
        i2c_master_bus_reset(bus);
    }
    if (!Check(found, "TCA9555 detection", error)) return false;
    i2c_master_dev_handle_t expander;
    if (!Check(Device(I2C_NUM_0, kExpanderAddress, &expander), "TCA9555 setup", error)) return false;
    uint8_t old[2]{};
    if (!Check(Read(expander, 2, old, sizeof(old)), "TCA9555 output read", error)) return false;
    uint16_t outputs = uint16_t(old[0] | (old[1] << 8));
    outputs |= (1u<<0)|(1u<<5)|(1u<<6)|(1u<<9)|(1u<<11);
    outputs &= uint16_t(~((1u<<1)|(1u<<4)));
    if (!Check(Write16(2, outputs), "TCA9555 output", error)) return false;
    if (!Check(Read(expander, 6, old, sizeof(old)), "TCA9555 direction read", error)) return false;
    const auto directions = uint16_t(((old[0] | (old[1] << 8)) | kInputs) & ~kOutputs);
    if (!Check(Write16(6, directions), "TCA9555 direction", error)) return false;
    if (!Check(Write16(2, output_latch & ~(1u<<9)), "touch reset assert", error)) return false;
    vTaskDelay(pdMS_TO_TICKS(10));
    if (!Check(Write16(2, output_latch | (1u<<9)), "touch reset release", error)) return false;
    vTaskDelay(pdMS_TO_TICKS(120));
    gpio_config_t motor{};
    motor.pin_bit_mask = 1ULL << VIBRATION_MOTOR_GPIO;
    motor.mode = GPIO_MODE_OUTPUT;
    if (!Check(gpio_config(&motor), "motor GPIO", error)) return false;
    Motor(false);
    gpio_config_t inputs{};
    inputs.pin_bit_mask = (1ULL << POWER_BUTTON_GPIO) | (1ULL << TOUCH_INT_GPIO) |
                          (1ULL << SDMMC_DAT3_PIN);
    inputs.mode = GPIO_MODE_INPUT;
    inputs.pull_up_en = GPIO_PULLUP_ENABLE;
    return Check(gpio_config(&inputs), "input GPIO", error);
}
bool RefreshDone(esp_lcd_panel_handle_t, const void*, void*) {
    BaseType_t woken = pdFALSE;
    xSemaphoreGiveFromISR(refresh_done, &woken);
    return woken == pdTRUE;
}
bool InitPanel(std::string* error) {
    spi_bus_config_t spi{};
    spi.mosi_io_num = GPIO_NUM_8;
    spi.miso_io_num = -1;
    spi.sclk_io_num = GPIO_NUM_14;
    spi.quadwp_io_num = -1;
    spi.quadhd_io_num = -1;
    spi.max_transfer_sz = kMonoBytes + 8;
    if (!Check(spi_bus_initialize(SPI3_HOST, &spi, SPI_DMA_CH_AUTO), "SPI bus", error)) return false;
    esp_lcd_panel_io_spi_config_t io{};
    io.cs_gpio_num = GPIO_NUM_45;
    io.dc_gpio_num = GPIO_NUM_13;
    io.pclk_hz = 10000000;
    io.trans_queue_depth = 10;
    io.lcd_cmd_bits = 8;
    io.lcd_param_bits = 8;
    if (!Check(esp_lcd_new_panel_io_spi(static_cast<esp_lcd_spi_bus_handle_t>(SPI3_HOST), &io, &panel_io),
               "panel SPI", error)) return false;
    const auto isr = gpio_install_isr_service(0);
    if (isr != ESP_OK && isr != ESP_ERR_INVALID_STATE) return Check(isr, "GPIO ISR", error);
    refresh_done = xSemaphoreCreateBinary();
    if (!refresh_done) return Check(ESP_ERR_NO_MEM, "display semaphore", error);
    esp_lcd_ssd1677_config_t vendor{};
    vendor.busy_gpio_num = kBusy;
    vendor.non_copy_mode = true;
    vendor.use_fast_full_update = true;
    esp_lcd_panel_dev_config_t config{};
    config.reset_gpio_num = GPIO_NUM_18;
    config.vendor_config = &vendor;
    if (!Check(esp_lcd_new_panel_ssd1677(panel_io, &config, &panel), "SSD1677", error)) return false;
    epaper_panel_callbacks_t callbacks{};
    callbacks.on_epaper_refresh_done = RefreshDone;
    if (!Check(epaper_panel_register_event_callbacks(panel, &callbacks, nullptr), "panel callback", error) ||
        !Check(esp_lcd_panel_reset(panel), "panel reset", error)) return false;
    vTaskDelay(pdMS_TO_TICKS(100));
    if (!Check(esp_lcd_panel_init(panel), "panel init", error)) return false;
    vTaskDelay(pdMS_TO_TICKS(100));
    transfer = static_cast<uint8_t*>(heap_caps_malloc(kMonoBytes, MALLOC_CAP_DMA | MALLOC_CAP_INTERNAL));
    return transfer || Check(ESP_ERR_NO_MEM, "display DMA buffer", error);
}
void TouchTask(void*) {
    for (;;) {
        if (!touch_paused.load(std::memory_order_acquire) && LockBus(30)) {
            if (!touch_paused.load(std::memory_order_acquire)) {
                uint8_t data[5]{};
                const auto result = Read(devices[kTouchAddress], 0x02, data, sizeof(data), 20);
                last_error = result;
                if (result == ESP_OK) {
                    const int x = ((data[1] & 15) << 8) | data[2];
                    const int y = ((data[3] & 15) << 8) | data[4];
                    if (data[0] == 0 || (data[0] == 1 && x < kWidth && y <= TOUCH_VK_Y + TOUCH_VK_TOL)) {
                        ++samples;
                        sample_cb(data[0], x, y, x, y);
                    }
                } else ++read_errors;
            }
            UnlockBus();
        }
        vTaskDelay(std::max<TickType_t>(1, pdMS_TO_TICKS(8)));
    }
}
} // namespace

bool Init(std::string* error) { return InitIo(error) && InitPanel(error); }
bool StartTouch(Sample sample, std::string* error) {
    i2c_master_dev_handle_t device;
    if (!sample || !Check(Device(I2C_NUM_0, kTouchAddress, &device), "CST816S setup", error)) return false;
    uint8_t id = 0;
    if (!Check(Read(device, 0xa7, &id, 1), "CST816S ID", error)) return false;
    sample_cb = sample;
    ESP_LOGI(kTag, "CST816S id=%u logical=480x800", unsigned(id));
    return xTaskCreate(TouchTask, "pocket_touch", 4096, nullptr, 5, nullptr) == pdPASS ||
           Check(ESP_ERR_NO_MEM, "touch task", error);
}
void PauseTouch(bool paused) { touch_paused.store(paused, std::memory_order_release); }
bool LockBus(int timeout_ms) {
    return bus_lock && xSemaphoreTake(bus_lock, pdMS_TO_TICKS(timeout_ms)) == pdTRUE;
}
void UnlockBus() { xSemaphoreGive(bus_lock); }
power_i2c_t PowerBus() { return {I2C_NUM_0, LockBus, UnlockBus, Device}; }
void Motor(bool enabled) { gpio_set_level(VIBRATION_MOTOR_GPIO, enabled); }
bool ReadPowerKey(bool* down) {
    if (!down) return false;
    *down = gpio_get_level(POWER_BUTTON_GPIO) == 0;
    return true;
}
void SetNativePixel(uint8_t* frame, int x, int y, bool black) {
    const int px = y, py = kWidth - 1 - x;
    auto& byte = frame[size_t(py) * (kHeight / 8) + px / 8];
    const uint8_t mask = uint8_t(0x80u >> (px % 8));
    byte = black ? uint8_t(byte & ~mask) : uint8_t(byte | mask);
}
void EncodePoster(const uint8_t* portrait, uint8_t* frame) {
    std::memset(frame, 0xff, kMonoBytes);
    for (int y = 0; y < kHeight; ++y)
        for (int x = 0; x < kWidth; ++x)
            if (portrait[size_t(y) * (kWidth / 8) + x / 8] & (0x80u >> (x % 8)))
                SetNativePixel(frame, x, y, true);
}
esp_err_t Present(const uint8_t* frame, bool full) {
    if (!panel || !transfer || !frame) return ESP_ERR_INVALID_STATE;
    full = full || !known;
    known = false;
    auto result = esp_lcd_panel_io_tx_param(panel_io, -1, nullptr, 0);
    if (result != ESP_OK) return result;
    std::memcpy(transfer, frame, kMonoBytes);
    if (full) {
        result = epaper_panel_set_bitmap_color(panel, SSD1677_EPAPER_BITMAP_PREVIOUS);
        if (result == ESP_OK) result = esp_lcd_panel_draw_bitmap(panel, 0, 0, 800, 480, transfer);
    } else result = epaper_panel_prepare_for_partial(panel);
    if (result == ESP_OK) result = epaper_panel_set_bitmap_color(panel, SSD1677_EPAPER_BITMAP_CURRENT);
    if (result == ESP_OK) result = esp_lcd_panel_draw_bitmap(panel, 0, 0, 800, 480, transfer);
    if (result == ESP_OK)
        result = epaper_panel_set_refresh_mode(panel, full ? SSD1677_EPAPER_REFRESH_FULL : SSD1677_EPAPER_REFRESH_PARTIAL);
    while (xSemaphoreTake(refresh_done, 0) == pdTRUE) {}
    if (result == ESP_OK) result = epaper_panel_refresh_screen(panel);
    if (result == ESP_OK && !full && xSemaphoreTake(refresh_done, pdMS_TO_TICKS(7000)) != pdTRUE)
        result = ESP_ERR_TIMEOUT;
    known = result == ESP_OK;
    return result;
}
esp_err_t SleepPanel() {
    known = false;
    return epaper_panel_deep_sleep(panel);
}
esp_err_t WakePanel() {
    auto result = esp_lcd_panel_reset(panel);
    if (result == ESP_OK) result = esp_lcd_panel_init(panel);
    known = false;
    return result;
}
void PrepareSleep() {
    Motor(false);
    if (LockBus(100)) {
        // Keep main power and the wake key rail latched. Disable PA and hold
        // the touch controller in reset while the processor sleeps.
        const auto result = Write16(2, output_latch & ~((1u<<1)|(1u<<9)));
        if (result != ESP_OK) ESP_LOGW(kTag, "sleep IO: %s", esp_err_to_name(result));
        UnlockBus();
    }
}
TouchStats ReadTouchStats() {
    return {samples.load(), read_errors.load(), last_error.load(),
            gpio_get_level(TOUCH_INT_GPIO), touch_paused.load()};
}
} // namespace pocket_s3
