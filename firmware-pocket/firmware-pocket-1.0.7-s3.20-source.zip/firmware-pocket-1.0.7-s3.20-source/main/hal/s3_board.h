#pragma once

#include "power/power_i2c.h"
#include <cstddef>
#include <cstdint>
#include <string>

namespace pocket_s3 {
constexpr int kWidth = 480;
constexpr int kHeight = 800;
constexpr size_t kMonoBytes = size_t(kWidth) * kHeight / 8;
using Sample = void (*)(uint8_t count, int raw_x, int raw_y, int x, int y);

bool Init(std::string* error);
bool StartTouch(Sample sample, std::string* error);
void PauseTouch(bool paused);
bool LockBus(int timeout_ms);
void UnlockBus();
power_i2c_t PowerBus();
void Motor(bool enabled);
bool ReadPowerKey(bool* down);
void SetNativePixel(uint8_t* frame, int x, int y, bool black);
void EncodePoster(const uint8_t* portrait, uint8_t* frame);
esp_err_t Present(const uint8_t* frame, bool full);
esp_err_t SleepPanel();
esp_err_t WakePanel();
void PrepareSleep();

struct TouchStats {
    unsigned samples;
    unsigned read_errors;
    int last_error;
    int irq_level;
    bool paused;
};
TouchStats ReadTouchStats();
} // namespace pocket_s3
