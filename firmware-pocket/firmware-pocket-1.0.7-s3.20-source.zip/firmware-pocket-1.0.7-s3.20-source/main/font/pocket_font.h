#pragma once
#include "lvgl.h"
#include <cstdint>

namespace pocket_font {
// Private embedded font, independent of TF contents and any host firmware.
// Native Noto metrics and 1bpp ink at each UI pixel size. Never resize glyphs.
const lv_font_t* Get(uint16_t pixels = 23);

struct CacheStats {
    uint32_t requests = 0;
    uint32_t hits = 0;
    uint32_t expanded = 0;
    uint32_t uncached = 0;
    uint32_t allocation_failures = 0;
    uint32_t cache_bytes = 0;
    uint32_t expand_us_total = 0;
    uint32_t expand_us_max = 0;
};
// Safe to sample from another task; individual counters are atomic, while the
// returned group is an approximate snapshot. Timings cover actual expansion.
CacheStats GetCacheStats();
}
