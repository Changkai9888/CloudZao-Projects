# s3.20 发布核对

对应 Metalio E-INK4 3.97 英寸 ESP32-S3 版固件口袋 1.0.7-s3.20。正式发布的 BIN SHA-256 为 `1420671308c4edb201456fc7aef374339f088f97475631c2c10b45e9c0a230cd`。

## 许可与来源

- 项目原创代码采用 MIT。随附的第三方代码、字体、词表和图像各按自身许可或授权分发。
- 启动组件来自 ESP-IDF 5.5.4。上游 Bootloader 源文件标注 Apache-2.0，完整许可见 `licenses/ESP-IDF-Apache-2.0.txt`。FPOCKET ABI 1.0 是应用接入协议。
- 本版链接本机的 SSD1677 驱动。已核对的 s3.20 ELF 与链接清单中没有 Plus 的 EPDiy 驱动。SSD1677 源码保留 Apache-2.0 文件头。板级参考的 CloudZao MIT、FreeInk/CrossPoint 署名及许可另附。灰阶波形表的 112 字节与 Open X4 E-Paper Community SDK 公布的 `lut_grayscale` 完全一致，附其 MIT 许可。该对照确认字节和对应上游许可，原工程最初引入该表的提交未查明。
- Noto Sans SC、Noto Sans 和其派生位图保留 OFL 1.1，派生字体名为 Pocket 3.97 Native Sans。附原版权和许可全文。拼音输入表的上游来源、转换和 Apache/MIT 署名见第三方说明。
- 本版实际使用的 FatFs 为 R0.15 patch2，C 运行库为 Xtensa 工具链的 Newlib。其原文，以及对应版本的 Mbed TLS 许可，见 `licenses/actual-s3.20/`。本版已将上述实际许可和灰阶波形署名纳入设备离线许可。发布时请同时提供本说明及实际依赖许可。
- 锁屏与深休图保留为构建用位图，来源摘要见 `sources/artwork-provenance.json`。公开发布由维护者确认其提供的海报、图像和标识可随固件再分发。项目 MIT 仅覆盖项目原创代码。

来源：[ESP-IDF 5.5.4 许可](https://github.com/espressif/esp-idf/blob/v5.5.4/LICENSE) · [CloudZao SSD1677 驱动](https://github.com/CloudZao/Metalio-E-INK4/blob/6d05a6583c0feaea97b91d9aade3ce6757321dc4/main/boards/metalio-e-ink-4/esp_lcd_panel_ssd1677.c) · [Open X4 波形表](https://github.com/open-x4-epaper/community-sdk/blob/main/libs/display/EInkDisplay/src/EInkDisplay.cpp) · [FreeInk 署名](https://github.com/Free-Ink/freeink-sdk/blob/main/NOTICE) · [OFL 说明](https://openfontlicense.org/how-to-modify-ofl-fonts/)

## GitHub 发布

把本源码 ZIP 和对应版本的 BIN 作为同一个 GitHub Release 的附件。发布说明写明版本、3.97 英寸硬件、BIN SHA-256，以及本文件中提到的许可范围和实际依赖说明。其他只提供 BIN 的下载页面应给出该版本的固定 Release 链接，方便用户取得源码和许可。下载渠道允许时，也可将 BIN 与许可文本一同打包。

本次核对未发现由 Plus EPDiy 引出的 LGPL 重新链接材料要求。接入指南及设备绑定请从项目说明访问。日常构建需要已激活的 ESP-IDF 工具链及锁定的公开依赖。
