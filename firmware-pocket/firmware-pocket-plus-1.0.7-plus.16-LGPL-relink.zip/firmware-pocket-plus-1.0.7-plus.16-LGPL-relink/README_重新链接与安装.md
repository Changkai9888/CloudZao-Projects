# 固件口袋 Plus：显示驱动修改与重新链接材料

对应版本：**1.0.7-plus.16**，设备为 Metalio E-INK4 Plus / ESP32-S31。

对应原始完整 BIN 的 SHA256：

`83992d1f4b6745dcd8dcaed95cbbd26a2397d93c5b4f08c9884335796e0b8f49`

本包按 LGPL v3 第4(d)(0)条提供显示驱动源码及重新链接材料。口袋业务以目标文件提供，未附业务源码或架构指南。

## 包内材料

| 路径 | 用途 |
| --- | --- |
| `driver/epdiy/` | 本版实际使用的 EPDiy 驱动源码、修改及头文件，可编辑 |
| `objects/`、`sdk-libs/` | 已去除调试信息的可重新链接目标文件和静态库 |
| `config/sdkconfig.h`、`linkdirs/` | 编译配置及必要链接脚本 |
| `driver_compile.json`、`link_args.json` | 驱动编译及最终链接参数 |
| `images/flash-prefix.bin` | 完整镜像的引导与分区前缀 |
| `scripts/relink.py` | 重建驱动、重新链接并生成可烧录 BIN |
| `licenses/` | LGPL、GPL及其他随附组件适用的版权和许可原文 |

目标文件保留重新链接所需的符号与重定位信息；未附调试符号，不代表无法进行反编译或其他分析。

## 重新生成 BIN

1. 使用 Linux 或 WSL，准备公开的 [ESP-IDF](https://github.com/espressif/esp-idf)，检出提交 `fff9895c82d744c7237be8847347bdd1b07c6643`，获取其子模块，并安装 ESP32-S31 所需工具。
2. 使用该提交对应的 RISC-V 工具链 **esp-15.2.0_20251204**，执行该 SDK 的 `export.sh`，使编译器及 esptool 可用。SDK和工具链无需从本包获取。
3. 解压本包，在包根目录执行：

```sh
python3 scripts/relink.py
```

结果为：`output/firmware-pocket-plus-1.0.7-plus.16-relinked.bin`。

修改显示驱动时，编辑 `driver/epdiy/` 后再次运行同一命令。脚本使用包内应用目标文件与新编译的驱动链接；通常应保持驱动的外部接口兼容。代码或接口改动导致的编译、链接及运行错误需要由修改者处理。

## 安装修改版

先保存正在使用的应用并返回口袋。将生成的完整 BIN 从 **0x0** 烧录到 Plus 设备，可使用支持 ESP32-S31 的烧录器，或 SDK 环境中的 esptool：

```sh
python -m esptool --chip esp32s31 --port <设备串口> write-flash 0x0 output/firmware-pocket-plus-1.0.7-plus.16-relinked.bin
```

这是口袋自身的完整烧录镜像，不是放入 TF 卡 `packages` 的应用包。本发行版未启用要求私人签名密钥的安全启动或 Flash 加密；安装修改版不需要我们提供私有授权密钥。烧录前自行备份需保留的数据。

## 许可与权利

EPDiy 的 LGPL 及其引用的 GPL 文本随包提供，本地修改保留在源码中。其他组件、波形和字体等继续遵循各自许可，不能将全包统一视为 MIT。

应用目标文件沿用其原有 MIT 及第三方许可。允许按适用许可修改显示库、将应用与修改后的库重新链接和安装，并允许为调试这些库修改而进行必要的逆向工程；本包不施加与这些权利相反的限制。

参考：[LGPL v3 第4条](https://www.gnu.org/licenses/lgpl-3.0.html#section4)。本包对应上述版本和摘要，不能代替其他版本的对应材料。
