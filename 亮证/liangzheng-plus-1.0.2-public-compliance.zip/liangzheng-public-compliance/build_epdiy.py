#!/usr/bin/env python3
"""Build only the supplied EPDiy source using the pinned external ESP-IDF headers."""
from pathlib import Path
import argparse,json,os,subprocess,hashlib
p=argparse.ArgumentParser();p.add_argument('--idf-path',default=os.environ.get('IDF_PATH'));p.add_argument('--tool-prefix',default='riscv32-esp-elf-');a=p.parse_args()
if not a.idf_path:p.error('--idf-path or IDF_PATH is required')
r=Path(__file__).resolve().parent;b=r/'build';idf=Path(a.idf_path).resolve()
if (idf/'.git').exists():
 commit=subprocess.check_output(['git','-C',str(idf),'rev-parse','HEAD'],text=True).strip()
 if commit!='fff9895c82d744c7237be8847347bdd1b07c6643':raise SystemExit('ESP-IDF commit mismatch: '+commit)
# Official source archive is also supported. Verify every SDK header used by
# the original library compile, including recursively pinned submodule headers.
for name,sha in json.loads((r/'sdk-header-sha256.json').read_text()).items():
 p=idf/name
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=sha:raise SystemExit('SDK source mismatch: '+name)
def expand(s):return s.replace('${PACKAGE_ROOT}',str(r)).replace('${IDF_PATH}',str(idf))
run=b/'epdiy-rebuild';run.mkdir(exist_ok=True)
for n in ['cflags','cxxflags','ldflags']:(run/n).write_text(expand((b/'toolchain'/n).read_text()))
objects=[]
for entry in json.loads((r/'epdiy-compile-commands.json').read_text()):
 args=[expand(x).replace(str(b/'toolchain'),str(run)) for x in entry['arguments']]
 args[0]=a.tool_prefix+('g++' if args[0].endswith('g++') else 'gcc')
 output=b/entry['output'];output.parent.mkdir(parents=True,exist_ok=True)
 subprocess.run(args,cwd=b,check=True);objects.append(str(output))
lib=run/'libepdiy.a';lib.unlink(missing_ok=True)
subprocess.run([a.tool_prefix+'ar','qcD',str(lib)]+objects,check=True)
subprocess.run([a.tool_prefix+'ranlib',str(lib)],check=True)
print('Replacement library:',lib)
print('Use: python relink.py --epdiy-library '+str(lib))
