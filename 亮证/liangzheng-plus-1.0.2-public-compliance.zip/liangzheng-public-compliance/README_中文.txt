亮证 1.0.2 · LGPL 对应源码与可重链接材料

本包供接收者修改 EPDiy 显示库并重新组合/重链接亮证固件。包含：实际使用的完整 EPDiy 库源码（含修改与波形）、必要库构建配置、去除调试信息的应用/SDK对象与资源、链接脚本、库重编和应用重链接脚本、完整第三方许可。它不是亮证业务源码包；不含用户HTML、业务源码、开发日志或调试DWARF。应用对象保留重链接所需符号与重定位。

权利说明
你可按 LGPL-3.0 修改 EPDiy 并将其与配套应用对象重新组合/重链接。对应用部分的使用条款不得禁止为调试这些库修改而必需的逆向工程。为上述目的，允许使用本包应用对象与资源进行重新组合及在兼容设备安装；亮证业务代码其他授权不因此改变。库及第三方组件以 licenses/THIRD_PARTY_LICENSES.txt 和各源码中的许可为准。无保修；商标不随代码许可转让。无需秘密签名密钥，本包流程不设置阻止修改库安装的技术措施。

工具版本（Linux x86_64 已验证；不附带整个工具链）
ESP-IDF v6.1.0，固定提交 fff9895c82d744c7237be8847347bdd1b07c6643：
https://github.com/espressif/esp-idf
获取该提交并递归初始化子模块，按官方文档安装其 Python 依赖。仅重链接不需完整SDK；重编EPDiy需此SDK头文件及子模块。
RISC-V GCC esp-15.2.0_20251204（GCC15.2.0）：
https://github.com/espressif/crosstool-NG/releases/download/esp-15.2.0_20251204/riscv32-esp-elf-15.2.0_20251204-x86_64-linux-gnu.tar.xz
下载SHA256 ace5aae6afe98f754947be043d40173e2e22ace57754b11a394b7238eefa01cf
解压并把其 bin 目录加 PATH。Python 环境安装 esptool==5.6.0。使用的GNU工具与官方工具链同版。

1. 原样重链接（不依赖业务源文件）
python relink.py
输出 build/liangzheng.elf 与 build/liangzheng.bin（仅应用分区）。相同配套工具版本、原样对象与脚本的结果应与发布应用完全相同；ELF SHA写入应用描述符也是比较的一部分。

2. 修改并重编 EPDiy
编辑 project/components/epdiy/ 下所需文件，保留版权/许可。
python build_epdiy.py --idf-path /path/to/pinned-esp-idf
脚本核对SDK提交，使用 epdiy-compile-commands.json 中的库专用参数，编译25个库源文件，完全不读取亮证业务源码。
python relink.py --epdiy-library build/epdiy-rebuild/libepdiy.a
可用 --tool-prefix 或 --cxx 指定上述工具链可执行程序。此流程不执行烧录。

3. 在兼容 Plus 4.7 / ESP32-S31 上安装
build/liangzheng.bin 是应用分区镜像，不是地址0的完整镜像。独立模式须使用与本发布相同分区布局、bootloader与otadata；已有相同布局时可把应用镜像写入0x10000。不要把仅应用文件写入0x0，不要把独立全镜像当保留口袋的升级。
固件口袋 1.0.7-plus.13 导入时使用配套完整镜像布局：由相同发布bootloader(0x2000)、partition-table(0x8000)、otadata(0xd000)及本应用(0x10000)合并成单一BIN；可用 merge_image.py 生成。
修改库后的镜像须自行真机验证；不要在带重要资料的设备上跳过备份。此包不自动访问串口、不上传、不发布。

隐私界限
公开对象含固件自身的界面字符串、位图字体、图标/资源与机器指令，这是可重链接所必需，不是可编辑业务源文件；包内没有用户导入凭证、真实核销历史、用户原始录音或开发会话。
