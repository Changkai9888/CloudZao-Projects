#!/usr/bin/env python3
"""Build a standalone/pocket-layout full image; never flash a device."""
from pathlib import Path
import subprocess,sys
r=Path(__file__).resolve().parent
subprocess.run([sys.executable,'-m','esptool','--chip','esp32s31','merge-bin','--flash-mode','dio','--flash-size','16MB','--flash-freq','80m','-o',str(r/'liangzheng-modified-full.bin'),'0x2000',str(r/'install/bootloader.bin'),'0x8000',str(r/'install/partition-table.bin'),'0xd000',str(r/'install/ota_data_initial.bin'),'0x10000',str(r/'build/liangzheng.bin')],check=True)
