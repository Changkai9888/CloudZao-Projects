#!/usr/bin/env python3
"""Relink supplied objects, optionally replace EPDiy; never accesses a device."""
from pathlib import Path
import argparse,json,subprocess,sys
p=argparse.ArgumentParser();p.add_argument('--cxx',default='riscv32-esp-elf-g++');p.add_argument('--epdiy-library');p.add_argument('--strip',default='riscv32-esp-elf-strip');a=p.parse_args()
r=Path(__file__).resolve().parent;b=r/'build'
def expand(s):return s.replace('${PACKAGE_ROOT}',str(r))
# Materialize response-file templates in a disposable run directory.
run=b/'public-run';run.mkdir(exist_ok=True)
for n in ['cflags','cxxflags','ldflags']:
 (run/n).write_text(expand((b/'toolchain'/n).read_text()))
args=[expand(s).replace(str(b/'toolchain'),str(run)) for s in json.loads((r/'link-args.json').read_text())]
if a.epdiy_library:
 new=str(Path(a.epdiy_library).resolve());args=[new if s=='esp-idf/epdiy/libepdiy.a' else s for s in args]
subprocess.run([a.cxx]+args,cwd=b,check=True)
subprocess.run([a.strip,'--strip-debug',str(b/'liangzheng.elf')],check=True)
# ELF SHA is part of the application descriptor; this ELF is the release baseline.
subprocess.run([sys.executable,'-m','esptool','--chip','esp32s31','elf2image','--flash-mode','dio','--flash-freq','80m','--flash-size','16MB','--elf-sha256-offset','0xb0','--flash-mmu-page-size','64KB','--min-rev-full','0','--max-rev-full','99','-o','liangzheng.bin','liangzheng.elf'],cwd=b,check=True)
print(b/'liangzheng.bin')
