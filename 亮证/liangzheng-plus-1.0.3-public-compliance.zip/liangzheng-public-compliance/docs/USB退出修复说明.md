# 1.0.3 USB 退出恢复修复

## 代码确认的故障机制（不冒充已读取真机日志）
旧 Exit() 仅接受 SCSI START STOP UNIT / load_eject。用户界面的“已安全弹出”勾选没有传给该函数；USB DETACHED 未记录。因此未发送该SCSI命令的主机、已拔线等情形都可能被永久拒绝。与此同时主界面USB视图覆写了Exit返回错误，用户看到的只是未退出。USB所有权锁正确阻止返回口袋，但缺乏可恢复出口。

## 修复与互斥不变量
- `Exit(error, host_eject_confirmed)` 接受真实SCSI eject、真实DETACHED，或用户明确确认已经先在电脑安全弹出。Suspend不视为弹出；重新ATTACHED清除旧detach状态。
- 用户确认不是主机缓存刷盘的技术证明，界面和使用说明仍必须要求先电脑安全弹出。固件不能替电脑补写尚未提交的数据，不将普通等待或挂起解释为安全弹出。
- 切入Stopping后立即拒绝新MSC读写；断开设备端连接，保留TinyUSB任务以完成已接受的deferred写入。等待真实读/写回调和已接受SD写入计数归零后才调用driver uninstall，最后挂回VFS。
- 排空最多等待10秒；超时保留ownership锁、禁止TF业务和睡眠，不强删正在写卡的task、不假报成功。worker返回Error，用户可重试退出。
- TinyUSB原task_stop在deinit失败前清除context，导致后续uninstall无法重试。现保留context直至deinit成功，task只删除一次，成功stop幂等返回；没有以失败为理由清USB所有权。
- 原有双槽历史与TF身份规则不变，没有删除用户TXT或存档，也没有同时挂载MSC与VFS。

## 已跑的软件测试
- 实际 wallet_usb.cc 配合平台mock，ASAN/UBSAN：原转移/启动/卸载/重挂载失败锁、无SCSI但用户确认退出、suspend拒退出、detach及重新连接清状态、排空超时锁定、后续排空重试成功、一次remount事件。
- 从实际vendor C源码提取 MSC回调与pending计数：read执行中计数、读失败、写拒绝、已接受deferred写保持pending、关admission后不接受新操作。
- 从实际vendor C源码提取 task_stop：deinit失败保留context、成功重试只释放一次、完成后再次调用幂等。

上述测试不是Windows/USB硬件验收。仍需真机测试导入→电脑安全弹出→勾选→退出→自动重扫、拔线恢复、反复进出、无旧码闪回以及正常返回口袋。
